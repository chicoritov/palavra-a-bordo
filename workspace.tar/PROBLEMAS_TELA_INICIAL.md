# 🐛 Problemas Identificados na Tela Inicial

## Análise Crítica e Detalhada

Data da análise: 2024  
Arquivo analisado: `src/App.tsx` (linhas 717-1066)

---

## 🔴 PROBLEMAS CRÍTICOS (Alta Prioridade)

### 1. **Estado do Som Não Funciona** 🔇
**Localização:** Linhas 802-812, 57

**Problema:**
```typescript
const [somLigado, setSomLigado] = useState(true);

<button onClick={() => setSomLigado(!somLigado)}>
  <span>{somLigado ? '🔊' : '🔇'}</span>
</button>
```

**Impacto:**
- ❌ O estado `somLigado` é apenas visual
- ❌ Não afeta o áudio real do jogo
- ❌ Usuário acha que mutou, mas o som continua
- ❌ Experiência frustrante e confusa

**Solução:**
```typescript
// Integrar com o sistema de áudio existente
const toggleSom = () => {
  const novosVolumes = somLigado 
    ? { musica: 0, efeitos: 0, voz: 0 }
    : { musica: 0.3, efeitos: 0.5, voz: 0.8 };
  
  setVolumes(novosVolumes.musica, novosVolumes.efeitos, novosVolumes.voz);
  setSomLigado(!somLigado);
};
```

---

### 2. **Canvas do Carro com Performance Problemática** 🚗
**Localização:** Linhas 900-1021

**Problema:**
```typescript
<canvas
  ref={(el) => {
    if (el) {
      const ctx = el.getContext('2d');
      if (ctx) {
        // Desenha o carro inline
        ctx.save();
        ctx.translate(140, 80);
        ctx.scale(2.3, 2.3);
        // ... 100+ linhas de desenho
      }
    }
  }}
/>
```

**Impacto:**
- ❌ Função inline é recriada em cada render
- ❌ Canvas pode ser redesenhado desnecessariamente
- ❌ Não há limpeza do canvas antes de redesenhar
- ❌ Performance degradada em dispositivos lentos
- ❌ Dificuldade de manutenção (100+ linhas inline)

**Solução:**
```typescript
// Extrair para função separada com useEffect
const desenharCarro = useCallback((canvas: HTMLCanvasElement) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save();
  // ... desenho
  ctx.restore();
}, []);

useEffect(() => {
  if (canvasRef.current) {
    desenharCarro(canvasRef.current);
  }
}, [desenharCarro]);
```

---

### 3. **Layout Quebrado em Mobile** 📱
**Localização:** Linhas 835, 895-896, 1043

**Problema:**
```typescript
// Título muito grande
className="text-5xl md:text-7xl"

// Carro com tamanho fixo
style={{ width: '280px', height: '160px' }}

// Botões em linha horizontal
<div className="flex gap-6 mt-6">
  {/* 3 botões de 96x96px cada = 384px + gaps */}
</div>
```

**Impacto:**
- ❌ Título pode ultrapassar a tela em mobile (< 400px)
- ❌ Carro de 280px é muito grande para telas pequenas
- ❌ Botões secundários não cabem em telas < 400px
- ❌ Overflow horizontal ou quebra de layout
- ❌ Experiência ruim em dispositivos móveis

**Solução:**
```typescript
// Título responsivo
className="text-4xl sm:text-5xl md:text-7xl"

// Carro responsivo
style={{ 
  width: 'min(280px, 80vw)', 
  height: 'auto',
  aspectRatio: '280/160'
}}

// Botões em grid responsivo
<div className="grid grid-cols-3 gap-4 sm:gap-6 mt-6 max-w-md">
  {/* ou usar flex-wrap */}
  <div className="flex flex-wrap justify-center gap-4 mt-6">
```

---

### 4. **Acessibilidade - Falta de ARIA Labels** ♿
**Localização:** Linhas 802-812, 1026-1040, 1044-1100

**Problema:**
```typescript
<button onClick={() => setSomLigado(!somLigado)}>
  <span>{somLigado ? '🔊' : '🔇'}</span>
</button>

<button onClick={iniciarJogoDaTelaInicial}>
  ▶ JOGAR
</button>
```

**Impacto:**
- ❌ Leitores de tela não entendem a função dos botões
- ❌ Navegação por teclado prejudicada
- ❌ Não há indicação de estado atual do som
- ❌ Viola WCAG 2.1 Level A

**Solução:**
```typescript
<button 
  onClick={() => setSomLigado(!somLigado)}
  aria-label={somLigado ? 'Desativar som' : 'Ativar som'}
  aria-pressed={somLigado}
>
  <span aria-hidden="true">{somLigado ? '🔊' : '🔇'}</span>
</button>

<button 
  onClick={iniciarJogoDaTelaInicial}
  aria-label="Iniciar jogo"
>
  <span aria-hidden="true">▶</span> JOGAR
</button>
```

---

## 🟠 PROBLEMAS IMPORTANTES (Média Prioridade)

### 5. **Balão de Fala Sempre Igual** 💬
**Localização:** Linhas 871-889

**Problema:**
```typescript
<span>Vamos jogar! 🎮</span>
```

**Impacto:**
- ❌ Mensagem estática e repetitiva
- ❌ Não há variação ou surpresa
- ❌ Perde oportunidade de engajamento
- ❌ Pode sobrepor o título em telas menores

**Solução:**
```typescript
const mensagens = [
  'Vamos jogar! 🎮',
  'Pronto para aprender? 📚',
  'Estacione e divirta-se! 🚗',
  'Que palavra é essa? 🤔',
  'Vamos rimar! 🎵'
];

const [mensagemAtual] = useState(
  mensagens[Math.floor(Math.random() * mensagens.length)]
);

<span>{mensagemAtual}</span>
```

---

### 6. **Preview da Estrada Confuso** 🛣️
**Localização:** Linhas 768-799

**Problema:**
```typescript
{/* Vagas de estacionamento (preview) */}
<div className="flex gap-8">
  {['GATO', 'CASA', 'SAPO'].map((palavra) => (
    <div>{palavra}</div>
  ))}
</div>
```

**Impacto:**
- ❌ Usuário pode pensar que são as palavras do jogo real
- ❌ Não há indicação de que é apenas um preview
- ❌ Compete visualmente com o conteúdo principal
- ❌ Pode causar confusão sobre o objetivo

**Solução:**
```typescript
{/* Preview decorativo - não interativo */}
<div 
  className="absolute bottom-0 left-0 w-full h-1/3 opacity-50"
  aria-hidden="true"
>
  {/* Adicionar label "PREVIEW" ou tornar mais sutil */}
</div>
```

---

### 7. **Contraste Insuficiente** 🎨
**Localização:** Linhas 855, 1064

**Problema:**
```typescript
// Subtítulo
color: '#2C5F7C',
textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)',

// Texto dos botões
color: '#2C5F7C',
textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)'
```

**Impacto:**
- ❌ Azul #2C5F7C sobre fundo azul claro pode ter contraste < 4.5:1
- ❌ TextShadow pode não ser suficiente em todos os backgrounds
- ❌ Viola WCAG 2.1 Level AA (mínimo 4.5:1)
- ❌ Dificulta leitura para pessoas com baixa visão

**Solução:**
```typescript
// Usar cores com melhor contraste
color: '#1a3a52', // Azul mais escuro
// ou
color: '#ffffff', // Branco com contorno
textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)',
```

---

### 8. **Animações Excessivas** ✨
**Localização:** Linhas 745, 764, 867, 874, 897, 1035

**Problema:**
```typescript
// Múltiplas animações simultâneas
animation: `floatCloud ${30 + i * 10}s linear infinite`
animation: 'pulse 3s ease-in-out infinite'
animation: 'slideInLeft 1s ease-out 0.5s both'
animation: 'bounce 2s ease-in-out infinite'
animation: 'carIdle 2s ease-in-out infinite'
animation: 'pulse 1.5s ease-in-out infinite, fadeInUp 0.5s ease-out 1s both'
```

**Impacto:**
- ❌ 6+ animações simultâneas podem causar jank
- ❌ Consuma CPU/GPU desnecessariamente
- ❌ Pode ser distrativo para crianças com TDAH
- ❌ Não respeita `prefers-reduced-motion`

**Solução:**
```typescript
// Respeitar preferências do usuário
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
  }
}

// Reduzir animações contínuas
animation: 'fadeInUp 0.5s ease-out 1s both' // apenas entrada
```

---

### 9. **Falta de Indicador de Foco Visível** 🎯
**Localização:** Todos os botões

**Problema:**
```typescript
<button className="... hover:scale-110 active:scale-95">
```

**Impacto:**
- ❌ Não há indicador de foco para navegação por teclado
- ❌ Usuários que usam teclado não sabem qual botão está selecionado
- ❌ Viola WCAG 2.1 Level A (2.4.7 Focus Visible)

**Solução:**
```typescript
<button 
  className="... focus:ring-4 focus:ring-blue-300 focus:outline-none"
>
```

---

### 10. **Botões sem Tipo Explícito** 🔘
**Localização:** Linhas 802, 1026, 1044, 1068, 1092

**Problema:**
```typescript
<button onClick={...}>
```

**Impacto:**
- ❌ Botões dentro de formulários podem submitar por padrão
- ❌ Comportamento inconsistente entre navegadores
- ❌ Pode causar bugs inesperados

**Solução:**
```typescript
<button type="button" onClick={...}>
```

---

## 🟡 PROBLEMAS MENORES (Baixa Prioridade)

### 11. **Posição do Botão de Som** 🔊
**Localização:** Linha 804

**Problema:**
```typescript
className="absolute top-6 right-6"
```

**Impacto:**
- ❌ Difícil de alcançar em mobile (canto superior direito)
- ❌ Pode ser clicado acidentalmente
- ❌ Não há feedback visual claro de estado

**Solução:**
```typescript
// Mover para posição mais acessível
className="absolute top-6 left-6 sm:right-6 sm:left-auto"
```

---

### 12. **Textos Hardcoded** 🌍
**Localização:** Linhas 844-846, 860, 879, 1039, 1062, 1086, 1110, 1125

**Problema:**
```typescript
'🚗 PALAVRA'
'A BORDO 🅿️'
'Estacione o carro na palavra certa! 🎯'
'Vamos jogar! 🎮'
'▶ JOGAR'
'Como Jogar'
'Conquistas'
'Configurações'
'🎓 Para crianças de 5-8 anos • 36 fases de aprendizado'
```

**Impacto:**
- ❌ Não há suporte para internacionalização (i18n)
- ❌ Difícil traduzir para outros idiomas
- ❌ Emojis podem não renderizar em todos os dispositivos

**Solução:**
```typescript
// Criar arquivo de traduções
const traducoes = {
  pt: {
    titulo: 'PALAVRA A BORDO',
    subtitulo: 'Estacione o carro na palavra certa!',
    // ...
  },
  en: {
    titulo: 'WORD ABOARD',
    subtitulo: 'Park the car on the right word!',
    // ...
  }
};
```

---

### 13. **Falta de Meta Tags SEO** 🔍
**Localização:** `index.html`

**Problema:**
```html
<title>🚗 Palavra a bordo 🅿️</title>
```

**Impacto:**
- ❌ Não há descrição do jogo para motores de busca
- ❌ Não há keywords relevantes
- ❌ Não há Open Graph tags para redes sociais
- ❌ Dificulta descoberta do jogo

**Solução:**
```html
<title>Palavra a bordo - Jogo Educativo de Alfabetização</title>
<meta name="description" content="Jogo educativo de alfabetização para crianças de 5-8 anos. Estacione o carro na palavra certa e aprenda consciência fonológica brincando!" />
<meta name="keywords" content="alfabetização, jogo educativo, crianças, consciência fonológica, aprendizado" />
<meta property="og:title" content="Palavra a bordo" />
<meta property="og:description" content="Jogo educativo de alfabetização para crianças" />
```

---

### 14. **Semântica HTML Fraca** 🏗️
**Localização:** Linhas 729, 815

**Problema:**
```typescript
<div className="fixed inset-0 flex flex-col items-center justify-center">
  <div className="relative z-10 flex flex-col items-center gap-8 px-4">
    <h1>...</h1>
    <p>...</p>
    <button>...</button>
  </div>
</div>
```

**Impacto:**
- ❌ Falta `<main>` para agrupar conteúdo principal
- ❌ Falta `<section>` para seções lógicas
- ❌ `<h1>` está dentro de `<div>` sem contexto semântico
- ❌ Dificulta navegação por leitores de tela

**Solução:**
```typescript
<main className="fixed inset-0 flex flex-col items-center justify-center">
  <section aria-label="Tela inicial do jogo">
    <header>
      <h1>...</h1>
      <p>...</p>
    </header>
    <nav aria-label="Menu principal">
      <button>...</button>
    </nav>
  </section>
</main>
```

---

### 15. **Não Há Fallback para Navegadores Antigos** 🌐
**Localização:** Linhas 732, 829, 900

**Problema:**
```typescript
background: 'linear-gradient(...)'
backdropFilter: 'blur(10px)'
<canvas ref={...}>
```

**Impacto:**
- ❌ `backdrop-filter` não é suportado em IE11 e navegadores antigos
- ❌ Canvas pode não funcionar em dispositivos muito antigos
- ❌ Não há fallback visual

**Solução:**
```typescript
// Adicionar fallback
style={{
  background: 'linear-gradient(...)',
  // Fallback para navegadores sem suporte
  backgroundFallback: '#87CEEB'
}}

// Verificar suporte a canvas
if (!canvas.getContext) {
  // Renderizar imagem estática como fallback
}
```

---

## 📊 Resumo dos Problemas

| Severidade | Quantidade | Descrição |
|------------|------------|-----------|
| 🔴 Crítico | 4 | Funcionalidade quebrada, performance, responsividade, acessibilidade |
| 🟠 Importante | 6 | UX, contraste, animações, foco, semântica |
| 🟡 Menor | 5 | i18n, SEO, fallback, posição, manutenção |
| **Total** | **15** | |

---

## 🎯 Prioridades de Correção

### Fase 1: Críticos (Urgente)
1. ✅ Estado do som não funciona
2. ✅ Performance do canvas
3. ✅ Layout quebrado em mobile
4. ✅ Falta de ARIA labels

### Fase 2: Importantes (Alta prioridade)
5. ✅ Balão de fala estático
6. ✅ Preview confuso
7. ✅ Contraste insuficiente
8. ✅ Animações excessivas
9. ✅ Falta de foco visível
10. ✅ Botões sem tipo

### Fase 3: Menores (Média prioridade)
11. ✅ Posição do botão de som
12. ✅ Textos hardcoded
13. ✅ Falta de SEO
14. ✅ Semântica fraca
15. ✅ Sem fallback

---

## 🧪 Como Testar os Problemas

### Teste 1: Estado do Som
1. Clique no botão 🔊
2. Verifique se o som realmente muta
3. **Resultado esperado:** Som deve mutar
4. **Resultado atual:** Apenas ícone muda ❌

### Teste 2: Responsividade Mobile
1. Abra em tela < 400px
2. Verifique se todos os elementos cabem
3. **Resultado esperado:** Layout adaptado
4. **Resultado atual:** Overflow ou quebra ❌

### Teste 3: Acessibilidade
1. Navegue com Tab
2. Verifique indicador de foco
3. Use leitor de tela
4. **Resultado esperado:** Foco visível, labels claros
5. **Resultado atual:** Sem foco, sem labels ❌

### Teste 4: Performance
1. Abra DevTools > Performance
2. Grave enquanto a tela está visível
3. **Resultado esperado:** 60 FPS estável
4. **Resultado atual:** Possível jank com canvas ❌

---

## 📝 Conclusão

A tela inicial tem um design visual atraente, mas apresenta **15 problemas** que afetam:
- **Funcionalidade:** Estado do som não funciona
- **Performance:** Canvas com desenho inline
- **Responsividade:** Layout quebrado em mobile
- **Acessibilidade:** Falta de ARIA, foco, contraste
- **UX:** Animações excessivas, preview confuso
- **Manutenção:** Código inline, textos hardcoded

**Recomendação:** Corrigir os 4 problemas críticos antes do lançamento, depois abordar os importantes em sprints seguintes.

---

**Análise concluída!** 🔍✨
