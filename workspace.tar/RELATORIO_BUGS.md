# 🐛 Relatório de Bugs - AlfaEstacionamento

## Análise Completa do Código

Data da análise: 2024
Versão analisada: 3D Isométrico

---

## 🔴 BUGS CRÍTICOS (Quebram a funcionalidade)

### Bug #1: Desincronização entre Lógica 2D e Renderização 3D
**Severidade:** CRÍTICA  
**Arquivo:** `src/App.tsx` e `src/game/renderer3d.ts`

**Descrição:**
O sistema de colisão usa coordenadas 2D cartesianas (x, y), mas a renderização 3D converte para isométrico usando `worldToIso()`. Isso causa um desalinhamento grave entre:
- Onde o carro **está** (lógica 2D)
- Onde o carro **aparece** (renderização 3D)
- Onde as vagas **estão** (lógica 2D)
- Onde as vagas **aparecem** (renderização 3D)

**Código problemático:**
```typescript
// App.tsx - Lógica usa coordenadas 2D
if (novoX < 10 || novoX + carro.w > cw - 10) colidiu = true;

// renderer3d.ts - Renderização converte para isométrico
const isoPos = worldToIso(carro.x - 450, carro.y - 250, 20);
```

**Impacto:**
- Carro pode colidir com objetos que visualmente não estão ali
- Vagas podem parecer acessíveis mas não são
- Experiência de jogo frustrante e imprevisível

**Solução:**
Criar sistema de colisão isométrico ou renderizar em 2D puro.

---

### Bug #2: Flickering da Textura do Asfalto
**Severidade:** CRÍTICA  
**Arquivo:** `src/game/renderer3d.ts` (linhas 121-141)

**Descrição:**
A textura do asfalto é gerada aleatoriamente **a cada frame** dentro da função de renderização, causando flickering visual constante.

**Código problemático:**
```typescript
// Renderizado 60x por segundo!
ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
for (let i = 0; i < 200; i++) {
  const angle = Math.random() * Math.PI * 2; // ← Random a cada frame!
  const radius = Math.random() * 400;
  const x = Math.cos(angle) * radius;
  const y = Math.sin(angle) * radius * 0.5;
  ctx.fillRect(x, y, size, size);
}
```

**Impacto:**
- Asfalto "pisca" constantemente
- Distrativo e cansativo visualmente
- Performance degradada (200 randoms por frame)

**Solução:**
Pré-gerar textura uma vez e reutilizar:
```typescript
// Fora do loop de renderização
const texturaChao = gerarTexturaChao(); // Array fixo de pontos

// Dentro do render
for (const ponto of texturaChao) {
  ctx.fillRect(ponto.x, ponto.y, ponto.w, ponto.h);
}
```

---

### Bug #3: Posição Inicial do Carro Ignora Layout
**Severidade:** CRÍTICA  
**Arquivo:** `src/App.tsx` (linha 576-578)

**Descrição:**
Quando o jogador erra uma vaga, o carro é resetado para posição fixa (50, 240), ignorando o layout atual. No layout "shopping", a posição inicial deveria ser diferente.

**Código problemático:**
```typescript
setTimeout(() => {
  carro.x = 50;
  carro.y = 240; // ← Sempre 240, mesmo no layout shopping!
  emVaga!.estado = 'normal';
  state.tempoNaVaga = 0;
  state.vagaAtual = null;
}, 800);
```

**Impacto:**
- No layout shopping, carro aparece em posição errada
- Pode spawnar dentro de obstáculos
- Experiência inconsistente

**Solução:**
```typescript
setTimeout(() => {
  if (state.layout === 'shopping') {
    carro.x = 50;
    carro.y = 150; // Posição correta para shopping
  } else {
    carro.x = 50;
    carro.y = 240; // Posição correta para clássico
  }
  // ... resto do código
}, 800);
```

---

### Bug #4: Sistema de Partículas em Coordenadas Erradas
**Severidade:** CRÍTICA  
**Arquivo:** `src/game/particles.ts` e `src/game/renderer3d.ts`

**Descrição:**
As partículas são criadas com coordenadas 2D do carro, mas renderizadas diretamente no canvas sem conversão isométrica, causando desalinhamento completo.

**Código problemático:**
```typescript
// App.tsx - Partículas criadas em coords 2D
state.particulas.adicionarConfetes(carro.x + carro.w / 2, carro.y, 40);

// renderer3d.ts - Renderizadas sem conversão
particulas.renderizar(ctx); // ← coords 2D em canvas isométrico!
```

**Impacto:**
- Confetes aparecem em posições aleatórias
- Fumaça não segue o carro
- Faíscas de colisão aparecem no lugar errado
- Efeitos visuais completamente quebrados

**Solução:**
Converter coordenadas das partículas para isométrico antes de renderizar:
```typescript
renderizar(ctx) {
  for (const p of this.particulas) {
    const isoPos = worldToIso(p.x - 450, p.y - 250, 20);
    ctx.fillRect(isoPos.x, isoPos.y, p.tamanho, p.tamanho);
  }
}
```

---

## 🟠 BUGS IMPORTANTES (Degradam a experiência)

### Bug #5: Barra de Progresso Não Usa tempoNaVaga
**Severidade:** ALTA  
**Arquivo:** `src/game/renderer3d.ts` (linha 321)

**Descrição:**
A barra de progresso das vagas usa `Date.now() % 2000` em vez do `tempoNaVaga` real, mostrando progresso incorreto.

**Código problemático:**
```typescript
const progresso = Math.min(1, (Date.now() % 2000) / 2000);
// ↑ Isso não tem relação com o tempo que o carro está na vaga!
```

**Impacto:**
- Barra enche e esvazia sozinha
- Não reflete o progresso real
- Jogador não sabe quanto falta para estacionar

**Solução:**
Passar `tempoNaVaga` como parâmetro para a função de renderização:
```typescript
const progresso = Math.min(1, tempoNaVaga / 60);
```

---

### Bug #6: Emoji do Carro Renderizado Fora do Contexto 3D
**Severidade:** ALTA  
**Arquivo:** `src/game/renderer3d.ts` (linhas 585-626)

**Descrição:**
O emoji acima do carro é renderizado após `ctx.restore()`, então não segue as transformações 3D do carro (rotação, inclinação).

**Código problemático:**
```typescript
ctx.restore(); // ← Restaura transformações

// Emoji renderizado fora do contexto 3D!
if (ehJogador && emoji) {
  ctx.save();
  ctx.translate(screenX, screenY - 60); // ← coords absolutas
  // ... renderiza emoji
  ctx.restore();
}
```

**Impacto:**
- Emoji não segue rotação do carro
- Emoji não segue inclinação nas curvas
- Visual desconectado do carro

**Solução:**
Renderizar emoji dentro do contexto do carro, antes do `ctx.restore()`:
```typescript
// Antes do ctx.restore()
if (ehJogador && emoji) {
  ctx.save();
  ctx.translate(0, -60); // ← relativo ao carro
  // ... renderiza emoji
  ctx.restore();
}

ctx.restore(); // ← agora sim
```

---

### Bug #7: Som de Batida Tocando Continuamente
**Severidade:** ALTA  
**Arquivo:** `src/App.tsx` (linhas 417-423)

**Descrição:**
O `somBatida()` é chamado a cada frame de colisão (60x por segundo), causando múltiplos sons sobrepostos e áudio distorcido.

**Código problemático:**
```typescript
if (!colidiu) carro.x = novoX;
else if (dx !== 0) {
  somBatida(); // ← Chamado 60x por segundo!
  state.particulas.adicionarFaiscas(...);
}
```

**Impacto:**
- Áudio distorcido e desagradável
- Performance degradada (muitos oscillators)
- Experiência auditiva ruim

**Solução:**
Adicionar cooldown para o som:
```typescript
const agora = Date.now();
if (!colidiu) {
  carro.x = novoX;
} else if (dx !== 0 && agora - state.ultimaBatida > 200) {
  somBatida();
  state.ultimaBatida = agora;
  state.particulas.adicionarFaiscas(...);
}
```

---

### Bug #8: Motor Não Para ao Sair do Jogo
**Severidade:** ALTA  
**Arquivo:** `src/App.tsx` (linha 640)

**Descrição:**
Quando o jogador clica "Menu", o motor continua tocando em background porque não há chamada para `pararMotor()`.

**Código problemático:**
```typescript
<button onClick={() => { setTela('menu'); }} className="...">
  ← Menu
</button>
// ← Faltou pararMotor()!
```

**Impacto:**
- Som de motor continua tocando no menu
- Confuso para o jogador
- Consome recursos desnecessariamente

**Solução:**
```typescript
<button onClick={() => { 
  pararMotor();
  setTela('menu'); 
}}>
  ← Menu
</button>
```

---

### Bug #9: Conquistas Podem Ser Desbloqueadas Múltiplas Vezes
**Severidade:** MÉDIA  
**Arquivo:** `src/App.tsx` (linhas 541-548)

**Descrição:**
Não há verificação se a conquista já foi desbloqueada antes de adicionar ao array, permitindo duplicatas.

**Código problemático:**
```typescript
const novasConquistas = verificarConquistas(state.stats);
if (novasConquistas.length > 0) {
  const c = novasConquistas[0];
  state.stats.conquistasDesbloqueadas.push(c.id); // ← Pode duplicar!
  setNovaConquista(c);
}
```

**Impacto:**
- Conquistas duplicadas no array
- Contagem errada de conquistas
- Possível crash ao acessar índices inválidos

**Solução:**
```typescript
if (novasConquistas.length > 0) {
  const c = novasConquistas[0];
  if (!state.stats.conquistasDesbloqueadas.includes(c.id)) {
    state.stats.conquistasDesbloqueadas.push(c.id);
    setNovaConquista(c);
    somConquista();
  }
}
```

---

### Bug #10: Estatísticas Não São Resetadas ao Reiniciar
**Severidade:** MÉDIA  
**Arquivo:** `src/App.tsx` (função `reiniciar`)

**Descrição:**
O botão "Jogar de Novo" não reseta completamente as estatísticas, mantendo dados de partidas anteriores.

**Código problemático:**
```typescript
const reiniciar = useCallback(() => {
  const state = gameState.current;
  state.stats = criarEstatisticasIniciais();
  setStats(criarEstatisticasIniciais());
  salvarEstatisticas(state.stats);
  setTela('menu');
}, []);
```

**Impacto:**
- Conquistas antigas permanecem
- Tempo total acumula
- Palavras erradas não são limpas
- Experiência inconsistente

**Solução:**
Já está correto, mas verificar se `criarEstatisticasIniciais()` está limpando tudo:
```typescript
export function criarEstatisticasIniciais(): EstatisticasJogador {
  return {
    fasesCompletadas: 0,
    totalAcertos: 0,
    totalErros: 0,
    fasesSemErro: 0,
    melhorSequencia: 0,
    palavrasErradas: {}, // ← Limpar objeto
    conquistasDesbloqueadas: [], // ← Limpar array
    estrelasPorFase: [], // ← Limpar array
    tempoTotal: 0
  };
}
```

---

## 🟡 BUGS MENORES (Detalhes visuais/UX)

### Bug #11: Ordenação de Profundidade Incorreta
**Severidade:** BAIXA  
**Arquivo:** `src/game/renderer3d.ts` (linha 662)

**Descrição:**
A ordenação de objetos por profundidade usa `x + y`, mas em isométrico deveria considerar a projeção real.

**Código problemático:**
```typescript
.sort((a, b) => a.profundidade - b.profundidade);
// onde profundidade = x + y (simplificado)
```

**Impacto:**
- Objetos podem ser renderizados na ordem errada
- Carro pode aparecer atrás de vagas quando deveria estar na frente
- Efeito 3D menos convincente

**Solução:**
Usar projeção isométrica real para calcular profundidade:
```typescript
const profundidade = (x + y) * ISO_SIN - z * 2;
```

---

### Bug #12: Vagas do Layout Shopping Não Aparecem Corretamente
**Severidade:** BAIXA  
**Arquivo:** `src/game/renderer3d.ts`

**Descrição:**
O renderer3D não diferencia entre layouts, então as vagas do layout shopping (com fileira "meio") podem não aparecer corretamente.

**Impacto:**
- Vagas da fileira central podem ficar invisíveis
- Layout shopping não funciona corretamente
- Jogador não consegue completar fases no layout shopping

**Solução:**
Adicionar lógica específica para renderizar vagas da fileira "meio":
```typescript
if (vaga.fileira === 'meio') {
  // Renderizar com elevação diferente
  const isoPos = worldToIso(vaga.x - 450, vaga.y - 250, 10);
}
```

---

### Bug #13: Nuvens Animadas Usam Math.random()
**Severidade:** BAIXA  
**Arquivo:** `src/game/renderer3d.ts` (linhas 57-92)

**Descrição:**
Embora as nuvens usem `frame * 0.3` para movimento, o tamanho e posição inicial usam `i % 3`, o que é determinístico mas pode não ser o ideal.

**Impacto:**
- Nuvens podem parecer repetitivas
- Padrão previsível

**Solução:**
Usar seed aleatório fixo para cada nuvem:
```typescript
const cloudSeed = i * 12345; // Seed fixo por nuvem
const cloudScale = 0.8 + (cloudSeed % 3) * 0.2;
```

---

### Bug #14: Filtro de Blur Pode Causar Performance Issues
**Severidade:** BAIXA  
**Arquivo:** `src/game/renderer3d.ts` (linhas 234, 385)

**Descrição:**
O uso de `ctx.filter = 'blur(6px)'` para sombras pode ser pesado em dispositivos móveis.

**Código problemático:**
```typescript
ctx.filter = 'blur(6px)';
ctx.beginPath();
ctx.ellipse(8, 15, 50, 25, 0, 0, Math.PI * 2);
ctx.fill();
ctx.filter = 'none';
```

**Impacto:**
- Performance degradada em mobile
- FPS pode cair abaixo de 60
- Bateria consumida mais rápido

**Solução:**
Usar gradientes radiais em vez de blur:
```typescript
const shadowGrad = ctx.createRadialGradient(8, 15, 0, 8, 15, 50);
shadowGrad.addColorStop(0, 'rgba(0, 0, 0, 0.4)');
shadowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
ctx.fillStyle = shadowGrad;
ctx.beginPath();
ctx.ellipse(8, 15, 50, 25, 0, 0, Math.PI * 2);
ctx.fill();
```

---

### Bug #15: Guardar de Trânsito Não é Renderizado
**Severidade:** BAIXA  
**Arquivo:** `src/App.tsx` e `src/game/renderer3d.ts`

**Descrição:**
O código do App.tsx tem lógica para mostrar o guarda de trânsito (`state.mostrarGuarda`), mas o renderer3D não recebe esse parâmetro.

**Código problemático:**
```typescript
// App.tsx
state.mostrarGuarda = fase === 0;
state.mensagemGuarda = fase === 0 ? 'Dirija até a palavra certa!' : '';

// renderer3d.ts - Função não recebe esses parâmetros!
export function renderizar3D(
  ctx, vagas, obstaculos, carro, faseAtual, vagaAtual, 
  particulas, frame, vagaDestacada, opacidadeTransicao
) {
  // ← Faltam: mostrarGuarda, mensagemGuarda
}
```

**Impacto:**
- Guarda de trânsito nunca aparece
- Dicas visuais não funcionam
- Tutorial inicial incompleto

**Solução:**
Adicionar parâmetros ao renderer3D:
```typescript
export function renderizar3D(
  // ... parâmetros existentes
  mostrarGuarda: boolean = false,
  mensagemGuarda: string = ''
) {
  if (mostrarGuarda) {
    desenharGuarda(ctx, 820, 260, frame, mensagemGuarda);
  }
}
```

---

## 📊 Resumo dos Bugs

| Severidade | Quantidade | Descrição |
|------------|------------|-----------|
| 🔴 CRÍTICA | 4 | Quebram funcionalidade principal |
| 🟠 IMPORTANTE | 6 | Degradam significativamente a experiência |
| 🟡 MENOR | 5 | Detalhes visuais/UX |
| **TOTAL** | **15** | |

---

## 🎯 Prioridade de Correção

### Fase 1: Bugs Críticos (Urgente)
1. Bug #1: Desincronização 2D/3D
2. Bug #2: Flickering da textura
3. Bug #3: Posição inicial do carro
4. Bug #4: Partículas em coords erradas

### Fase 2: Bugs Importantes (Alta prioridade)
5. Bug #5: Barra de progresso
6. Bug #6: Emoji fora do contexto 3D
7. Bug #7: Som de batida contínuo
8. Bug #8: Motor não para
9. Bug #9: Conquistas duplicadas
10. Bug #10: Estatísticas não resetam

### Fase 3: Bugs Menores (Média prioridade)
11. Bug #11: Ordenação de profundidade
12. Bug #12: Layout shopping
13. Bug #13: Nuvens repetitivas
14. Bug #14: Performance do blur
15. Bug #15: Guarda não renderizado

---

## 🔧 Recomendações Gerais

### Arquitetura
- **Separar lógica de renderização**: Criar camada de abstração entre coords 2D e 3D
- **Sistema de eventos**: Usar event emitter para sons e partículas
- **State management**: Considerar usar Zustand ou Redux para estado complexo

### Performance
- **Pré-renderizar texturas**: Usar canvas offscreen para elementos estáticos
- **Object pooling**: Reutilizar objetos de partículas em vez de criar/destruir
- **Level of detail**: Reduzir detalhes em dispositivos móveis

### Testes
- **Testes unitários**: Para funções de colisão e geração de fases
- **Testes visuais**: Comparar screenshots para detectar regressões visuais
- **Testes de performance**: Monitorar FPS em diferentes dispositivos

---

## 📝 Conclusão

O jogo possui uma base sólida, mas a transição para 3D isométrico introduziu bugs críticos de sincronização entre lógica e renderização. Os bugs mais urgentes são:

1. **Desalinhamento 2D/3D** - Afeta toda a jogabilidade
2. **Flickering visual** - Degrada experiência visual
3. **Partículas desalinhadas** - Efeitos visuais quebrados

Recomenda-se corrigir os bugs críticos antes de adicionar novas funcionalidades.

---

**Relatório gerado automaticamente**  
**Próxima análise:** Após correção dos bugs críticos
