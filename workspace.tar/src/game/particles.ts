/**
 * Sistema de Partículas do Palavra a bordo
 * Gerencia efeitos visuais: fumaça, confetes, estrelas, marcas de pneu
 */

export interface Particula {
  x: number;
  y: number;
  vx: number;
  vy: number;
  vida: number;
  vidaMax: number;
  cor: string;
  tamanho: number;
  rotacao?: number;
  rotacaoVelocidade?: number;
  tipo: 'fumaca' | 'confete' | 'estrela' | 'faísca';
  opacidade: number;
}

export interface MarcaPneu {
  x: number;
  y: number;
  angulo: number;
  opacidade: number;
}

export class SistemaParticulas {
  particulas: Particula[] = [];
  marcasPneu: MarcaPneu[] = [];
  maxMarcasPneu = 200;

  /**
   * Adiciona fumaça/poeira ao acelerar ou frear
   */
  adicionarFumaca(x: number, y: number, quantidade: number = 3) {
    for (let i = 0; i < quantidade; i++) {
      this.particulas.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 10,
        vx: (Math.random() - 0.5) * 1.5,
        vy: -Math.random() * 1.5 - 0.5,
        vida: 0,
        vidaMax: 40 + Math.random() * 20,
        cor: `rgba(${150 + Math.random() * 50}, ${150 + Math.random() * 50}, ${150 + Math.random() * 50}`,
        tamanho: 3 + Math.random() * 4,
        tipo: 'fumaca',
        opacidade: 0.6
      });
    }
  }

  /**
   * Adiciona confetes ao acertar a fase
   */
  adicionarConfetes(x: number, y: number, quantidade: number = 50) {
    const cores = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F'];
    for (let i = 0; i < quantidade; i++) {
      const angulo = Math.random() * Math.PI * 2;
      const velocidade = 3 + Math.random() * 5;
      this.particulas.push({
        x: x,
        y: y,
        vx: Math.cos(angulo) * velocidade,
        vy: Math.sin(angulo) * velocidade - 3,
        vida: 0,
        vidaMax: 80 + Math.random() * 40,
        cor: cores[Math.floor(Math.random() * cores.length)],
        tamanho: 4 + Math.random() * 4,
        rotacao: Math.random() * Math.PI * 2,
        rotacaoVelocidade: (Math.random() - 0.5) * 0.3,
        tipo: 'confete',
        opacidade: 1
      });
    }
  }

  /**
   * Adiciona estrelas brilhantes ao acertar
   */
  adicionarEstrelas(x: number, y: number, quantidade: number = 20) {
    for (let i = 0; i < quantidade; i++) {
      const angulo = Math.random() * Math.PI * 2;
      const velocidade = 2 + Math.random() * 4;
      this.particulas.push({
        x: x,
        y: y,
        vx: Math.cos(angulo) * velocidade,
        vy: Math.sin(angulo) * velocidade - 2,
        vida: 0,
        vidaMax: 60 + Math.random() * 30,
        cor: '#FFD700',
        tamanho: 3 + Math.random() * 3,
        tipo: 'estrela',
        opacidade: 1
      });
    }
  }

  /**
   * Adiciona faíscas ao colidir
   */
  adicionarFaiscas(x: number, y: number, quantidade: number = 8) {
    for (let i = 0; i < quantidade; i++) {
      const angulo = Math.random() * Math.PI * 2;
      const velocidade = 2 + Math.random() * 3;
      this.particulas.push({
        x: x,
        y: y,
        vx: Math.cos(angulo) * velocidade,
        vy: Math.sin(angulo) * velocidade,
        vida: 0,
        vidaMax: 20 + Math.random() * 15,
        cor: '#FFA500',
        tamanho: 2 + Math.random() * 2,
        tipo: 'faísca',
        opacidade: 1
      });
    }
  }

  /**
   * Adiciona marca de pneu no asfalto
   */
  adicionarMarcaPneu(x: number, y: number, angulo: number) {
    this.marcasPneu.push({
      x: x,
      y: y,
      angulo: angulo,
      opacidade: 0.3
    });
    if (this.marcasPneu.length > this.maxMarcasPneu) {
      this.marcasPneu.shift();
    }
  }

  /**
   * Atualiza todas as partículas
   */
  atualizar() {
    // Atualiza partículas
    for (let i = this.particulas.length - 1; i >= 0; i--) {
      const p = this.particulas[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vida++;

      // Gravidade para confetes e estrelas
      if (p.tipo === 'confete' || p.tipo === 'estrela') {
        p.vy += 0.15;
      }

      // Rotação para confetes
      if (p.rotacao !== undefined && p.rotacaoVelocidade !== undefined) {
        p.rotacao += p.rotacaoVelocidade;
      }

      // Fumaça expande e desvanece
      if (p.tipo === 'fumaca') {
        p.tamanho += 0.15;
        p.opacidade = 0.6 * (1 - p.vida / p.vidaMax);
      }

      // Remove partículas mortas
      if (p.vida >= p.vidaMax) {
        this.particulas.splice(i, 1);
      }
    }

    // Desvanece marcas de pneu lentamente
    for (let i = this.marcasPneu.length - 1; i >= 0; i--) {
      this.marcasPneu[i].opacidade -= 0.001;
      if (this.marcasPneu[i].opacidade <= 0) {
        this.marcasPneu.splice(i, 1);
      }
    }
  }

  /**
   * Renderiza todas as partículas e marcas
   */
  renderizar(ctx: CanvasRenderingContext2D) {
    // Renderiza marcas de pneu primeiro (atrás de tudo)
    for (const marca of this.marcasPneu) {
      ctx.save();
      ctx.translate(marca.x, marca.y);
      ctx.rotate(marca.angulo);
      ctx.fillStyle = `rgba(30, 30, 30, ${marca.opacidade})`;
      ctx.fillRect(-3, -1, 6, 2);
      ctx.fillRect(-3, 3, 6, 2);
      ctx.restore();
    }

    // Renderiza partículas
    for (const p of this.particulas) {
      ctx.save();
      ctx.globalAlpha = p.opacidade;

      if (p.tipo === 'fumaca') {
        ctx.fillStyle = `${p.cor}, ${p.opacidade})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.tamanho, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.tipo === 'confete') {
        ctx.translate(p.x, p.y);
        if (p.rotacao !== undefined) ctx.rotate(p.rotacao);
        ctx.fillStyle = p.cor;
        ctx.fillRect(-p.tamanho / 2, -p.tamanho / 4, p.tamanho, p.tamanho / 2);
      } else if (p.tipo === 'estrela') {
        ctx.translate(p.x, p.y);
        ctx.fillStyle = p.cor;
        ctx.shadowColor = '#FFD700';
        ctx.shadowBlur = 8;
        this.desenharEstrela(ctx, 0, 0, 5, p.tamanho, p.tamanho / 2);
      } else if (p.tipo === 'faísca') {
        ctx.fillStyle = p.cor;
        ctx.shadowColor = '#FFA500';
        ctx.shadowBlur = 5;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.tamanho, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  /**
   * Desenha uma estrela de 5 pontas
   */
  private desenharEstrela(ctx: CanvasRenderingContext2D, cx: number, cy: number, pontas: number, raioExterno: number, raioInterno: number) {
    ctx.beginPath();
    for (let i = 0; i < pontas * 2; i++) {
      const raio = i % 2 === 0 ? raioExterno : raioInterno;
      const angulo = (i / (pontas * 2)) * Math.PI * 2 - Math.PI / 2;
      const x = cx + Math.cos(angulo) * raio;
      const y = cy + Math.sin(angulo) * raio;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
  }

  /**
   * Limpa todas as partículas
   */
  limpar() {
    this.particulas = [];
    this.marcasPneu = [];
  }
}
