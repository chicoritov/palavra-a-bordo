/**
 * Dados do Mini-Quiz de Consciência Fonológica
 * Contém perguntas específicas para cada palavra de cada fase
 */

export interface PerguntaQuiz {
  pergunta: string;
  opcoes: string[];
  correta: number; // Índice da opção correta (0, 1 ou 2)
}

/**
 * Array de perguntas para cada fase
 * Cada fase tem 3 perguntas específicas sobre a palavra daquela fase
 */
export const perguntasQuiz: Record<number, PerguntaQuiz[]> = {
  // Fase 1: GATO
  0: [
    {
      pergunta: "Na palavra GATO, qual é a segunda letra?",
      opcoes: ["G", "A", "T"],
      correta: 1
    },
    {
      pergunta: "GATO rima com qual palavra?",
      opcoes: ["PATO", "CASA", "SAPO"],
      correta: 0
    },
    {
      pergunta: "Se tirarmos o G de GATO, fica qual palavra?",
      opcoes: ["ATO", "GAT", "ATO"],
      correta: 0
    }
  ],

  // Fase 2: CASA
  1: [
    {
      pergunta: "Na palavra CASA, qual letra aparece duas vezes?",
      opcoes: ["C", "A", "S"],
      correta: 1
    },
    {
      pergunta: "CASA começa com o mesmo som de qual palavra?",
      opcoes: ["SACO", "BOLA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Quantas sílabas tem a palavra CASA?",
      opcoes: ["1 sílaba", "2 sílabas", "3 sílabas"],
      correta: 1
    }
  ],

  // Fase 3: SAPO
  2: [
    {
      pergunta: "SAPO tem o mesmo som inicial de qual palavra?",
      opcoes: ["PATO", "SACA", "BOLA"],
      correta: 1
    },
    {
      pergunta: "Na palavra SAPO, qual é a última letra?",
      opcoes: ["S", "A", "O"],
      correta: 2
    },
    {
      pergunta: "Se trocarmos o S pelo P em SAPO, fica qual palavra?",
      opcoes: ["PATO", "PAPO", "POCO"],
      correta: 1
    }
  ],

  // Fase 4: PATO
  3: [
    {
      pergunta: "PATO rima com qual palavra?",
      opcoes: ["GATO", "CASA", "SAPO"],
      correta: 0
    },
    {
      pergunta: "Na palavra PATO, quantas vogais existem?",
      opcoes: ["1 vogal", "2 vogais", "3 vogais"],
      correta: 1
    },
    {
      pergunta: "PATO começa com o mesmo som de qual palavra?",
      opcoes: ["BOLA", "PÉ", "MÃO"],
      correta: 1
    }
  ],

  // Fase 5: RATO
  4: [
    {
      pergunta: "RATO rima com qual palavra?",
      opcoes: ["CASA", "PRATO", "SAPO"],
      correta: 1
    },
    {
      pergunta: "Na palavra RATO, qual é a primeira letra?",
      opcoes: ["A", "T", "R"],
      correta: 2
    },
    {
      pergunta: "Se trocarmos o R pelo G em RATO, fica qual palavra?",
      opcoes: ["GATO", "GATA", "GOTA"],
      correta: 0
    }
  ],

  // Fase 6: VACA
  5: [
    {
      pergunta: "VACA rima com qual palavra?",
      opcoes: ["FACA", "CASA", "SAPO"],
      correta: 0
    },
    {
      pergunta: "Na palavra VACA, qual é a letra do meio?",
      opcoes: ["V", "A", "C"],
      correta: 2
    },
    {
      pergunta: "Se trocarmos o V pelo F em VACA, fica qual palavra?",
      opcoes: ["FACA", "FAMA", "FOCA"],
      correta: 0
    }
  ],

  // Fase 7: FACA
  6: [
    {
      pergunta: "FACA tem o mesmo som final de qual palavra?",
      opcoes: ["VACA", "BOLA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Na palavra FACA, quantas vezes aparece a letra A?",
      opcoes: ["1 vez", "2 vezes", "3 vezes"],
      correta: 1
    },
    {
      pergunta: "Quantas sílabas tem a palavra FACA?",
      opcoes: ["1 sílaba", "2 sílabas", "3 sílabas"],
      correta: 1
    }
  ],

  // Fase 8: DADO
  7: [
    {
      pergunta: "DADO começa com o mesmo som de qual palavra?",
      opcoes: ["DEDO", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra DADO, qual letra aparece duas vezes?",
      opcoes: ["A", "O", "D"],
      correta: 2
    },
    {
      pergunta: "Se trocarmos o D pelo R em DADO, fica qual palavra?",
      opcoes: ["RADO", "RARO", "RODA"],
      correta: 1
    }
  ],

  // Fase 9: MAÇÃ
  8: [
    {
      pergunta: "MAÇã rima com qual palavra?",
      opcoes: ["BANANA", "LARANJA", "BETERRABA"],
      correta: 0
    },
    {
      pergunta: "Na palavra MAÇÃ, qual é a letra que tem acento?",
      opcoes: ["M", "A", "Ç"],
      correta: 2
    },
    {
      pergunta: "MAÇÃ começa com o mesmo som de qual palavra?",
      opcoes: ["MESA", "CAMA", "PATO"],
      correta: 0
    }
  ],

  // Fase 10: BANANA
  9: [
    {
      pergunta: "Na palavra BANANA, quantas vezes aparece a letra A?",
      opcoes: ["2 vezes", "3 vezes", "4 vezes"],
      correta: 1
    },
    {
      pergunta: "BANANA tem quantas sílabas?",
      opcoes: ["2 sílabas", "3 sílabas", "4 sílabas"],
      correta: 1
    },
    {
      pergunta: "BANANA rima com qual palavra?",
      opcoes: ["MAÇÃ", "LARANJA", "PERA"],
      correta: 0
    }
  ],

  // Fase 11: NAVIO
  10: [
    {
      pergunta: "NAVIO começa com o mesmo som de qual palavra?",
      opcoes: ["Nuvem", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra NAVIO, qual é a última letra?",
      opcoes: ["N", "A", "O"],
      correta: 2
    },
    {
      pergunta: "Quantas vogais tem a palavra NAVIO?",
      opcoes: ["2 vogais", "3 vogais", "4 vogais"],
      correta: 1
    }
  ],

  // Fase 12: AVIÃO
  11: [
    {
      pergunta: "AVIÃO termina com o mesmo som de qual palavra?",
      opcoes: ["MÃO", "PÉ", "BOCA"],
      correta: 0
    },
    {
      pergunta: "Na palavra AVIÃO, qual letra tem acento?",
      opcoes: ["A", "I", "O"],
      correta: 1
    },
    {
      pergunta: "AVIÃO tem quantas sílabas?",
      opcoes: ["2 sílabas", "3 sílabas", "4 sílabas"],
      correta: 1
    }
  ],

  // Fase 13: LÁPIS
  12: [
    {
      pergunta: "LÁPIS começa com o mesmo som de qual palavra?",
      opcoes: ["LARANJA", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra LÁPIS, qual letra tem acento?",
      opcoes: ["L", "A", "I"],
      correta: 1
    },
    {
      pergunta: "LÁPIS termina com o mesmo som de qual palavra?",
      opcoes: ["PAÍS", "MESA", "BOLA"],
      correta: 0
    }
  ],

  // Fase 14: TAMBOR
  13: [
    {
      pergunta: "TAMBOR termina com o mesmo som de qual palavra?",
      opcoes: ["TAMBOR", "AMOR", "DOR"],
      correta: 1
    },
    {
      pergunta: "Na palavra TAMBOR, quantas sílabas existem?",
      opcoes: ["2 sílabas", "3 sílabas", "4 sílabas"],
      correta: 1
    },
    {
      pergunta: "TAMBOR começa com o mesmo som de qual palavra?",
      opcoes: ["TAMPA", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 15: QUATRO
  14: [
    {
      pergunta: "QUATRO começa com o mesmo som de qual palavra?",
      opcoes: ["QUADRO", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra QUATRO, qual é a segunda letra?",
      opcoes: ["Q", "U", "A"],
      correta: 1
    },
    {
      pergunta: "QUATRO rima com qual palavra?",
      opcoes: ["QUADRO", "TRÊS", "CINCO"],
      correta: 0
    }
  ],

  // Fase 16: JACARÉ
  15: [
    {
      pergunta: "JACARÉ termina com o mesmo som de qual palavra?",
      opcoes: ["PÉ", "MÃO", "BOCA"],
      correta: 0
    },
    {
      pergunta: "Na palavra JACARÉ, qual letra tem acento?",
      opcoes: ["A", "E", "É"],
      correta: 2
    },
    {
      pergunta: "JACARÉ tem quantas sílabas?",
      opcoes: ["2 sílabas", "3 sílabas", "4 sílabas"],
      correta: 1
    }
  ],

  // Fase 17: TARTARUGA
  16: [
    {
      pergunta: "TARTARUGA começa com o mesmo som de qual palavra?",
      opcoes: ["TATU", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra TARTARUGA, quantas vezes aparece a letra T?",
      opcoes: ["2 vezes", "3 vezes", "4 vezes"],
      correta: 1
    },
    {
      pergunta: "TARTARUGA termina com o mesmo som de qual palavra?",
      opcoes: ["AMIGA", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 18: XADREZ
  17: [
    {
      pergunta: "XADREZ começa com o mesmo som de qual palavra?",
      opcoes: ["XAROPE", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra XADREZ, qual é a última letra?",
      opcoes: ["X", "E", "Z"],
      correta: 2
    },
    {
      pergunta: "XADREZ tem quantas sílabas?",
      opcoes: ["2 sílabas", "3 sílabas", "4 sílabas"],
      correta: 0
    }
  ],

  // Fase 19: CACHORRO
  18: [
    {
      pergunta: "CACHORRO começa com o mesmo som de qual palavra?",
      opcoes: ["CAMA", "BOLA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Na palavra CACHORRO, quantas vezes aparece a letra R?",
      opcoes: ["1 vez", "2 vezes", "3 vezes"],
      correta: 1
    },
    {
      pergunta: "CACHORRO rima com qual palavra?",
      opcoes: ["MORRO", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 20: CAVALO
  19: [
    {
      pergunta: "CAVALO começa com o mesmo som de qual palavra?",
      opcoes: ["CAMA", "BOLA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Na palavra CAVALO, qual é a letra do meio?",
      opcoes: ["C", "V", "L"],
      correta: 1
    },
    {
      pergunta: "CAVALO rima com qual palavra?",
      opcoes: ["PALAVRA", "BOLA", "MESA"],
      correta: 0
    }
  ],

  // Fase 21: PEIXE
  20: [
    {
      pergunta: "PEIXE começa com o mesmo som de qual palavra?",
      opcoes: ["PÉ", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra PEIXE, qual é a última letra?",
      opcoes: ["P", "E", "X"],
      correta: 1
    },
    {
      pergunta: "PEIXE rima com qual palavra?",
      opcoes: ["LEITE", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 22: LEÃO
  21: [
    {
      pergunta: "LEÃO termina com o mesmo som de qual palavra?",
      opcoes: ["MÃO", "PÉ", "BOCA"],
      correta: 0
    },
    {
      pergunta: "Na palavra LEÃO, qual letra tem acento?",
      opcoes: ["L", "E", "Ã"],
      correta: 2
    },
    {
      pergunta: "LEÃO tem quantas sílabas?",
      opcoes: ["1 sílaba", "2 sílabas", "3 sílabas"],
      correta: 1
    }
  ],

  // Fase 23: PÁSSARO
  22: [
    {
      pergunta: "PÁSSARO começa com o mesmo som de qual palavra?",
      opcoes: ["PATO", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra PÁSSARO, qual letra tem acento?",
      opcoes: ["P", "Á", "O"],
      correta: 1
    },
    {
      pergunta: "PÁSSARO termina com o mesmo som de qual palavra?",
      opcoes: ["TEATRO", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 24: BORBOLETA
  23: [
    {
      pergunta: "BORBOLETA começa com o mesmo som de qual palavra?",
      opcoes: ["BOLA", "CASA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Na palavra BORBOLETA, quantas vezes aparece a letra B?",
      opcoes: ["1 vez", "2 vezes", "3 vezes"],
      correta: 1
    },
    {
      pergunta: "BORBOLETA tem quantas sílabas?",
      opcoes: ["3 sílabas", "4 sílabas", "5 sílabas"],
      correta: 1
    }
  ],

  // Fase 25: PÃO
  24: [
    {
      pergunta: "PÃO termina com o mesmo som de qual palavra?",
      opcoes: ["MÃO", "PÉ", "BOCA"],
      correta: 0
    },
    {
      pergunta: "Na palavra PÃO, qual letra tem acento?",
      opcoes: ["P", "A", "Ã"],
      correta: 2
    },
    {
      pergunta: "PÃO rima com qual palavra?",
      opcoes: ["IRMÃO", "PÉ", "BOCA"],
      correta: 0
    }
  ],

  // Fase 26: QUEIJO
  25: [
    {
      pergunta: "QUEIJO começa com o mesmo som de qual palavra?",
      opcoes: ["QUEBRA", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra QUEIJO, qual é a segunda letra?",
      opcoes: ["Q", "U", "E"],
      correta: 1
    },
    {
      pergunta: "QUEIJO rima com qual palavra?",
      opcoes: ["BEIJO", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 27: PIZZA
  26: [
    {
      pergunta: "PIZZA começa com o mesmo som de qual palavra?",
      opcoes: ["PIPA", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra PIZZA, quantas vezes aparece a letra Z?",
      opcoes: ["1 vez", "2 vezes", "3 vezes"],
      correta: 1
    },
    {
      pergunta: "PIZZA rima com qual palavra?",
      opcoes: ["PIZA", "BOLA", "CASA"],
      correta: 0
    }
  ],
  // Fase 28: LIVRO
  27: [
    {
      pergunta: "LIVRO começa com o mesmo som de qual palavra?",
      opcoes: ["LÁPIS", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra LIVRO, qual é a letra do meio?",
      opcoes: ["L", "V", "R"],
      correta: 1
    },
    {
      pergunta: "LIVRO rima com qual palavra?",
      opcoes: ["NILO", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 29: TINTA
  28: [
    {
      pergunta: "TINTA começa com o mesmo som de qual palavra?",
      opcoes: ["TATU", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra TINTA, quantas vezes aparece a letra T?",
      opcoes: ["1 vez", "2 vezes", "3 vezes"],
      correta: 1
    },
    {
      pergunta: "TINTA rima com qual palavra?",
      opcoes: ["PINTA", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 30: BOLA
  29: [
    {
      pergunta: "BOLA começa com o mesmo som de qual palavra?",
      opcoes: ["BOLA", "CASA", "MESA"],
      correta: 0
    },
    {
      pergunta: "Na palavra BOLA, qual é a segunda letra?",
      opcoes: ["B", "O", "L"],
      correta: 1
    },
    {
      pergunta: "BOLA rima com qual palavra?",
      opcoes: ["SACOLA", "CASA", "MESA"],
      correta: 0
    }
  ],

  // Fase 31: CHAVE
  30: [
    {
      pergunta: "CHAVE começa com o mesmo som de qual palavra?",
      opcoes: ["CHUVA", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra CHAVE, qual é a última letra?",
      opcoes: ["C", "A", "E"],
      correta: 2
    },
    {
      pergunta: "CHAVE rima com qual palavra?",
      opcoes: ["CHAVE", "NAVE", "BOLA"],
      correta: 1
    }
  ],

  // Fase 32: CHUVA
  31: [
    {
      pergunta: "CHUVA começa com o mesmo som de qual palavra?",
      opcoes: ["CHAVE", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra CHUVA, qual é a letra do meio?",
      opcoes: ["C", "U", "V"],
      correta: 1
    },
    {
      pergunta: "CHUVA rima com qual palavra?",
      opcoes: ["CHUVA", "LUVA", "BOLA"],
      correta: 1
    }
  ],

  // Fase 33: ACHOCOLATADO
  32: [
    {
      pergunta: "ACHOCOLATADO é uma palavra grande. Quantas sílabas ela tem?",
      opcoes: ["4 sílabas", "5 sílabas", "6 sílabas"],
      correta: 1
    },
    {
      pergunta: "ACHOCOLATADO começa com o mesmo som de qual palavra?",
      opcoes: ["ABACAXI", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra ACHOCOLATADO, qual é a última letra?",
      opcoes: ["A", "O", "D"],
      correta: 2
    }
  ],

  // Fase 34: MENINO
  33: [
    {
      pergunta: "MENINO começa com o mesmo som de qual palavra?",
      opcoes: ["MESA", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra MENINO, qual letra aparece duas vezes?",
      opcoes: ["M", "E", "N"],
      correta: 2
    },
    {
      pergunta: "MENINO rima com qual palavra?",
      opcoes: ["MENINO", "DESTINO", "BOLA"],
      correta: 1
    }
  ],

  // Fase 35: ARCO-ÍRIS
  34: [
    {
      pergunta: "ARCO-ÍRIS começa com o mesmo som de qual palavra?",
      opcoes: ["ARCO", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra ARCO-ÍRIS, qual letra tem acento?",
      opcoes: ["A", "I", "Í"],
      correta: 2
    },
    {
      pergunta: "ARCO-ÍRIS termina com o mesmo som de qual palavra?",
      opcoes: ["PAÍS", "BOLA", "CASA"],
      correta: 0
    }
  ],

  // Fase 36: PASSARINHO
  35: [
    {
      pergunta: "PASSARINHO começa com o mesmo som de qual palavra?",
      opcoes: ["PATO", "BOLA", "CASA"],
      correta: 0
    },
    {
      pergunta: "Na palavra PASSARINHO, qual é a última sílaba?",
      opcoes: ["PAS", "SA", "RINHO"],
      correta: 2
    },
    {
      pergunta: "PASSARINHO rima com qual palavra?",
      opcoes: ["CARRINHO", "BOLA", "CASA"],
      correta: 0
    }
  ]
};

/**
 * Função para obter perguntas de uma fase
 * Se a fase não tiver perguntas específicas, retorna perguntas genéricas
 */
export function getPerguntasFase(faseIndex: number): PerguntaQuiz[] {
  return perguntasQuiz[faseIndex] || perguntasQuiz[0];
}
