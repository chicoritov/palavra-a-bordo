/**
 * Sistema de Renderização 3D Isométrico
 * Transforma coordenadas 2D em perspectiva isométrica 3D
 */

// Ângulo isométrico (30 graus para visual clássico)
const ISO_ANGLE = Math.PI / 6; // 30 graus
const ISO_COS = Math.cos(ISO_ANGLE);
const ISO_SIN = Math.sin(ISO_ANGLE);

/**
 * Converte coordenadas do mundo (x, y, z) para tela isométrica
 */
export function worldToIso(x: number, y: number, z: number = 0): { x: number; y: number } {
  return {
    x: (x - y) * ISO_COS,
    y: (x + y) * ISO_SIN - z
  };
}

/**
 * Converte coordenadas de tela para mundo (aproximado)
 */
export function isoToWorld(screenX: number, screenY: number): { x: number; y: number } {
  const x = (screenX / ISO_COS + screenY / ISO_SIN) / 2;
  const y = (screenY / ISO_SIN - screenX / ISO_COS) / 2;
  return { x, y };
}

/**
 * Aplica transformação isométrica ao contexto
 */
export function applyIsoTransform(ctx: CanvasRenderingContext2D, centerX: number, centerY: number) {
  ctx.translate(centerX, centerY);
  ctx.scale(1, 0.5); // Achata para dar perspectiva
  ctx.rotate(Math.PI / 4); // Rotaciona 45 graus
}

/**
 * Remove transformação isométrica
 */
export function resetIsoTransform(ctx: CanvasRenderingContext2D) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
}

/**
 * Calcula profundidade para ordenação (painter's algorithm)
 */
export function calculateDepth(x: number, y: number, z: number = 0): number {
  return x + y - z * 2;
}

/**
 * Cria gradiente 3D para superfícies
 */
export function create3DGradient(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, width: number, height: number,
  baseColor: string,
  direction: 'top' | 'side' | 'front' = 'top'
): CanvasGradient {
  const grad = ctx.createLinearGradient(x, y, x + width, y + height);
  
  let lightFactor = 1.0;
  let darkFactor = 0.7;
  
  if (direction === 'side') {
    lightFactor = 0.8;
    darkFactor = 0.5;
  } else if (direction === 'front') {
    lightFactor = 0.9;
    darkFactor = 0.6;
  }
  
  grad.addColorStop(0, lightenColor(baseColor, lightFactor));
  grad.addColorStop(1, darkenColor(baseColor, darkFactor));
  
  return grad;
}

/**
 * Clareia uma cor
 */
function lightenColor(color: string, factor: number): string {
  const rgb = parseColor(color);
  return `rgb(${Math.min(255, rgb.r + (255 - rgb.r) * factor)}, ${Math.min(255, rgb.g + (255 - rgb.g) * factor)}, ${Math.min(255, rgb.b + (255 - rgb.b) * factor)})`;
}

/**
 * Escurece uma cor
 */
export function darkenColor(color: string, factor: number): string {
  const rgb = parseColor(color);
  return `rgb(${rgb.r * factor}, ${rgb.g * factor}, ${rgb.b * factor})`;
}

/**
 * Parseia cor para RGB
 */
function parseColor(color: string): { r: number; g: number; b: number } {
  if (color.startsWith('#')) {
    const hex = color.slice(1);
    return {
      r: parseInt(hex.slice(0, 2), 16),
      g: parseInt(hex.slice(2, 4), 16),
      b: parseInt(hex.slice(4, 6), 16)
    };
  }
  // Fallback
  return { r: 128, g: 128, b: 128 };
}

/**
 * Desenha caixa 3D isométrica
 */
export function drawIsoBox(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, z: number,
  width: number, height: number, depth: number,
  color: string
) {
  const isoPos = worldToIso(x, y, z);
  
  // Face superior (mais clara)
  ctx.fillStyle = lightenColor(color, 0.3);
  ctx.beginPath();
  ctx.moveTo(isoPos.x, isoPos.y);
  ctx.lineTo(isoPos.x + width * ISO_COS, isoPos.y + width * ISO_SIN);
  ctx.lineTo(isoPos.x + width * ISO_COS - height * ISO_COS, isoPos.y + width * ISO_SIN + height * ISO_SIN);
  ctx.lineTo(isoPos.x - height * ISO_COS, isoPos.y + height * ISO_SIN);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = darkenColor(color, 0.5);
  ctx.lineWidth = 1;
  ctx.stroke();
  
  // Face direita (média)
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(isoPos.x + width * ISO_COS, isoPos.y + width * ISO_SIN);
  ctx.lineTo(isoPos.x + width * ISO_COS, isoPos.y + width * ISO_SIN + depth);
  ctx.lineTo(isoPos.x + width * ISO_COS - height * ISO_COS, isoPos.y + width * ISO_SIN + height * ISO_SIN + depth);
  ctx.lineTo(isoPos.x + width * ISO_COS - height * ISO_COS, isoPos.y + width * ISO_SIN + height * ISO_SIN);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  
  // Face frontal (mais escura)
  ctx.fillStyle = darkenColor(color, 0.7);
  ctx.beginPath();
  ctx.moveTo(isoPos.x - height * ISO_COS, isoPos.y + height * ISO_SIN);
  ctx.lineTo(isoPos.x + width * ISO_COS - height * ISO_COS, isoPos.y + width * ISO_SIN + height * ISO_SIN);
  ctx.lineTo(isoPos.x + width * ISO_COS - height * ISO_COS, isoPos.y + width * ISO_SIN + height * ISO_SIN + depth);
  ctx.lineTo(isoPos.x - height * ISO_COS, isoPos.y + height * ISO_SIN + depth);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
}

/**
 * Desenha sombra projetada
 */
export function drawProjectedShadow(
  ctx: CanvasRenderingContext2D,
  x: number, y: number,
  width: number, height: number,
  elevation: number,
  lightAngle: number = Math.PI / 4
) {
  const shadowOffset = elevation * 0.5;
  const shadowX = x + Math.cos(lightAngle) * shadowOffset;
  const shadowY = y + Math.sin(lightAngle) * shadowOffset;
  
  ctx.save();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.filter = 'blur(4px)';
  
  const isoPos = worldToIso(shadowX, shadowY, 0);
  ctx.beginPath();
  ctx.ellipse(isoPos.x, isoPos.y, width * ISO_COS * 0.8, height * ISO_SIN * 0.8, 0, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.restore();
}
