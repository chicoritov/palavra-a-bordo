/**
 * Módulo de Renderização do Palavra a bordo
 * Desenha: carros isométricos, estacionamento, guarda de trânsito, efeitos visuais
 */

import { Vaga, Obstaculo, Carro, TexturaPonto, fases } from './data';
import { SistemaParticulas } from './particles';

function escurecerCor(cor: string, fator: number): string {
  const r = parseInt(cor.slice(1, 3), 16);
  const g = parseInt(cor.slice(3, 5), 16);
  const b = parseInt(cor.slice(5, 7), 16);
  return `rgb(${Math.floor(r * fator)},${Math.floor(g * fator)},${Math.floor(b * fator)})`;
}

function clarearCor(cor: string, fator: number): string {
  const r = parseInt(cor.slice(1, 3), 16);
  const g = parseInt(cor.slice(3, 5), 16);
  const b = parseInt(cor.slice(5, 7), 16);
  return `rgb(${Math.min(255, Math.floor(r + (255 - r) * fator))},${Math.min(255, Math.floor(g + (255 - g) * fator))},${Math.min(255, Math.floor(b + (255 - b) * fator))})`;
}

function desenharRoda(ctx: CanvasRenderingContext2D, x: number, y: number, raio: number) {
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.arc(x, y, raio, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#888';
  ctx.beginPath();
  ctx.arc(x, y, raio * 0.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#333';
  ctx.beginPath();
  ctx.arc(x, y, raio * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#666';
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const ang = (i / 5) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(ang) * raio * 0.6, y + Math.sin(ang) * raio * 0.6);
    ctx.stroke();
  }
}

function desenharSombra(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, direcao: string = 'direita') {
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  // Sombra dinâmica baseada na direção
  let offsetX = 8, offsetY = 5;
  if (direcao === 'esquerda') offsetX = -8;
  else if (direcao === 'cima') offsetY = -5;
  else if (direcao === 'baixo') offsetY = 8;
  ctx.beginPath();
  ctx.ellipse(cx + offsetX, cy + h / 2 + offsetY, w / 2 + 5, h / 2 + 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function desenharEsportivo(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-50, 10); ctx.lineTo(-45, -15); ctx.lineTo(-20, -22);
  ctx.lineTo(20, -22); ctx.lineTo(45, -15); ctx.lineTo(50, 10);
  ctx.lineTo(48, 22); ctx.lineTo(-48, 22);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  // Brilho superior
  ctx.fillStyle = clarearCor(cor, 0.2);
  ctx.beginPath();
  ctx.moveTo(-20, -22); ctx.lineTo(20, -22); ctx.lineTo(15, -18); ctx.lineTo(-15, -18);
  ctx.closePath(); ctx.fill();

  ctx.fillStyle = escurecerCor(cor, 0.9);
  ctx.beginPath();
  ctx.moveTo(20, -22); ctx.lineTo(45, -15); ctx.lineTo(50, 10);
  ctx.lineTo(25, 5); ctx.lineTo(15, -10);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = escurecerCor(cor, 0.85);
  ctx.beginPath();
  ctx.moveTo(-25, -15); ctx.lineTo(-15, -22); ctx.lineTo(15, -22);
  ctx.lineTo(25, -15); ctx.lineTo(20, -10); ctx.lineTo(-20, -10);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  // Vidros
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.moveTo(15, -10); ctx.lineTo(25, -15); ctx.lineTo(20, -22);
  ctx.lineTo(10, -22); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-15, -10); ctx.lineTo(-25, -15); ctx.lineTo(-20, -22);
  ctx.lineTo(-10, -22); ctx.closePath(); ctx.fill();

  // Faróis
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.beginPath();
  ctx.moveTo(45, -10); ctx.lineTo(50, -5); ctx.lineTo(48, 0); ctx.lineTo(42, -5);
  ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(45, 5); ctx.lineTo(50, 10); ctx.lineTo(48, 15); ctx.lineTo(42, 10);
  ctx.closePath(); ctx.fill();
  ctx.shadowBlur = 0;

  // Lanternas traseiras
  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-50, -12, 4, 8);
  ctx.fillRect(-50, 4, 4, 8);

  desenharRoda(ctx, -30, 22, 8); desenharRoda(ctx, 30, 22, 8);
  desenharRoda(ctx, -30, -18, 8); desenharRoda(ctx, 30, -18, 8);
  ctx.restore();
}

function desenharSeda(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-50, 15); ctx.lineTo(-50, -10); ctx.lineTo(-35, -20);
  ctx.lineTo(20, -20); ctx.lineTo(40, -15); ctx.lineTo(50, -5);
  ctx.lineTo(50, 15); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  ctx.fillStyle = clarearCor(cor, 0.15);
  ctx.beginPath();
  ctx.moveTo(-35, -20); ctx.lineTo(20, -20); ctx.lineTo(15, -17); ctx.lineTo(-30, -17);
  ctx.closePath(); ctx.fill();

  ctx.fillStyle = escurecerCor(cor, 0.9);
  ctx.beginPath();
  ctx.moveTo(20, -20); ctx.lineTo(40, -15); ctx.lineTo(50, -5);
  ctx.lineTo(25, -5); ctx.lineTo(15, -15);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = escurecerCor(cor, 0.85);
  ctx.beginPath();
  ctx.moveTo(-30, -20); ctx.lineTo(-20, -28); ctx.lineTo(10, -28);
  ctx.lineTo(20, -20); ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(12, -18); ctx.lineTo(20, -20); ctx.lineTo(10, -28);
  ctx.lineTo(5, -28); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-5, -18); ctx.lineTo(10, -18); ctx.lineTo(5, -28);
  ctx.lineTo(-10, -28); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-15, -18); ctx.lineTo(-5, -18); ctx.lineTo(-10, -28);
  ctx.lineTo(-20, -28); ctx.closePath(); ctx.fill();

  ctx.fillStyle = '#333';
  ctx.fillRect(45, -3, 5, 12);

  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 8;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(47, -8, 3, 5); ctx.fillRect(47, 8, 3, 5);
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-50, -8, 3, 6); ctx.fillRect(-50, 2, 3, 6);

  desenharRoda(ctx, -30, 18, 9); desenharRoda(ctx, 30, 18, 9);
  desenharRoda(ctx, -30, -18, 9); desenharRoda(ctx, 30, -18, 9);
  ctx.restore();
}

function desenharHatch(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-45, 15); ctx.lineTo(-45, -15); ctx.lineTo(-25, -22);
  ctx.lineTo(15, -22); ctx.lineTo(35, -15); ctx.lineTo(45, -5);
  ctx.lineTo(45, 15); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  ctx.fillStyle = clarearCor(cor, 0.15);
  ctx.beginPath();
  ctx.moveTo(-25, -22); ctx.lineTo(15, -22); ctx.lineTo(10, -19); ctx.lineTo(-20, -19);
  ctx.closePath(); ctx.fill();

  ctx.fillStyle = escurecerCor(cor, 0.9);
  ctx.beginPath();
  ctx.moveTo(15, -22); ctx.lineTo(35, -15); ctx.lineTo(45, -5);
  ctx.lineTo(20, -5); ctx.lineTo(10, -15);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = escurecerCor(cor, 0.85);
  ctx.beginPath();
  ctx.moveTo(-25, -22);
  ctx.quadraticCurveTo(-20, -30, 0, -30);
  ctx.quadraticCurveTo(15, -30, 15, -22);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(10, -18); ctx.lineTo(15, -22); ctx.lineTo(5, -28);
  ctx.lineTo(0, -28); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-5, -18); ctx.lineTo(8, -18); ctx.lineTo(0, -28);
  ctx.lineTo(-12, -28); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-15, -18); ctx.lineTo(-5, -18); ctx.lineTo(-12, -28);
  ctx.lineTo(-22, -28); ctx.closePath(); ctx.fill();

  ctx.fillStyle = '#222';
  ctx.fillRect(40, -8, 5, 16);

  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 8;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.beginPath();
  ctx.moveTo(40, -12); ctx.lineTo(45, -10); ctx.lineTo(45, -5); ctx.lineTo(38, -8);
  ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(40, 8); ctx.lineTo(45, 10); ctx.lineTo(45, 5); ctx.lineTo(38, 8);
  ctx.closePath(); ctx.fill();
  ctx.shadowBlur = 0;

  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-45, -12, 3, 8); ctx.fillRect(-45, 4, 3, 8);

  desenharRoda(ctx, -28, 18, 9); desenharRoda(ctx, 28, 18, 9);
  desenharRoda(ctx, -28, -18, 9); desenharRoda(ctx, 28, -18, 9);
  ctx.restore();
}

function desenharCompacto(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-40, 15); ctx.lineTo(-40, -12); ctx.lineTo(-25, -20);
  ctx.lineTo(15, -20); ctx.lineTo(30, -12); ctx.lineTo(40, -5);
  ctx.lineTo(40, 15); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  ctx.fillStyle = clarearCor(cor, 0.15);
  ctx.beginPath();
  ctx.moveTo(-25, -20); ctx.lineTo(15, -20); ctx.lineTo(10, -17); ctx.lineTo(-20, -17);
  ctx.closePath(); ctx.fill();

  ctx.fillStyle = escurecerCor(cor, 0.9);
  ctx.beginPath();
  ctx.moveTo(15, -20); ctx.lineTo(30, -12); ctx.lineTo(40, -5);
  ctx.lineTo(18, -5); ctx.lineTo(10, -12);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = escurecerCor(cor, 0.85);
  ctx.beginPath();
  ctx.moveTo(-25, -20);
  ctx.quadraticCurveTo(-20, -28, -5, -28);
  ctx.quadraticCurveTo(10, -28, 15, -20);
  ctx.closePath(); ctx.fill(); ctx.stroke();

  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(8, -18); ctx.lineTo(15, -20); ctx.lineTo(8, -26);
  ctx.lineTo(2, -26); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-5, -18); ctx.lineTo(6, -18); ctx.lineTo(0, -26);
  ctx.lineTo(-10, -26); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-12, -18); ctx.lineTo(-5, -18); ctx.lineTo(-10, -26);
  ctx.lineTo(-20, -26); ctx.closePath(); ctx.fill();

  ctx.fillStyle = '#333';
  ctx.fillRect(36, -6, 4, 12);

  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 8;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(37, -10, 3, 5); ctx.fillRect(37, 5, 3, 5);
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-40, -10, 3, 6); ctx.fillRect(-40, 4, 3, 6);

  desenharRoda(ctx, -25, 18, 8); desenharRoda(ctx, 25, 18, 8);
  desenharRoda(ctx, -25, -18, 8); desenharRoda(ctx, 25, -18, 8);
  ctx.restore();
}

/**
 * Caminhonete/Pickup - veículo maior e mais robusto
 */
function desenharCaminhonete(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 110, escY = h / 60;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo principal
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-55, 18); ctx.lineTo(-55, -15); ctx.lineTo(-30, -25);
  ctx.lineTo(25, -25); ctx.lineTo(50, -18); ctx.lineTo(55, -8);
  ctx.lineTo(55, 18); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  // Brilho superior
  ctx.fillStyle = clarearCor(cor, 0.2);
  ctx.beginPath();
  ctx.moveTo(-30, -25); ctx.lineTo(25, -25); ctx.lineTo(20, -22); ctx.lineTo(-25, -22);
  ctx.closePath(); ctx.fill();

  // Cabine
  ctx.fillStyle = escurecerCor(cor, 0.85);
  ctx.beginPath();
  ctx.moveTo(-30, -25); ctx.lineTo(-20, -35); ctx.lineTo(15, -35);
  ctx.lineTo(25, -25); ctx.closePath(); ctx.fill(); ctx.stroke();

  // Vidros
  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(-15, -23); ctx.lineTo(-10, -32); ctx.lineTo(5, -32);
  ctx.lineTo(10, -23); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-25, -23); ctx.lineTo(-20, -32); ctx.lineTo(-12, -32);
  ctx.lineTo(-17, -23); ctx.closePath(); ctx.fill();

  // Caçamba
  ctx.fillStyle = escurecerCor(cor, 0.7);
  ctx.fillRect(25, -20, 28, 35);
  ctx.strokeStyle = '#222';
  ctx.strokeRect(25, -20, 28, 35);

  // Faróis
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(52, -12, 4, 6);
  ctx.fillRect(52, 6, 4, 6);
  ctx.shadowBlur = 0;

  // Lanternas
  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-55, -10, 3, 8);
  ctx.fillRect(-55, 4, 3, 8);

  // Rodas maiores
  desenharRoda(ctx, -35, 20, 10);
  desenharRoda(ctx, 35, 20, 10);
  desenharRoda(ctx, -35, -20, 10);
  desenharRoda(ctx, 35, -20, 10);

  ctx.restore();
}

/**
 * Van/Minibus - veículo grande e alto
 */
function desenharVan(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 120, escY = h / 65;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo principal (retangular)
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-60, 20); ctx.lineTo(-60, -20); ctx.lineTo(-45, -30);
  ctx.lineTo(40, -30); ctx.lineTo(55, -20); ctx.lineTo(60, -10);
  ctx.lineTo(60, 20); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  // Brilho superior
  ctx.fillStyle = clarearCor(cor, 0.15);
  ctx.fillRect(-45, -30, 85, 3);

  // Janelas laterais
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(-40, -25, 15, 12);
  ctx.fillRect(-20, -25, 15, 12);
  ctx.fillRect(0, -25, 15, 12);
  ctx.fillRect(20, -25, 15, 12);

  // Vidro frontal
  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(40, -30); ctx.lineTo(55, -20); ctx.lineTo(55, -10);
  ctx.lineTo(40, -10); ctx.closePath(); ctx.fill();

  // Faróis
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(57, -8, 3, 6);
  ctx.fillRect(57, 4, 3, 6);
  ctx.shadowBlur = 0;

  // Lanternas
  ctx.fillStyle = '#C0392B';
  ctx.fillRect(-60, -15, 3, 8);
  ctx.fillRect(-60, 8, 3, 8);

  // Rodas
  desenharRoda(ctx, -40, 22, 10);
  desenharRoda(ctx, 40, 22, 10);
  desenharRoda(ctx, -40, -22, 10);
  desenharRoda(ctx, 40, -22, 10);

  ctx.restore();
}

/**
 * Moto - veículo pequeno e ágil
 */
function desenharMoto(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 70, escY = h / 40;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo da moto
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-30, 5); ctx.lineTo(-25, -8); ctx.lineTo(-10, -12);
  ctx.lineTo(15, -12); ctx.lineTo(25, -5); ctx.lineTo(30, 5);
  ctx.lineTo(25, 10); ctx.lineTo(-25, 10);
  ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  // Banco
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.moveTo(-15, -12); ctx.lineTo(-5, -18); ctx.lineTo(10, -18);
  ctx.lineTo(15, -12); ctx.closePath(); ctx.fill();

  // Tanque
  ctx.fillStyle = clarearCor(cor, 0.2);
  ctx.beginPath();
  ctx.ellipse(0, -10, 12, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#222';
  ctx.stroke();

  // Guidão
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(20, -15); ctx.lineTo(25, -20);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(20, -15); ctx.lineTo(25, -10);
  ctx.stroke();

  // Farol
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 8;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.beginPath();
  ctx.arc(28, -5, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Lanterna traseira
  ctx.fillStyle = '#C0392B';
  ctx.beginPath();
  ctx.arc(-28, 0, 2, 0, Math.PI * 2);
  ctx.fill();

  // Rodas (duas apenas)
  desenharRoda(ctx, -20, 12, 8);
  desenharRoda(ctx, 20, 12, 8);

  ctx.restore();
}

/**
 * ============================================================
 * EXEMPLO: Como criar seu próprio modelo de carro
 * ============================================================
 * 
 * PASSO 1: Crie uma função seguindo este padrão:
 * - Nome: desenharSeuModelo
 * - Parâmetros: ctx, cx, cy, w, h, cor, farolAceso
 * - Use ctx.beginPath(), ctx.moveTo(), ctx.lineTo(), etc.
 * - A origem (0,0) é o centro do carro
 * - O carro é desenhado apontando para a DIREITA
 * - Use ctx.save()/ctx.restore() para isolar transformações
 * 
 * PASSO 2: Registre no switch case da função desenharCarroIsometrico
 * 
 * PASSO 3: Adicione o nome em modelosCarros no arquivo data.ts
 * 
 * PASSO 4: Adicione na galeria do menu em App.tsx
 * ============================================================
 */

/**
 * EXEMPLO PRÁTICO: Carro de Polícia
 */
function desenharPolicial(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo principal (preto e branco)
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.moveTo(-50, 12); ctx.lineTo(-50, -12); ctx.lineTo(-35, -20);
  ctx.lineTo(20, -20); ctx.lineTo(40, -15); ctx.lineTo(50, -5);
  ctx.lineTo(50, 12); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = '#000'; ctx.lineWidth = 1.5; ctx.stroke();

  // Faixa branca lateral
  ctx.fillStyle = 'white';
  ctx.fillRect(-45, -5, 90, 10);

  // Texto "POLÍCIA" (simplificado como retângulo)
  ctx.fillStyle = '#1a1a1a';
  ctx.font = 'bold 6px Georgia';
  ctx.textAlign = 'center';
  ctx.fillText('POLÍCIA', 0, 2);

  // Giroflex (luzes no teto)
  if (farolAceso) {
    // Luz vermelha piscando
    ctx.fillStyle = '#FF0000';
    ctx.shadowColor = '#FF0000';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(-5, -25, 4, 0, Math.PI * 2);
    ctx.fill();
    // Luz azul
    ctx.fillStyle = '#0066FF';
    ctx.shadowColor = '#0066FF';
    ctx.beginPath();
    ctx.arc(5, -25, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  } else {
    ctx.fillStyle = '#FF0000';
    ctx.beginPath();
    ctx.arc(-5, -25, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#0066FF';
    ctx.beginPath();
    ctx.arc(5, -25, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  // Vidros
  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.moveTo(12, -18); ctx.lineTo(20, -20); ctx.lineTo(10, -28);
  ctx.lineTo(5, -28); ctx.closePath(); ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-5, -18); ctx.lineTo(10, -18); ctx.lineTo(5, -28);
  ctx.lineTo(-10, -28); ctx.closePath(); ctx.fill();

  // Faróis
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(47, -8, 3, 5); ctx.fillRect(47, 5, 3, 5);
  ctx.shadowBlur = 0;

  // Rodas
  desenharRoda(ctx, -30, 15, 8);
  desenharRoda(ctx, 30, 15, 8);
  desenharRoda(ctx, -30, -15, 8);
  desenharRoda(ctx, 30, -15, 8);

  ctx.restore();
}

/**
 * Fusca Clássico - carro vintage arredondado
 */
function desenharFusca(ctx: CanvasRenderingContext2D, cx: number, cy: number, w: number, h: number, cor: string, farolAceso: boolean = false) {
  const escX = w / 90, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo arredondado característico
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-45, 15);
  ctx.quadraticCurveTo(-50, 0, -45, -10);
  ctx.quadraticCurveTo(-35, -25, -15, -28);
  ctx.quadraticCurveTo(0, -30, 15, -28);
  ctx.quadraticCurveTo(35, -25, 42, -10);
  ctx.quadraticCurveTo(45, 0, 42, 15);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#222'; ctx.lineWidth = 1.5; ctx.stroke();

  // Brilho superior
  ctx.fillStyle = clarearCor(cor, 0.25);
  ctx.beginPath();
  ctx.quadraticCurveTo(-35, -25, -15, -28);
  ctx.quadraticCurveTo(0, -30, 15, -28);
  ctx.quadraticCurveTo(35, -25, 42, -10);
  ctx.lineTo(38, -10);
  ctx.quadraticCurveTo(30, -22, 15, -25);
  ctx.quadraticCurveTo(0, -27, -15, -25);
  ctx.quadraticCurveTo(-30, -22, -40, -10);
  ctx.closePath();
  ctx.fill();

  // Janela traseira (oval característica)
  ctx.fillStyle = '#0a0a0a';
  ctx.beginPath();
  ctx.ellipse(-25, -15, 12, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Janela frontal
  ctx.beginPath();
  ctx.ellipse(20, -15, 12, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Faróis redondos característicos
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.beginPath();
  ctx.arc(40, -5, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(40, 8, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Faróis traseiros
  ctx.fillStyle = '#C0392B';
  ctx.beginPath();
  ctx.arc(-42, -3, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(-42, 6, 3, 0, Math.PI * 2);
  ctx.fill();

  // Rodas
  desenharRoda(ctx, -28, 18, 8);
  desenharRoda(ctx, 28, 18, 8);
  desenharRoda(ctx, -28, -18, 8);
  desenharRoda(ctx, 28, -18, 8);

  ctx.restore();
}

/**
 * Desenha o guarda de trânsito animado
 */
export function desenharGuarda(ctx: CanvasRenderingContext2D, x: number, y: number, frame: number, mensagem: string = '') {
  ctx.save();
  ctx.translate(x, y);

  // Balanço suave do corpo
  const balanco = Math.sin(frame * 0.05) * 2;
  ctx.rotate(balanco * 0.02);

  // Sombra
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(0, 35, 15, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Pernas
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-8, 15, 6, 20);
  ctx.fillRect(2, 15, 6, 20);

  // Sapatos
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(-9, 32, 8, 4);
  ctx.fillRect(1, 32, 8, 4);

  // Corpo (uniforme)
  ctx.fillStyle = '#2C3E50';
  ctx.beginPath();
  ctx.moveTo(-12, -5);
  ctx.lineTo(12, -5);
  ctx.lineTo(10, 18);
  ctx.lineTo(-10, 18);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Cinto
  ctx.fillStyle = '#8B4513';
  ctx.fillRect(-10, 12, 20, 4);
  ctx.fillStyle = '#FFD700';
  ctx.fillRect(-2, 12, 4, 4);

  // Braços
  const angBraco = Math.sin(frame * 0.08) * 0.3;
  ctx.save();
  ctx.translate(-12, 0);
  ctx.rotate(-0.3 + angBraco);
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-3, 0, 6, 18);
  // Mão
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, 20, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Braço direito (acena)
  ctx.save();
  ctx.translate(12, 0);
  ctx.rotate(0.3 - angBraco * 1.5);
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-3, 0, 6, 18);
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, 20, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Cabeça
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, -15, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 0.5;
  ctx.stroke();

  // Olhos
  ctx.fillStyle = '#333';
  ctx.beginPath();
  ctx.arc(-4, -17, 1.5, 0, Math.PI * 2);
  ctx.arc(4, -17, 1.5, 0, Math.PI * 2);
  ctx.fill();

  // Sorriso
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(0, -12, 4, 0.1, Math.PI - 0.1);
  ctx.stroke();

  // Quepe
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.ellipse(0, -24, 12, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(-10, -28, 20, 6);
  // Brilho do quepe
  ctx.fillStyle = '#FFD700';
  ctx.beginPath();
  ctx.arc(0, -25, 3, 0, Math.PI * 2);
  ctx.fill();

  // Apito (se tiver mensagem)
  if (mensagem) {
    ctx.fillStyle = '#C0C0C0';
    ctx.beginPath();
    ctx.arc(6, -10, 2, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();

  // Balão de fala
  if (mensagem) {
    ctx.save();
    const larguraTexto = ctx.measureText(mensagem).width + 20;
    const bx = x - larguraTexto / 2;
    const by = y - 70;

    // Fundo do balão
    ctx.fillStyle = 'white';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    // Fallback para roundRect (compatibilidade)
    const r = 10;
    ctx.moveTo(bx + r, by);
    ctx.lineTo(bx + larguraTexto - r, by);
    ctx.quadraticCurveTo(bx + larguraTexto, by, bx + larguraTexto, by + r);
    ctx.lineTo(bx + larguraTexto, by + 30 - r);
    ctx.quadraticCurveTo(bx + larguraTexto, by + 30, bx + larguraTexto - r, by + 30);
    ctx.lineTo(bx + r, by + 30);
    ctx.quadraticCurveTo(bx, by + 30, bx, by + 30 - r);
    ctx.lineTo(bx, by + r);
    ctx.quadraticCurveTo(bx, by, bx + r, by);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Ponteiro do balão
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.moveTo(x - 5, by + 30);
    ctx.lineTo(x, by + 40);
    ctx.lineTo(x + 5, by + 30);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#333';
    ctx.beginPath();
    ctx.moveTo(x - 5, by + 30);
    ctx.lineTo(x, by + 40);
    ctx.lineTo(x + 5, by + 30);
    ctx.stroke();

    // Texto
    ctx.fillStyle = '#333';
    ctx.font = 'bold 11px Georgia';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(mensagem, x, by + 15);
    ctx.restore();
  }
}

export function desenharCarroIsometrico(
  ctx: CanvasRenderingContext2D,
  x: number, y: number, w: number, h: number,
  cor: string, modelo: string = 'sedã', direcao: string = 'direita',
  ehJogador: boolean = false, emoji: string = '',
  inclinacao: number = 0, oscilacao: number = 0,
  farolAceso: boolean = false
) {
  const cx = x + w / 2, cy = y + h / 2;
  ctx.save();
  ctx.translate(cx, cy);

  // Aplica inclinação (curva)
  if (ehJogador && inclinacao !== 0) {
    ctx.rotate(inclinacao * 0.03);
  }

  // Aplica oscilação (balanço ao parar)
  if (ehJogador && oscilacao !== 0) {
    ctx.translate(0, oscilacao);
  }

  let angulo = 0;
  if (direcao === 'cima') angulo = Math.PI;
  else if (direcao === 'esquerda') angulo = Math.PI / 2;
  else if (direcao === 'direita') angulo = -Math.PI / 2;
  ctx.rotate(angulo);
  ctx.translate(-cx, -cy);

  // Sombra dinâmica
  desenharSombra(ctx, cx, cy, w, h, direcao);

  switch (modelo) {
    case 'esportivo': desenharEsportivo(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'hatch': desenharHatch(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'compacto': desenharCompacto(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'caminhonete': desenharCaminhonete(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'van': desenharVan(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'moto': desenharMoto(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'fusca': desenharFusca(ctx, cx, cy, w, h, cor, farolAceso); break;
    case 'policial': desenharPolicial(ctx, cx, cy, w, h, cor, farolAceso); break;
    default: desenharSeda(ctx, cx, cy, w, h, cor, farolAceso);
  }
  ctx.restore();

  // Emoji/balão acima do carro do jogador
  if (ehJogador && emoji) {
    ctx.save();
    const bx = x + w / 2, by = y - 25 + oscilacao;
    ctx.fillStyle = 'white';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(bx, by, 22, 0, Math.PI * 2);
    ctx.fill(); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(bx - 4, by + 20); ctx.lineTo(bx, by + 28); ctx.lineTo(bx + 4, by + 20);
    ctx.closePath(); ctx.fillStyle = 'white'; ctx.fill(); ctx.stroke();
    ctx.font = '26px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(emoji, bx, by);
    ctx.restore();
  }
}

/**
 * Renderiza o layout clássico (2 fileiras)
 */
function renderizarLayoutClassico(ctx: CanvasRenderingContext2D) {
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 2;
  const numVagas = 10;
  const larguraVaga = 80;
  const espacamento = 10;
  const inicioX = 30;

  // Fileira superior
  for (let i = 0; i <= numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) - espacamento / 2;
    ctx.beginPath(); ctx.moveTo(x, 20); ctx.lineTo(x, 120); ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 120);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 120);
  ctx.stroke();

  // Fileira inferior
  for (let i = 0; i <= numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) - espacamento / 2;
    ctx.beginPath(); ctx.moveTo(x, 380); ctx.lineTo(x, 480); ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 380);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 380);
  ctx.stroke();

  // Numeração
  ctx.fillStyle = 'white';
  ctx.font = 'bold 11px Georgia';
  ctx.textAlign = 'center';
  for (let i = 0; i < numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) + larguraVaga / 2;
    ctx.fillText(String(623 - i), x, 18);
    ctx.fillText(String(664 - i), x, 495);
  }

  // Setas no corredor
  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  ctx.font = '30px Georgia';
  ctx.textAlign = 'center';
  ctx.fillText('➡', 450, 255);
  ctx.font = '20px Georgia';
  ctx.fillText('➡', 200, 255);
  ctx.fillText('➡', 700, 255);
}

/**
 * Renderiza o layout shopping (3 fileiras)
 */
function renderizarLayoutShopping(ctx: CanvasRenderingContext2D) {
  ctx.strokeStyle = 'white';
  ctx.lineWidth = 2;
  const numVagas = 5;
  const larguraVaga = 80;
  const espacamento = 10;
  const inicioX = 180;

  // Fileira superior
  for (let i = 0; i <= numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) - espacamento / 2;
    ctx.beginPath(); ctx.moveTo(x, 20); ctx.lineTo(x, 110); ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 110);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 110);
  ctx.stroke();

  // Fileira central (invertida - vagas olham para cima)
  for (let i = 0; i <= numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) - espacamento / 2;
    ctx.beginPath(); ctx.moveTo(x, 205); ctx.lineTo(x, 295); ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 205);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 205);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 295);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 295);
  ctx.stroke();

  // Fileira inferior
  for (let i = 0; i <= numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) - espacamento / 2;
    ctx.beginPath(); ctx.moveTo(x, 390); ctx.lineTo(x, 480); ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(inicioX - 10, 390);
  ctx.lineTo(inicioX + numVagas * (larguraVaga + espacamento), 390);
  ctx.stroke();

  // Numeração
  ctx.fillStyle = 'white';
  ctx.font = 'bold 11px Georgia';
  ctx.textAlign = 'center';
  for (let i = 0; i < numVagas; i++) {
    const x = inicioX + i * (larguraVaga + espacamento) + larguraVaga / 2;
    ctx.fillText(String(101 - i), x, 18);
    ctx.fillText(String(201 - i), x, 203);
    ctx.fillText(String(301 - i), x, 495);
  }

  // Setas nos corredores
  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  ctx.font = '24px Georgia';
  ctx.textAlign = 'center';
  ctx.fillText('➡', 450, 160);
  ctx.fillText('➡', 450, 350);
  ctx.font = '18px Georgia';
  ctx.fillText('➡', 250, 160);
  ctx.fillText('➡', 650, 160);
  ctx.fillText('➡', 250, 350);
  ctx.fillText('➡', 650, 350);

  // Decoração: pilares
  ctx.fillStyle = 'rgba(255,255,255,0.3)';
  ctx.fillRect(150, 130, 20, 60);
  ctx.fillRect(730, 130, 20, 60);
  ctx.fillRect(150, 310, 20, 60);
  ctx.fillRect(730, 310, 20, 60);
}

/**
 * Renderização completa da cena
 */
export function renderizar(
  ctx: CanvasRenderingContext2D,
  texturaChao: TexturaPonto[],
  vagas: Vaga[],
  obstaculos: Obstaculo[],
  carro: Carro,
  faseAtual: number,
  vagaAtual: Vaga | null,
  tempoNaVaga: number,
  particulas: SistemaParticulas,
  frame: number,
  mostrarGuarda: boolean = false,
  mensagemGuarda: string = '',
  opacidadeTransicao: number = 0,
  vagaDestacada: Vaga | null = null,
  layout: string = 'classico'
) {
  // Fundo concreto
  ctx.fillStyle = '#9a9a9a';
  ctx.fillRect(0, 0, 900, 500);

  // Textura pré-gerada
  ctx.fillStyle = 'rgba(0,0,0,0.03)';
  for (const ponto of texturaChao) {
    ctx.fillRect(ponto.x, ponto.y, ponto.w, ponto.h);
  }

  // Partículas (marcas de pneu primeiro)
  particulas.renderizar(ctx);

  // Renderiza layout baseado no tipo
  if (layout === 'shopping') {
    renderizarLayoutShopping(ctx);
  } else {
    renderizarLayoutClassico(ctx);
  }

  // Obstáculos
  for (const obs of obstaculos) {
    desenharCarroIsometrico(ctx, obs.x, obs.y, obs.w, obs.h, obs.cor, obs.modelo, obs.direcao);
  }

  // Vagas com palavras
  for (const v of vagas) {
    let corFundo = 'rgba(255,255,255,0.15)';
    let corBorda = 'white';
    if (v.estado === 'acerto') { corFundo = 'rgba(144,238,144,0.6)'; corBorda = '#228B22'; }
    else if (v.estado === 'erro') { corFundo = 'rgba(255,100,100,0.6)'; corBorda = '#B22222'; }
    else if (vagaAtual === v) { corFundo = 'rgba(255,228,181,0.5)'; }
    else if (vagaDestacada === v) {
      // Vaga destacada pela dica (piscando)
      const piscar = Math.sin(frame * 0.2) > 0;
      corFundo = piscar ? 'rgba(0,255,0,0.4)' : 'rgba(0,200,0,0.2)';
      corBorda = '#00FF00';
    }

    ctx.fillStyle = corFundo;
    ctx.fillRect(v.x, v.y, v.w, v.h);

    ctx.strokeStyle = corBorda;
    ctx.lineWidth = vagaDestacada === v ? 4 : 3;
    ctx.setLineDash(vagaDestacada === v ? [] : [8, 4]);
    ctx.strokeRect(v.x + 2, v.y + 2, v.w - 4, v.h - 4);
    ctx.setLineDash([]);

    ctx.fillStyle = v.estado === 'acerto' ? '#006400' : v.estado === 'erro' ? '#8B0000' : 'white';
    ctx.font = 'bold 15px Georgia, serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 4;
    ctx.fillText(v.palavra, v.x + v.w / 2, v.y + v.h / 2);
    ctx.shadowBlur = 0;

    // Barra de progresso
    if (vagaAtual === v && tempoNaVaga > 0 && v.estado === 'normal') {
      const progresso = tempoNaVaga / 60;
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.fillRect(v.x + 5, v.y + v.h - 12, (v.w - 10) * progresso, 8);
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 1;
      ctx.strokeRect(v.x + 5, v.y + v.h - 12, v.w - 10, 8);
    }
  }

  // Guarda de trânsito
  if (mostrarGuarda) {
    desenharGuarda(ctx, 820, 260, frame, mensagemGuarda);
  }

  // Carro do jogador
  if (fases[faseAtual]) {
    desenharCarroIsometrico(
      ctx, carro.x, carro.y, carro.w, carro.h,
      carro.cor, carro.modelo, carro.direcao,
      true, fases[faseAtual].imagem,
      carro.inclinacao, carro.oscilacao,
      false
    );
  }

  // Transição fade
  if (opacidadeTransicao > 0) {
    ctx.fillStyle = `rgba(0,0,0,${opacidadeTransicao})`;
    ctx.fillRect(0, 0, 900, 500);
  }
}
