/**
 * Renderizador 3D Isométrico Avançado para o Palavra a bordo
 * Visual 3D real com perspectiva, sombras e iluminação
 */

import { darkenColor } from './iso3d';
import { Vaga, Obstaculo, Carro, fases } from './data';
import { SistemaParticulas } from './particles';

// Configurações de câmera 3D
const ISO_ANGLE = Math.PI / 6; // 30 graus
const ISO_COS = Math.cos(ISO_ANGLE);
const ISO_SIN = Math.sin(ISO_ANGLE);

/**
 * Converte coordenadas do mundo para isométrico
 */
function worldToIso(x: number, y: number, z: number = 0): { x: number; y: number } {
  return {
    x: (x - y) * ISO_COS,
    y: (x + y) * ISO_SIN - z
  };
}

/**
 * Renderiza o ambiente 3D (céu, chão, iluminação)
 */
function renderizarAmbiente3D(ctx: CanvasRenderingContext2D, width: number, height: number, frame: number) {
  // Céu com gradiente dinâmico (ciclo dia mais bonito)
  const skyGrad = ctx.createLinearGradient(0, 0, 0, height * 0.7);
  skyGrad.addColorStop(0, '#4A90E2'); // Azul vibrante
  skyGrad.addColorStop(0.4, '#7CB9E8'); // Azul claro
  skyGrad.addColorStop(0.7, '#B0E0E6'); // Azul suave
  skyGrad.addColorStop(1, '#E0F0FF'); // Quase branco
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, width, height);
  
  // Sol com brilho
  const sunX = width * 0.8;
  const sunY = height * 0.15;
  const sunGrad = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 80);
  sunGrad.addColorStop(0, 'rgba(255, 255, 200, 1)');
  sunGrad.addColorStop(0.3, 'rgba(255, 255, 150, 0.8)');
  sunGrad.addColorStop(0.6, 'rgba(255, 255, 100, 0.3)');
  sunGrad.addColorStop(1, 'rgba(255, 255, 100, 0)');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(sunX, sunY, 80, 0, Math.PI * 2);
  ctx.fill();
  
  // Núcleo do sol
  ctx.fillStyle = '#FFFACD';
  ctx.beginPath();
  ctx.arc(sunX, sunY, 30, 0, Math.PI * 2);
  ctx.fill();
  
  // Nuvens animadas 3D
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  for (let i = 0; i < 6; i++) {
    const cloudX = ((frame * 0.3 + i * 180) % (width + 300)) - 150;
    const cloudY = 60 + i * 25;
    const cloudScale = 0.8 + (i % 3) * 0.2;
    
    ctx.save();
    ctx.translate(cloudX, cloudY);
    ctx.scale(cloudScale, cloudScale * 0.6); // Achata para perspectiva
    
    // Sombra da nuvem
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.beginPath();
    ctx.arc(5, 5, 35, 0, Math.PI * 2);
    ctx.arc(30, 5, 40, 0, Math.PI * 2);
    ctx.arc(55, 5, 35, 0, Math.PI * 2);
    ctx.fill();
    
    // Nuvem principal
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.beginPath();
    ctx.arc(0, 0, 35, 0, Math.PI * 2);
    ctx.arc(25, 0, 40, 0, Math.PI * 2);
    ctx.arc(50, 0, 35, 0, Math.PI * 2);
    ctx.fill();
    
    // Brilho no topo
    ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
    ctx.beginPath();
    ctx.arc(10, -10, 20, 0, Math.PI * 2);
    ctx.arc(35, -10, 25, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();
  }
  
  // Chão do estacionamento (asfalto 3D com perspectiva)
  ctx.save();
  ctx.translate(width / 2, height / 2 + 100);
  
  // Chão isométrico com gradiente realista
  const floorGrad = ctx.createLinearGradient(-600, -300, 600, 300);
  floorGrad.addColorStop(0, '#2a2a2a');
  floorGrad.addColorStop(0.3, '#3a3a3a');
  floorGrad.addColorStop(0.5, '#454545');
  floorGrad.addColorStop(0.7, '#3a3a3a');
  floorGrad.addColorStop(1, '#2a2a2a');
  ctx.fillStyle = floorGrad;
  
  // Diamante isométrico (chão)
  ctx.beginPath();
  ctx.moveTo(0, -280);
  ctx.lineTo(550, 0);
  ctx.lineTo(0, 280);
  ctx.lineTo(-550, 0);
  ctx.closePath();
  ctx.fill();
  
  // Borda do estacionamento
  ctx.strokeStyle = '#FFD700';
  ctx.lineWidth = 4;
  ctx.stroke();
  
  // Textura do asfalto (granulação realista)
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  for (let i = 0; i < 200; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = Math.random() * 400;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius * 0.5; // Achata para perspectiva
    const size = Math.random() * 2 + 1;
    ctx.fillRect(x, y, size, size);
  }
  
  // Textura clara (reflexos)
  ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
  for (let i = 0; i < 50; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = Math.random() * 350;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius * 0.5;
    const size = Math.random() * 3 + 2;
    ctx.fillRect(x, y, size, size);
  }
  
  // Linhas do estacionamento (marcações 3D no chão)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.lineWidth = 3;
  ctx.setLineDash([15, 10]);
  
  // Linhas horizontais (perspectiva isométrica)
  for (let i = -3; i <= 3; i++) {
    const y = i * 70;
    ctx.beginPath();
    ctx.moveTo(-450 + Math.abs(i) * 20, y);
    ctx.lineTo(450 - Math.abs(i) * 20, y);
    ctx.stroke();
  }
  
  // Linhas verticais (perspectiva isométrica)
  for (let i = -4; i <= 4; i++) {
    const x = i * 100;
    ctx.beginPath();
    ctx.moveTo(x, -220 + Math.abs(i) * 15);
    ctx.lineTo(x, 220 - Math.abs(i) * 15);
    ctx.stroke();
  }
  
  ctx.setLineDash([]);
  
  // Setas direcionais no chão
  ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.font = 'bold 40px Georgia';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Seta central
  ctx.save();
  ctx.scale(1, 0.5); // Achata para perspectiva
  ctx.fillText('→', 0, 0);
  ctx.restore();
  
  // Setas laterais
  ctx.save();
  ctx.scale(1, 0.5);
  ctx.fillText('→', -250, -100);
  ctx.fillText('→', 250, 100);
  ctx.restore();
  
  ctx.restore();
}

/**
 * Renderiza uma vaga 3D com paredes e profundidade
 */
function renderizarVaga3D(
  ctx: CanvasRenderingContext2D,
  vaga: Vaga,
  offsetX: number,
  offsetY: number,
  frame: number,
  vagaAtual: Vaga | null,
  vagaDestacada: Vaga | null
) {
  const isoPos = worldToIso(vaga.x - 450, vaga.y - 250, 0);
  const screenX = isoPos.x + offsetX;
  const screenY = isoPos.y + offsetY;
  
  ctx.save();
  ctx.translate(screenX, screenY);
  
  // Determina cor baseada no estado
  let corBase = '#5a5a5a';
  let corBorda = '#ffffff';
  let brilho = 0;
  
  if (vaga.estado === 'acerto') {
    corBase = '#2ecc71';
    corBorda = '#27ae60';
    brilho = 0.3;
  } else if (vaga.estado === 'erro') {
    corBase = '#e74c3c';
    corBorda = '#c0392b';
  } else if (vagaDestacada === vaga) {
    const piscar = Math.sin(frame * 0.3) * 0.5 + 0.5;
    corBase = `hsl(45, 100%, ${50 + piscar * 20}%)`;
    corBorda = '#d35400';
    brilho = piscar * 0.4;
  } else if (vagaAtual === vaga) {
    corBase = '#3498db';
    corBorda = '#2980b9';
    brilho = 0.2;
  }
  
  // Sombra projetada
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.filter = 'blur(6px)';
  ctx.beginPath();
  ctx.ellipse(8, 15, 50, 25, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.filter = 'none';
  
  // Base da vaga (chão)
  const baseGrad = ctx.createLinearGradient(-60, 0, 60, 60);
  baseGrad.addColorStop(0, corBase);
  baseGrad.addColorStop(1, darkenColor(corBase, 0.8));
  ctx.fillStyle = baseGrad;
  
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(70, 35);
  ctx.lineTo(0, 70);
  ctx.lineTo(-70, 35);
  ctx.closePath();
  ctx.fill();
  
  // Brilho na base
  if (brilho > 0) {
    ctx.fillStyle = `rgba(255, 255, 255, ${brilho})`;
    ctx.fill();
  }
  
  // Bordas 3D (paredes)
  const paredeAltura = 12;
  
  // Parede frontal (mais escura)
  ctx.fillStyle = darkenColor(corBase, 0.6);
  ctx.beginPath();
  ctx.moveTo(-70, 35);
  ctx.lineTo(0, 70);
  ctx.lineTo(0, 70 + paredeAltura);
  ctx.lineTo(-70, 35 + paredeAltura);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = corBorda;
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // Parede direita (média)
  ctx.fillStyle = darkenColor(corBase, 0.75);
  ctx.beginPath();
  ctx.moveTo(0, 70);
  ctx.lineTo(70, 35);
  ctx.lineTo(70, 35 + paredeAltura);
  ctx.lineTo(0, 70 + paredeAltura);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = corBorda;
  ctx.stroke();
  
  // Linhas da vaga (marcações no chão)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.lineWidth = 3;
  ctx.setLineDash([8, 6]);
  ctx.beginPath();
  ctx.moveTo(-55, 28);
  ctx.lineTo(0, 56);
  ctx.lineTo(55, 28);
  ctx.stroke();
  ctx.setLineDash([]);
  
  // Texto da palavra com efeito 3D
  ctx.save();
  ctx.translate(0, 30);
  
  // Sombra do texto
  ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
  ctx.font = 'bold 18px Georgia';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(vaga.palavra, 2, 2);
  
  // Texto principal (amarelo para melhor visibilidade)
  ctx.fillStyle = '#FFD700';
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
  ctx.lineWidth = 4;
  ctx.strokeText(vaga.palavra, 0, 0);
  ctx.fillText(vaga.palavra, 0, 0);
  
  ctx.restore();
  
  // Barra de progresso 3D
  if (vagaAtual === vaga && vaga.estado === 'normal') {
    const progresso = Math.min(1, (Date.now() % 2000) / 2000);
    
    // Fundo da barra
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(-35, 52, 70, 6);
    
    // Barra de progresso
    const barGrad = ctx.createLinearGradient(-35, 0, 35, 0);
    barGrad.addColorStop(0, '#2ecc71');
    barGrad.addColorStop(1, '#27ae60');
    ctx.fillStyle = barGrad;
    ctx.fillRect(-35, 52, 70 * progresso, 6);
    
    // Borda da barra
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.lineWidth = 1;
    ctx.strokeRect(-35, 52, 70, 6);
  }
  
  ctx.restore();
}

/**
 * Renderiza um carro 3D isométrico detalhado
 */
function renderizarCarro3D(
  ctx: CanvasRenderingContext2D,
  carro: Carro,
  offsetX: number,
  offsetY: number,
  frame: number,
  ehJogador: boolean = false,
  emoji: string = ''
) {
  const isoPos = worldToIso(carro.x - 450, carro.y - 250, 20); // Elevação
  const screenX = isoPos.x + offsetX;
  const screenY = isoPos.y + offsetY;
  
  ctx.save();
  ctx.translate(screenX, screenY);
  
  // Rotação baseada na direção
  let rotation = 0;
  if (carro.direcao === 'direita') rotation = 0;
  else if (carro.direcao === 'baixo') rotation = Math.PI / 2;
  else if (carro.direcao === 'esquerda') rotation = Math.PI;
  else if (carro.direcao === 'cima') rotation = -Math.PI / 2;
  
  ctx.rotate(rotation);
  
  // Inclinação (curva)
  if (ehJogador && carro.inclinacao !== 0) {
    ctx.rotate(carro.inclinacao * 0.08);
  }
  
  // Oscilação (balanço)
  if (ehJogador && carro.oscilacao !== 0) {
    ctx.translate(0, carro.oscilacao);
  }
  
  // Sombra projetada (no chão)
  ctx.save();
  ctx.rotate(-rotation);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.filter = 'blur(4px)';
  ctx.beginPath();
  ctx.ellipse(6, 25, 40, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.filter = 'none';
  ctx.restore();
  
  const cor = carro.cor;
  
  // === PARTE INFERIOR (Chassi) ===
  ctx.fillStyle = darkenColor(cor, 0.5);
  ctx.beginPath();
  ctx.moveTo(-35, 12);
  ctx.lineTo(35, 12);
  ctx.lineTo(40, 18);
  ctx.lineTo(-40, 18);
  ctx.closePath();
  ctx.fill();
  
  // === CORPO PRINCIPAL ===
  // Lado esquerdo (mais escuro)
  ctx.fillStyle = darkenColor(cor, 0.7);
  ctx.beginPath();
  ctx.moveTo(-35, -12);
  ctx.lineTo(-35, 12);
  ctx.lineTo(-40, 18);
  ctx.lineTo(-40, -6);
  ctx.closePath();
  ctx.fill();
  
  // Lado direito (médio)
  ctx.fillStyle = darkenColor(cor, 0.8);
  ctx.beginPath();
  ctx.moveTo(35, -12);
  ctx.lineTo(35, 12);
  ctx.lineTo(40, 18);
  ctx.lineTo(40, -6);
  ctx.closePath();
  ctx.fill();
  
  // Topo (capô/teto) com gradiente
  const topoGrad = ctx.createLinearGradient(0, -25, 0, 5);
  topoGrad.addColorStop(0, darkenColor(cor, 1.3));
  topoGrad.addColorStop(0.5, cor);
  topoGrad.addColorStop(1, darkenColor(cor, 0.9));
  ctx.fillStyle = topoGrad;
  ctx.beginPath();
  ctx.moveTo(-35, -12);
  ctx.lineTo(35, -12);
  ctx.lineTo(35, 12);
  ctx.lineTo(-35, 12);
  ctx.closePath();
  ctx.fill();
  
  // Brilho no topo (reflexo do sol)
  const reflexoGrad = ctx.createLinearGradient(-35, -12, 35, 0);
  reflexoGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
  reflexoGrad.addColorStop(0.3, 'rgba(255, 255, 255, 0.3)');
  reflexoGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.5)');
  reflexoGrad.addColorStop(0.7, 'rgba(255, 255, 255, 0.3)');
  reflexoGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = reflexoGrad;
  ctx.beginPath();
  ctx.moveTo(-30, -10);
  ctx.lineTo(30, -10);
  ctx.lineTo(25, -5);
  ctx.lineTo(-25, -5);
  ctx.closePath();
  ctx.fill();
  
  // Reflexo lateral (linha de luz)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-33, 0);
  ctx.lineTo(33, 0);
  ctx.stroke();
  
  // === CABINE (Vidros) ===
  const vidroGrad = ctx.createLinearGradient(0, -20, 0, -5);
  vidroGrad.addColorStop(0, 'rgba(150, 200, 255, 0.9)');
  vidroGrad.addColorStop(1, 'rgba(100, 150, 200, 0.7)');
  ctx.fillStyle = vidroGrad;
  ctx.beginPath();
  ctx.moveTo(-25, -10);
  ctx.lineTo(25, -10);
  ctx.lineTo(20, -22);
  ctx.lineTo(-20, -22);
  ctx.closePath();
  ctx.fill();
  
  // Brilho nos vidros
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
  ctx.beginPath();
  ctx.moveTo(-18, -18);
  ctx.lineTo(-5, -18);
  ctx.lineTo(-8, -12);
  ctx.lineTo(-20, -12);
  ctx.closePath();
  ctx.fill();
  
  // Moldura dos vidros
  ctx.strokeStyle = darkenColor(cor, 0.6);
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // === FARÓIS (com efeito de brilho) ===
  const farolCor = '#ffff00';
  
  // Brilho externo dos faróis
  ctx.shadowColor = farolCor;
  ctx.shadowBlur = 20;
  ctx.fillStyle = 'rgba(255, 255, 100, 0.6)';
  ctx.beginPath();
  ctx.ellipse(34, -6, 8, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(34, 6, 8, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Faróis principais
  ctx.fillStyle = farolCor;
  ctx.beginPath();
  ctx.ellipse(32, -6, 4, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(32, 6, 4, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Centro brilhante dos faróis
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.beginPath();
  ctx.ellipse(32, -6, 2, 1.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(32, 6, 2, 1.5, 0, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.shadowBlur = 0;
  
  // === LANTERNAS TRASEIRAS (com efeito de brilho) ===
  // Brilho externo
  ctx.shadowColor = '#ff0000';
  ctx.shadowBlur = 15;
  ctx.fillStyle = 'rgba(255, 50, 50, 0.5)';
  ctx.beginPath();
  ctx.ellipse(-34, -6, 6, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-34, 6, 6, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Lanternas principais
  ctx.fillStyle = '#ff0000';
  ctx.beginPath();
  ctx.ellipse(-32, -6, 3, 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-32, 6, 3, 2, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Centro brilhante
  ctx.fillStyle = 'rgba(255, 150, 150, 0.8)';
  ctx.beginPath();
  ctx.ellipse(-32, -6, 1.5, 1, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(-32, 6, 1.5, 1, 0, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.shadowBlur = 0;
  
  // === RODAS ===
  const drawWheel = (x: number, y: number) => {
    // Pneu
    ctx.fillStyle = '#1a1a1a';
    ctx.beginPath();
    ctx.ellipse(x, y, 7, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Aro
    ctx.fillStyle = '#6a6a6a';
    ctx.beginPath();
    ctx.ellipse(x, y, 5, 3.5, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Centro
    ctx.fillStyle = '#3a3a3a';
    ctx.beginPath();
    ctx.ellipse(x, y, 2, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  };
  
  drawWheel(-22, 15);
  drawWheel(22, 15);
  drawWheel(-22, -15);
  drawWheel(22, -15);
  
  ctx.restore();
  
  // === EMOJI ACIMA DO CARRO ===
  if (ehJogador && emoji) {
    ctx.save();
    ctx.translate(screenX, screenY - 60);
    
    // Animação de flutuação
    const floatOffset = Math.sin(frame * 0.1) * 3;
    ctx.translate(0, floatOffset);
    
    // Balão
    ctx.fillStyle = 'white';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 3;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 4;
    
    ctx.beginPath();
    ctx.arc(0, 0, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
    
    // Ponteiro
    ctx.beginPath();
    ctx.moveTo(-6, 20);
    ctx.lineTo(0, 32);
    ctx.lineTo(6, 20);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    // Emoji
    ctx.font = '28px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(emoji, 0, 0);
    
    ctx.restore();
  }
}

/**
 * Renderizador principal 3D
 */
export function renderizar3D(
  ctx: CanvasRenderingContext2D,
  vagas: Vaga[],
  obstaculos: Obstaculo[],
  carro: Carro,
  faseAtual: number,
  vagaAtual: Vaga | null,
  particulas: SistemaParticulas,
  frame: number,
  vagaDestacada: Vaga | null = null,
  opacidadeTransicao: number = 0
) {
  const width = ctx.canvas.width;
  const height = ctx.canvas.height;
  
  // Limpa canvas
  ctx.clearRect(0, 0, width, height);
  
  // Renderiza ambiente 3D
  renderizarAmbiente3D(ctx, width, height, frame);
  
  // Offset central
  const offsetX = width / 2;
  const offsetY = height / 2;
  
  // Ordena todos os objetos por profundidade (painter's algorithm)
  const objetos = [
    ...vagas.map(v => ({ tipo: 'vaga', obj: v, profundidade: v.x + v.y })),
    ...obstaculos.map(o => ({ tipo: 'obstaculo', obj: o, profundidade: o.x + o.y })),
    { tipo: 'carro', obj: carro, profundidade: carro.x + carro.y }
  ].sort((a, b) => a.profundidade - b.profundidade);
  
  // Renderiza partículas (atrás de tudo)
  ctx.save();
  ctx.globalAlpha = 0.8;
  particulas.renderizar(ctx);
  ctx.restore();
  
  // Renderiza objetos em ordem de profundidade
  for (const item of objetos) {
    if (item.tipo === 'vaga') {
      renderizarVaga3D(ctx, item.obj as Vaga, offsetX, offsetY, frame, vagaAtual, vagaDestacada);
    } else if (item.tipo === 'obstaculo') {
      const obs = item.obj as Obstaculo;
      const carroObstaculo: Carro = {
        ...obs,
        velocidade: 0,
        direcao: obs.direcao,
        direcaoAlvo: obs.direcao,
        inclinacao: 0,
        oscilacao: 0
      };
      renderizarCarro3D(ctx, carroObstaculo, offsetX, offsetY, frame, false, '');
    } else if (item.tipo === 'carro') {
      const emoji = fases[faseAtual]?.imagem || '';
      renderizarCarro3D(ctx, item.obj as Carro, offsetX, offsetY, frame, true, emoji);
    }
  }
  
  // Transição fade
  if (opacidadeTransicao > 0) {
    ctx.fillStyle = `rgba(0, 0, 0, ${opacidadeTransicao})`;
    ctx.fillRect(0, 0, width, height);
  }
}
