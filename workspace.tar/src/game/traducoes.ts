/**
 * Sistema de Traduções - Palavra a bordo
 * Suporte para múltiplos idiomas (preparado para i18n)
 */

export type Idioma = 'pt' | 'en' | 'es';

export interface Traducoes {
  titulo: string;
  subtitulo: string;
  botoes: {
    jogar: string;
    comoJogar: string;
    conquistas: string;
    configuracoes: string;
  };
  mensagens: {
    vamosJogar: string;
    prontoParaAprender: string;
    estacioneEDivirtaSe: string;
    quePalavraEssa: string;
    vamosRimar: string;
  };
  rodape: string;
  som: {
    ativar: string;
    desativar: string;
  };
}

export const traducoes: Record<Idioma, Traducoes> = {
  pt: {
    titulo: 'PALAVRA A BORDO',
    subtitulo: 'Estacione o carro na palavra certa!',
    botoes: {
      jogar: 'JOGAR',
      comoJogar: 'Como Jogar',
      conquistas: 'Conquistas',
      configuracoes: 'Configurações'
    },
    mensagens: {
      vamosJogar: 'Vamos jogar! 🎮',
      prontoParaAprender: 'Pronto para aprender? 📚',
      estacioneEDivirtaSe: 'Estacione e divirta-se! 🚗',
      quePalavraEssa: 'Que palavra é essa? 🤔',
      vamosRimar: 'Vamos rimar! 🎵'
    },
    rodape: '🎓 Para crianças de 5-8 anos • 36 fases de aprendizado',
    som: {
      ativar: 'Ativar som',
      desativar: 'Desativar som'
    }
  },
  en: {
    titulo: 'WORD ABOARD',
    subtitulo: 'Park the car on the right word!',
    botoes: {
      jogar: 'PLAY',
      comoJogar: 'How to Play',
      conquistas: 'Achievements',
      configuracoes: 'Settings'
    },
    mensagens: {
      vamosJogar: "Let's play! 🎮",
      prontoParaAprender: 'Ready to learn? 📚',
      estacioneEDivirtaSe: 'Park and have fun! 🚗',
      quePalavraEssa: 'What word is this? 🤔',
      vamosRimar: "Let's rhyme! 🎵"
    },
    rodape: '🎓 For children ages 5-8 • 36 learning phases',
    som: {
      ativar: 'Enable sound',
      desativar: 'Disable sound'
    }
  },
  es: {
    titulo: 'PALABRA A BORDO',
    subtitulo: '¡Estaciona el coche en la palabra correcta!',
    botoes: {
      jogar: 'JUGAR',
      comoJogar: 'Cómo Jugar',
      conquistas: 'Logros',
      configuracoes: 'Configuración'
    },
    mensagens: {
      vamosJogar: '¡Vamos a jugar! 🎮',
      prontoParaAprender: '¿Listo para aprender? 📚',
      estacioneEDivirtaSe: '¡Estaciona y diviértete! 🚗',
      quePalavraEssa: '¿Qué palabra es esta? 🤔',
      vamosRimar: '¡Vamos a rimar! 🎵'
    },
    rodape: '🎓 Para niños de 5-8 años • 36 fases de aprendizaje',
    som: {
      ativar: 'Activar sonido',
      desativar: 'Desactivar sonido'
    }
  }
};

/**
 * Hook para obter traduções
 * @param idioma - Idioma atual (padrão: 'pt')
 * @returns Objeto com todas as traduções
 */
export function useTraducoes(idioma: Idioma = 'pt'): Traducoes {
  return traducoes[idioma];
}

/**
 * Função para obter mensagem aleatória do balão de fala
 * @param idioma - Idioma atual
 * @returns Mensagem aleatória
 */
export function getMensagemAleatoria(idioma: Idioma = 'pt'): string {
  const mensagens = Object.values(traducoes[idioma].mensagens);
  return mensagens[Math.floor(Math.random() * mensagens.length)];
}
