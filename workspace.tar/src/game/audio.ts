/**
 * Sistema de Áudio do Palavra a bordo
 * Gerencia: voz (speechSynthesis), efeitos sonoros, motor contínuo, música de fundo
 */

let audioCtx: AudioContext | null = null;
let motorOscillator: OscillatorNode | null = null;
let motorGain: GainNode | null = null;
let musicaGain: GainNode | null = null;
let musicaInterval: number | null = null;
let volumes = { musica: 0.3, efeitos: 0.5, voz: 0.8 };
let musicaAtiva = false;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Define volumes dos canais
 */
export function setVolumes(m: number, e: number, v: number) {
  volumes = { musica: m, efeitos: e, voz: v };
  if (motorGain) motorGain.gain.value = volumes.efeitos * 0.15;
  if (musicaGain) musicaGain.gain.value = volumes.musica * 0.4;
}

export function getVolumes() {
  return { ...volumes };
}

/**
 * Fala uma palavra usando síntese de voz
 */
export function falar(texto: string) {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(texto);
    u.lang = 'pt-BR';
    u.rate = 0.85;
    u.volume = volumes.voz;
    // Tratamento especial para palavras com acentos
    if (texto.includes('MAÇÃ')) u.text = 'maçã';
    if (texto.includes('AVIÃO')) u.text = 'avião';
    if (texto.includes('LÁPIS')) u.text = 'lápis';
    if (texto.includes('JACARÉ')) u.text = 'jacaré';
    window.speechSynthesis.speak(u);
  }
}

function tocarSom(freq: number, duracao: number, tipo: OscillatorType = 'sine', vol: number = 0.2) {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = tipo;
    osc.frequency.value = freq;
    const volFinal = vol * volumes.efeitos;
    gain.gain.setValueAtTime(volFinal, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duracao);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duracao);
  } catch (e) {
    // silently fail
  }
}

export function somAcerto() {
  // Melodia ascendente alegre
  tocarSom(523, 0.12, 'sine', 0.3);
  setTimeout(() => tocarSom(659, 0.12, 'sine', 0.3), 100);
  setTimeout(() => tocarSom(784, 0.2, 'sine', 0.3), 200);
  setTimeout(() => tocarSom(1047, 0.3, 'sine', 0.25), 350);
}

export function somErro() {
  tocarSom(200, 0.2, 'sawtooth', 0.2);
  setTimeout(() => tocarSom(150, 0.3, 'sawtooth', 0.2), 150);
}

export function somBatida() {
  tocarSom(100, 0.08, 'square', 0.15);
}

/**
 * Som de buzina
 */
export function somBuzina() {
  try {
    const ctx = getAudioContext();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    osc1.type = 'sawtooth';
    osc2.type = 'square';
    osc1.frequency.value = 440;
    osc2.frequency.value = 554;
    const volFinal = 0.25 * volumes.efeitos;
    gain.gain.setValueAtTime(volFinal, ctx.currentTime);
    gain.gain.setValueAtTime(volFinal, ctx.currentTime + 0.3);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);
    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + 0.5);
    osc2.stop(ctx.currentTime + 0.5);
  } catch (e) {}
}

/**
 * Som de conquista desbloqueada
 */
export function somConquista() {
  const notas = [523, 659, 784, 1047, 1319];
  notas.forEach((nota, i) => {
    setTimeout(() => tocarSom(nota, 0.2, 'sine', 0.2), i * 80);
  });
}

/**
 * Inicia o som do motor contínuo
 * A frequência muda conforme a velocidade
 */
export function iniciarMotor() {
  try {
    const ctx = getAudioContext();
    if (motorOscillator) return;

    motorOscillator = ctx.createOscillator();
    motorGain = ctx.createGain();

    motorOscillator.type = 'sawtooth';
    motorOscillator.frequency.value = 60;
    motorGain.gain.value = volumes.efeitos * 0.08;

    // Filtro para suavizar o som
    const filtro = ctx.createBiquadFilter();
    filtro.type = 'lowpass';
    filtro.frequency.value = 300;

    motorOscillator.connect(filtro);
    filtro.connect(motorGain);
    motorGain.connect(ctx.destination);
    motorOscillator.start();
  } catch (e) {}
}

/**
 * Atualiza o tom do motor conforme velocidade
 */
export function atualizarMotor(velocidade: number, maxVelocidade: number) {
  if (!motorOscillator || !motorGain) return;
  const ctx = getAudioContext();
  const ratio = velocidade / maxVelocidade;
  // Frequência entre 50Hz (parado) e 180Hz (máximo)
  const freq = 50 + ratio * 130;
  motorOscillator.frequency.setTargetAtTime(freq, ctx.currentTime, 0.1);
  // Volume proporcional à velocidade
  const vol = (0.04 + ratio * 0.1) * volumes.efeitos;
  motorGain.gain.setTargetAtTime(vol, ctx.currentTime, 0.1);
}

/**
 * Para o som do motor
 */
export function pararMotor() {
  if (motorOscillator) {
    try {
      motorOscillator.stop();
    } catch (e) {}
    motorOscillator = null;
    motorGain = null;
  }
}

/**
 * Inicia música de fundo alegre (gerada via Web Audio)
 * Melodia simples em Dó maior, looping
 */
export function iniciarMusica() {
  if (musicaAtiva) return;
  musicaAtiva = true;

  try {
    const ctx = getAudioContext();
    musicaGain = ctx.createGain();
    musicaGain.gain.value = volumes.musica * 0.25;
    musicaGain.connect(ctx.destination);

    // Notas da melodia (frequências em Hz) - melodia alegre infantil
    const melodia = [
      // Compasso 1
      { nota: 523, dur: 0.3 },  // Dó
      { nota: 523, dur: 0.3 },  // Dó
      { nota: 784, dur: 0.3 },  // Sol
      { nota: 784, dur: 0.3 },  // Sol
      { nota: 880, dur: 0.3 },  // Lá
      { nota: 880, dur: 0.3 },  // Lá
      { nota: 784, dur: 0.6 },  // Sol (longa)
      // Compasso 2
      { nota: 698, dur: 0.3 },  // Fá
      { nota: 698, dur: 0.3 },  // Fá
      { nota: 659, dur: 0.3 },  // Mi
      { nota: 659, dur: 0.3 },  // Mi
      { nota: 587, dur: 0.3 },  // Ré
      { nota: 587, dur: 0.3 },  // Ré
      { nota: 523, dur: 0.6 },  // Dó (longa)
    ];

    let notaIndex = 0;
    let proximoTempo = ctx.currentTime + 0.1;

    function tocarProximaNota() {
      if (!musicaAtiva || !musicaGain) return;
      const ctxLocal = getAudioContext();
      const { nota, dur } = melodia[notaIndex % melodia.length];

      const osc = ctxLocal.createOscillator();
      const notaGain = ctxLocal.createGain();

      osc.type = 'triangle';
      osc.frequency.value = nota;

      notaGain.gain.setValueAtTime(0, proximoTempo);
      notaGain.gain.linearRampToValueAtTime(0.3, proximoTempo + 0.02);
      notaGain.gain.linearRampToValueAtTime(0.2, proximoTempo + dur * 0.7);
      notaGain.gain.linearRampToValueAtTime(0, proximoTempo + dur);

      osc.connect(notaGain);
      notaGain.connect(musicaGain!);

      osc.start(proximoTempo);
      osc.stop(proximoTempo + dur);

      proximoTempo += dur;
      notaIndex++;

      // Agenda próxima nota
      const delay = (proximoTempo - ctxLocal.currentTime - 0.5) * 1000;
      musicaInterval = window.setTimeout(tocarProximaNota, Math.max(0, delay));
    }

    tocarProximaNota();
  } catch (e) {
    musicaAtiva = false;
  }
}

/**
 * Para a música de fundo
 */
export function pararMusica() {
  musicaAtiva = false;
  if (musicaInterval !== null) {
    clearTimeout(musicaInterval);
    musicaInterval = null;
  }
  if (musicaGain) {
    try {
      musicaGain.disconnect();
    } catch (e) {}
    musicaGain = null;
  }
}

/**
 * Inicializa o áudio (deve ser chamado após interação do usuário)
 */
export function inicializarAudio() {
  getAudioContext();
}
