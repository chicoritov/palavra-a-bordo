/**
 * Renderizador 2D para Palavra a bordo
 * Visual realista com cenário de estacionamento e carros detalhados
 */

import { Vaga, Obstaculo, Carro, fases } from './data';
import { SistemaParticulas } from './particles';

// ============================================
// FUNÇÕES AUXILIARES DE COR
// ============================================

function darkenColor(color: string, factor: number): string {
  if (color.startsWith('#')) {
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    return `rgb(${Math.floor(r * factor)}, ${Math.floor(g * factor)}, ${Math.floor(b * factor)})`;
  }
  return color;
}

function lightenColor(color: string, factor: number): string {
  if (color.startsWith('#')) {
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    return `rgb(${Math.min(255, Math.floor(r + (255 - r) * factor))}, ${Math.min(255, Math.floor(g + (255 - g) * factor))}, ${Math.min(255, Math.floor(b + (255 - b) * factor))})`;
  }
  return color;
}

function adjustColor(hex: string, percent: number): string {
  const num = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, (num >> 16) + percent));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + percent));
  const b = Math.min(255, Math.max(0, (num & 0x0000FF) + percent));
  return `rgb(${r},${g},${b})`;
}

// ============================================
// PARTE A — CENÁRIO DE ESTACIONAMENTO
// ============================================

/**
 * Renderiza o cenário de estacionamento (layout top-down)
 */
function renderizarAmbiente(ctx: CanvasRenderingContext2D, width: number, height: number, frame: number, texturaChao: any[]) {
  // === 1. FUNDO ASFALTO COM TEXTURA ===
  ctx.fillStyle = '#2d3339';
  ctx.fillRect(0, 0, width, height);
  
  // Textura de asfalto (pontos pré-definidos)
  ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
  for (const ponto of texturaChao) {
    ctx.fillRect(ponto.x, ponto.y, ponto.w, ponto.h);
  }
  
  ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
  for (let i = 0; i < texturaChao.length; i++) {
    const ponto = texturaChao[i];
    ctx.fillRect(ponto.x + 1, ponto.y + 1, 1, 1);
  }
  
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  for (let i = 0; i < texturaChao.length / 2; i++) {
    const ponto = texturaChao[i];
    ctx.fillRect(ponto.x, ponto.y, ponto.w + 1, ponto.h + 1);
  }
  
  // === 2. VAGAS DE ESTACIONAMENTO ===
  const vagaWidth = 180;
  const vagaHeight = 120;
  const marginX = 80;
  const spacingX = 40;
  
  // Fileira SUPERIOR (4 vagas)
  for (let i = 0; i < 4; i++) {
    const x = marginX + i * (vagaWidth + spacingX);
    const y = 60;
    
    // Fundo da vaga
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.fillRect(x, y, vagaWidth, vagaHeight);
    
    // Bordas brancas/creme
    ctx.strokeStyle = '#e8e4d9';
    ctx.lineWidth = 4;
    ctx.strokeRect(x, y, vagaWidth, vagaHeight);
    
    // === 3. LIMITADORES AMARELOS ===
    const limitadorWidth = vagaWidth * 0.6;
    const limitadorHeight = 10;
    const limitadorX = x + (vagaWidth - limitadorWidth) / 2;
    const limitadorY = y + vagaHeight - limitadorHeight - 5;
    
    // Sombra do limitador
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.beginPath();
    ctx.ellipse(limitadorX + limitadorWidth / 2, limitadorY + limitadorHeight + 2, limitadorWidth / 2, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Limitador com gradiente
    const limitadorGrad = ctx.createLinearGradient(limitadorX, limitadorY, limitadorX, limitadorY + limitadorHeight);
    limitadorGrad.addColorStop(0, '#d4a843');
    limitadorGrad.addColorStop(1, '#b8922e');
    ctx.fillStyle = limitadorGrad;
    ctx.beginPath();
    ctx.roundRect(limitadorX, limitadorY, limitadorWidth, limitadorHeight, 6);
    ctx.fill();
    
    // Brilho no topo
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(limitadorX + 6, limitadorY + 2);
    ctx.lineTo(limitadorX + limitadorWidth - 6, limitadorY + 2);
    ctx.stroke();
  }
  
  // Fileira INFERIOR (4 vagas)
  for (let i = 0; i < 4; i++) {
    const x = marginX + i * (vagaWidth + spacingX);
    const y = height - vagaHeight - 60;
    
    // Fundo da vaga
    ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.fillRect(x, y, vagaWidth, vagaHeight);
    
    // Bordas brancas/creme
    ctx.strokeStyle = '#e8e4d9';
    ctx.lineWidth = 4;
    ctx.strokeRect(x, y, vagaWidth, vagaHeight);
    
    // Limitador amarelo (parte superior da vaga)
    const limitadorWidth = vagaWidth * 0.6;
    const limitadorHeight = 10;
    const limitadorX = x + (vagaWidth - limitadorWidth) / 2;
    const limitadorY = y + 5;
    
    // Sombra do limitador
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.beginPath();
    ctx.ellipse(limitadorX + limitadorWidth / 2, limitadorY + limitadorHeight + 2, limitadorWidth / 2, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    
    // Limitador com gradiente
    const limitadorGrad = ctx.createLinearGradient(limitadorX, limitadorY, limitadorX, limitadorY + limitadorHeight);
    limitadorGrad.addColorStop(0, '#d4a843');
    limitadorGrad.addColorStop(1, '#b8922e');
    ctx.fillStyle = limitadorGrad;
    ctx.beginPath();
    ctx.roundRect(limitadorX, limitadorY, limitadorWidth, limitadorHeight, 6);
    ctx.fill();
    
    // Brilho no topo
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(limitadorX + 6, limitadorY + 2);
    ctx.lineTo(limitadorX + limitadorWidth - 6, limitadorY + 2);
    ctx.stroke();
  }
  
  // === 4. CANTEIRO CENTRAL ===
  const canteiroY = height / 2 - 40;
  const canteiroHeight = 80;
  const canteiroMargin = 60;
  
  // Borda externa (concreto)
  ctx.fillStyle = '#8a8a8a';
  ctx.beginPath();
  ctx.roundRect(canteiroMargin, canteiroY, width - canteiroMargin * 2, canteiroHeight, 40);
  ctx.fill();
  
  // Interior (terra)
  ctx.fillStyle = '#3d2817';
  ctx.beginPath();
  ctx.roundRect(canteiroMargin + 8, canteiroY + 8, width - canteiroMargin * 2 - 16, canteiroHeight - 16, 35);
  ctx.fill();
  
  // Arbustos densos (posições pré-definidas)
  const tonsVerde = ['#1e6b35', '#2d8a4e', '#3da55f', '#4ec46f', '#6dd47e'];
  const canteiroInnerX = canteiroMargin + 15;
  const canteiroInnerY = canteiroY + 15;
  const canteiroInnerW = width - canteiroMargin * 2 - 30;
  const canteiroInnerH = canteiroHeight - 30;
  
  // 100 arbustos
  for (let i = 0; i < 100; i++) {
    const seed = i * 7919;
    const x = canteiroInnerX + ((seed * 13) % canteiroInnerW);
    const y = canteiroInnerY + ((seed * 17) % canteiroInnerH);
    const r = 8 + ((seed * 23) % 11);
    const cor = tonsVerde[i % 5];
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.beginPath();
    ctx.arc(x + 1, y + 1, r, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = cor;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // 50 arbustos menores por cima
  for (let i = 0; i < 50; i++) {
    const seed = (i + 100) * 7919;
    const x = canteiroInnerX + ((seed * 13) % canteiroInnerW);
    const y = canteiroInnerY + ((seed * 17) % canteiroInnerH);
    const r = 6 + ((seed * 23) % 8);
    const cor = tonsVerde[(i + 2) % 5];
    
    ctx.fillStyle = cor;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.beginPath();
    ctx.arc(x - r / 3, y - r / 3, r / 2, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // 20 flores
  for (let i = 0; i < 20; i++) {
    const seed = (i + 200) * 7919;
    const x = canteiroInnerX + ((seed * 13) % canteiroInnerW);
    const y = canteiroInnerY + ((seed * 17) % canteiroInnerH);
    const r = 3 + ((seed * 23) % 3);
    
    ctx.fillStyle = i % 2 === 0 ? '#f5e6e8' : '#ffffff';
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = '#ffeb3b';
    ctx.beginPath();
    ctx.arc(x, y, r / 3, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // === 5. SETAS DE DIREÇÃO ===
  const setaHeight = 140;
  const setaWidth = 28;
  
  // Seta ESQUERDA (apontando para BAIXO)
  const setaLeftX = 30;
  const setaLeftY = height / 2;
  
  ctx.save();
  ctx.translate(setaLeftX, setaLeftY);
  
  // Sombra
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.beginPath();
  ctx.moveTo(2, -setaHeight / 2 + 2);
  ctx.lineTo(setaWidth / 2 + 2, -setaHeight / 4 + 2);
  ctx.lineTo(setaWidth / 4 + 2, -setaHeight / 4 + 2);
  ctx.lineTo(setaWidth / 4 + 2, setaHeight / 2 + 2);
  ctx.lineTo(-setaWidth / 4 + 2, setaHeight / 2 + 2);
  ctx.lineTo(-setaWidth / 4 + 2, -setaHeight / 4 + 2);
  ctx.lineTo(-setaWidth / 2 + 2, -setaHeight / 4 + 2);
  ctx.closePath();
  ctx.fill();
  
  // Seta com gradiente
  const setaGrad = ctx.createLinearGradient(0, -setaHeight / 2, 0, setaHeight / 2);
  setaGrad.addColorStop(0, '#ffffff');
  setaGrad.addColorStop(1, '#cccccc');
  ctx.fillStyle = setaGrad;
  ctx.beginPath();
  ctx.moveTo(0, -setaHeight / 2);
  ctx.lineTo(setaWidth / 2, -setaHeight / 4);
  ctx.lineTo(setaWidth / 4, -setaHeight / 4);
  ctx.lineTo(setaWidth / 4, setaHeight / 2);
  ctx.lineTo(-setaWidth / 4, setaHeight / 2);
  ctx.lineTo(-setaWidth / 4, -setaHeight / 4);
  ctx.lineTo(-setaWidth / 2, -setaHeight / 4);
  ctx.closePath();
  ctx.fill();
  
  ctx.strokeStyle = '#555555';
  ctx.lineWidth = 2;
  ctx.stroke();
  
  ctx.restore();
  
  // Seta DIREITA (apontando para CIMA)
  const setaRightX = width - 30;
  const setaRightY = height / 2;
  
  ctx.save();
  ctx.translate(setaRightX, setaRightY);
  
  // Sombra
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.beginPath();
  ctx.moveTo(2, setaHeight / 2 + 2);
  ctx.lineTo(setaWidth / 2 + 2, setaHeight / 4 + 2);
  ctx.lineTo(setaWidth / 4 + 2, setaHeight / 4 + 2);
  ctx.lineTo(setaWidth / 4 + 2, -setaHeight / 2 + 2);
  ctx.lineTo(-setaWidth / 4 + 2, -setaHeight / 2 + 2);
  ctx.lineTo(-setaWidth / 4 + 2, setaHeight / 4 + 2);
  ctx.lineTo(-setaWidth / 2 + 2, setaHeight / 4 + 2);
  ctx.closePath();
  ctx.fill();
  
  // Seta com gradiente
  const setaGrad2 = ctx.createLinearGradient(0, -setaHeight / 2, 0, setaHeight / 2);
  setaGrad2.addColorStop(0, '#cccccc');
  setaGrad2.addColorStop(1, '#ffffff');
  ctx.fillStyle = setaGrad2;
  ctx.beginPath();
  ctx.moveTo(0, setaHeight / 2);
  ctx.lineTo(setaWidth / 2, setaHeight / 4);
  ctx.lineTo(setaWidth / 4, setaHeight / 4);
  ctx.lineTo(setaWidth / 4, -setaHeight / 2);
  ctx.lineTo(-setaWidth / 4, -setaHeight / 2);
  ctx.lineTo(-setaWidth / 4, setaHeight / 4);
  ctx.lineTo(-setaWidth / 2, setaHeight / 4);
  ctx.closePath();
  ctx.fill();
  
  ctx.strokeStyle = '#555555';
  ctx.lineWidth = 2;
  ctx.stroke();
  
  ctx.restore();
  
  // Borda do cenário
  ctx.strokeStyle = '#1a1e22';
  ctx.lineWidth = 5;
  ctx.strokeRect(0, 0, width, height);
  
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.lineWidth = 8;
  ctx.strokeRect(4, 4, width - 8, height - 8);
  
  // Efeito vignette
  const vignetteGrad = ctx.createRadialGradient(
    width / 2, height / 2, Math.min(width, height) / 3,
    width / 2, height / 2, Math.max(width, height) / 1.5
  );
  vignetteGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
  vignetteGrad.addColorStop(1, 'rgba(0, 0, 0, 0.25)');
  ctx.fillStyle = vignetteGrad;
  ctx.fillRect(0, 0, width, height);
}

// ============================================
// PARTE B — REDESIGN DOS CARROS (MODULAR)
// ============================================

/**
 * Desenha a sombra projetada do carro
 * CORREÇÃO: Sombra proporcional ao carro alongado
 */
function drawCarShadow(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  // Calcular dimensões do carro visual
  const carLength = w * 1.8;
  const carWidth = h;
  const offsetX = (w - carLength) / 2;
  
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.beginPath();
  ctx.ellipse(x + offsetX + carLength / 2 + 3, y + carWidth / 2 + 4, carLength * 0.55, carWidth * 0.6, 0, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * Desenha as rodas do carro
 * CORREÇÃO: Rodas proporcionais ao carro alongado
 */
function drawCarWheels(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  // Calcular dimensões do carro visual
  const carLength = w * 1.8;
  const carWidth = h;
  const offsetX = (w - carLength) / 2;
  
  // Rodas proporcionais ao carro alongado
  const wheelWidth = carLength * 0.08; // 8% do comprimento
  const wheelHeight = carWidth * 0.15; // 15% da largura
  const wheelOffset = 2;
  
  ctx.fillStyle = '#1a1a1a';
  
  // Roda frente-esquerda
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.75 - wheelWidth/2, y + wheelOffset, wheelWidth, wheelHeight, 2);
  ctx.fill();
  
  // Roda frente-direita
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.75 - wheelWidth/2, y + carWidth - wheelHeight - wheelOffset, wheelWidth, wheelHeight, 2);
  ctx.fill();
  
  // Roda traseira-esquerda
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.25 - wheelWidth/2, y + wheelOffset, wheelWidth, wheelHeight, 2);
  ctx.fill();
  
  // Roda traseira-direita
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.25 - wheelWidth/2, y + carWidth - wheelHeight - wheelOffset, wheelWidth, wheelHeight, 2);
  ctx.fill();
  
  // Aros internos
  ctx.fillStyle = '#555';
  const aroWidth = wheelWidth * 0.6;
  const aroHeight = wheelHeight * 0.6;
  
  // Aro frente-esquerda
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.75 - aroWidth/2, y + wheelOffset + (wheelHeight - aroHeight)/2, aroWidth, aroHeight, 1);
  ctx.fill();
  
  // Aro frente-direita
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.75 - aroWidth/2, y + carWidth - wheelHeight - wheelOffset + (wheelHeight - aroHeight)/2, aroWidth, aroHeight, 1);
  ctx.fill();
  
  // Aro traseira-esquerda
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.25 - aroWidth/2, y + wheelOffset + (wheelHeight - aroHeight)/2, aroWidth, aroHeight, 1);
  ctx.fill();
  
  // Aro traseira-direita
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.25 - aroWidth/2, y + carWidth - wheelHeight - wheelOffset + (wheelHeight - aroHeight)/2, aroWidth, aroHeight, 1);
  ctx.fill();
}

/**
 * Desenha a carroceria do carro com gradiente
 * CORREÇÃO FINAL: Silhueta com proporção realista de carro
 */
function drawCarBody(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string) {
  // Gradiente vertical (topo claro, base escura)
  const bodyGrad = ctx.createLinearGradient(x, y, x, y + h);
  bodyGrad.addColorStop(0, adjustColor(color, 40));
  bodyGrad.addColorStop(0.5, color);
  bodyGrad.addColorStop(1, adjustColor(color, -30));
  ctx.fillStyle = bodyGrad;
  
  // Silhueta de carro realista (proporção 1:1.8)
  // O carro é desenhado mais comprido que a hitbox
  const carLength = w * 1.8; // Comprimento 1.8x a largura
  const carWidth = h;
  const offsetX = (w - carLength) / 2; // Centralizar
  
  ctx.beginPath();
  
  // Traseira (mais reta e quadrada)
  ctx.moveTo(x + offsetX + carLength * 0.05, y + carWidth * 0.1);
  ctx.lineTo(x + offsetX + carLength * 0.05, y + carWidth * 0.9);
  
  // Lado inferior (reto)
  ctx.lineTo(x + offsetX + carLength * 0.85, y + carWidth * 0.9);
  
  // Frente inferior (arredondada)
  ctx.quadraticCurveTo(x + offsetX + carLength * 0.95, y + carWidth * 0.9, x + offsetX + carLength * 0.95, y + carWidth * 0.75);
  
  // Frente (reta)
  ctx.lineTo(x + offsetX + carLength * 0.95, y + carWidth * 0.25);
  
  // Frente superior (arredondada)
  ctx.quadraticCurveTo(x + offsetX + carLength * 0.95, y + carWidth * 0.1, x + offsetX + carLength * 0.85, y + carWidth * 0.1);
  
  // Lado superior (reto)
  ctx.lineTo(x + offsetX + carLength * 0.05, y + carWidth * 0.1);
  
  ctx.closePath();
  ctx.fill();
  
  // Contorno escuro
  ctx.strokeStyle = darkenColor(color, 0.5);
  ctx.lineWidth = 2;
  ctx.stroke();
  
  // Linha divisória central
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x + offsetX + carLength * 0.1, y + carWidth * 0.5);
  ctx.lineTo(x + offsetX + carLength * 0.9, y + carWidth * 0.5);
  ctx.stroke();
  
  // Reflexo no capô
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.save();
  ctx.translate(x + offsetX + carLength * 0.7, y + carWidth * 0.3);
  ctx.rotate(-0.2);
  ctx.fillRect(-carLength * 0.15, -carWidth * 0.05, carLength * 0.3, carWidth * 0.1);
  ctx.restore();
}

/**
 * Desenha os para-brisas do carro
 * CORREÇÃO: Para-brisas proporcionais ao carro alongado
 */
function drawCarWindows(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  // Calcular dimensões do carro visual
  const carLength = w * 1.8;
  const carWidth = h;
  const offsetX = (w - carLength) / 2;
  
  // Para-brisa dianteiro (70% da largura, 20% do comprimento)
  ctx.fillStyle = 'rgba(26, 42, 58, 0.8)';
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.6, y + carWidth * 0.15, carLength * 0.2, carWidth * 0.7, 3);
  ctx.fill();
  
  // Reflexo diagonal
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(x + offsetX + carLength * 0.65, y + carWidth * 0.2);
  ctx.lineTo(x + offsetX + carLength * 0.75, y + carWidth * 0.8);
  ctx.stroke();
  
  // Vidro traseiro (65% da largura, 15% do comprimento)
  ctx.fillStyle = 'rgba(26, 42, 58, 0.9)';
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.15, y + carWidth * 0.175, carLength * 0.15, carWidth * 0.65, 3);
  ctx.fill();
}

/**
 * Desenha os faróis e lanternas do carro
 * CORREÇÃO: Faróis e lanternas proporcionais ao carro alongado
 */
function drawCarLights(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  // Calcular dimensões do carro visual
  const carLength = w * 1.8;
  const carWidth = h;
  const offsetX = (w - carLength) / 2;
  
  // Faróis dianteiros (12% do comprimento, 10% da largura)
  const headlightWidth = carLength * 0.06;
  const headlightHeight = carWidth * 0.12;
  
  // Halo amarelo
  const haloGrad1 = ctx.createRadialGradient(
    x + offsetX + carLength * 0.92, y + carWidth * 0.25, 0,
    x + offsetX + carLength * 0.92, y + carWidth * 0.25, carWidth * 0.15
  );
  haloGrad1.addColorStop(0, 'rgba(255, 244, 163, 0.3)');
  haloGrad1.addColorStop(1, 'rgba(255, 244, 163, 0)');
  ctx.fillStyle = haloGrad1;
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.92, y + carWidth * 0.25, carWidth * 0.15, 0, Math.PI * 2);
  ctx.fill();
  
  const haloGrad2 = ctx.createRadialGradient(
    x + offsetX + carLength * 0.92, y + carWidth * 0.75, 0,
    x + offsetX + carLength * 0.92, y + carWidth * 0.75, carWidth * 0.15
  );
  haloGrad2.addColorStop(0, 'rgba(255, 244, 163, 0.3)');
  haloGrad2.addColorStop(1, 'rgba(255, 244, 163, 0)');
  ctx.fillStyle = haloGrad2;
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.92, y + carWidth * 0.75, carWidth * 0.15, 0, Math.PI * 2);
  ctx.fill();
  
  // Faróis
  ctx.fillStyle = '#fff4a3';
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.89, y + carWidth * 0.2, headlightWidth, headlightHeight, 2);
  ctx.fill();
  
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.89, y + carWidth * 0.7, headlightWidth, headlightHeight, 2);
  ctx.fill();
  
  // Brilho interno
  ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.92, y + carWidth * 0.25, 2, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.92, y + carWidth * 0.75, 2, 0, Math.PI * 2);
  ctx.fill();
  
  // Lanternas traseiras (10% do comprimento, 8% da largura)
  const taillightWidth = carLength * 0.05;
  const taillightHeight = carWidth * 0.1;
  
  ctx.fillStyle = '#ff3333';
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.05, y + carWidth * 0.22, taillightWidth, taillightHeight, 2);
  ctx.fill();
  
  ctx.beginPath();
  ctx.roundRect(x + offsetX + carLength * 0.05, y + carWidth * 0.68, taillightWidth, taillightHeight, 2);
  ctx.fill();
  
  // Brilho interno
  ctx.fillStyle = 'rgba(255, 150, 150, 0.7)';
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.075, y + carWidth * 0.27, 1.5, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.beginPath();
  ctx.arc(x + offsetX + carLength * 0.075, y + carWidth * 0.73, 1.5, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * Função principal para desenhar um carro completo
 * ORDEM: sombra → rodas → carroceria → para-brisas → faróis → destaque jogador
 */
function drawCar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string, isPlayer: boolean = false) {
  // 1. Sombra projetada (primeiro, embaixo de tudo)
  drawCarShadow(ctx, x, y, w, h);
  
  // 2. Rodas (depois da sombra, antes da carroceria para ficarem visíveis nas laterais)
  drawCarWheels(ctx, x, y, w, h);
  
  // 3. Carroceria com gradiente (por cima das rodas)
  drawCarBody(ctx, x, y, w, h, color);
  
  // 4. Para-brisas (por cima da carroceria)
  drawCarWindows(ctx, x, y, w, h);
  
  // 5. Faróis e lanternas (por cima de tudo)
  drawCarLights(ctx, x, y, w, h);
  
  // 6. Destaque para carro do jogador (contorno branco sutil)
  if (isPlayer) {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(255, 255, 255, 0.5)';
    ctx.shadowBlur = 8;
    
    // Calcular dimensões do carro visual
    const carLength = w * 1.8;
    const carWidth = h;
    const offsetX = (w - carLength) / 2;
    
    // Refaz o path da carroceria para o contorno
    ctx.beginPath();
    ctx.moveTo(x + offsetX + carLength * 0.05, y + carWidth * 0.1);
    ctx.lineTo(x + offsetX + carLength * 0.05, y + carWidth * 0.9);
    ctx.lineTo(x + offsetX + carLength * 0.85, y + carWidth * 0.9);
    ctx.quadraticCurveTo(x + offsetX + carLength * 0.95, y + carWidth * 0.9, x + offsetX + carLength * 0.95, y + carWidth * 0.75);
    ctx.lineTo(x + offsetX + carLength * 0.95, y + carWidth * 0.25);
    ctx.quadraticCurveTo(x + offsetX + carLength * 0.95, y + carWidth * 0.1, x + offsetX + carLength * 0.85, y + carWidth * 0.1);
    ctx.lineTo(x + offsetX + carLength * 0.05, y + carWidth * 0.1);
    ctx.closePath();
    ctx.stroke();
    
    ctx.shadowBlur = 0;
  }
}

/**
 * Renderiza uma vaga 2D com efeitos visuais
 */
function renderizarVaga(
  ctx: CanvasRenderingContext2D,
  vaga: Vaga,
  frame: number,
  vagaAtual: Vaga | null,
  vagaDestacada: Vaga | null,
  tempoNaVaga: number
) {
  // Determina cor baseada no estado
  let corBase = '#4a4a4a';
  let corBorda = '#ffffff';
  
  if (vaga.estado === 'acerto') {
    corBase = '#2ecc71';
    corBorda = '#27ae60';
  } else if (vaga.estado === 'erro') {
    corBase = '#e74c3c';
    corBorda = '#c0392b';
  } else if (vagaDestacada === vaga) {
    const piscar = Math.sin(frame * 0.3) > 0;
    corBase = piscar ? '#f39c12' : '#e67e22';
    corBorda = '#d35400';
  } else if (vagaAtual === vaga) {
    corBase = '#3498db';
    corBorda = '#2980b9';
  }
  
  // Sombra projetada
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.beginPath();
  ctx.ellipse(vaga.x + vaga.w / 2, vaga.y + vaga.h + 5, vaga.w / 2, 8, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Base da vaga com gradiente
  const baseGrad = ctx.createLinearGradient(vaga.x, vaga.y, vaga.x, vaga.y + vaga.h);
  baseGrad.addColorStop(0, corBase);
  baseGrad.addColorStop(1, darkenColor(corBase, 0.8));
  ctx.fillStyle = baseGrad;
  ctx.fillRect(vaga.x, vaga.y, vaga.w, vaga.h);
  
  // Bordas
  ctx.strokeStyle = corBorda;
  ctx.lineWidth = 3;
  ctx.setLineDash(vagaDestacada === vaga ? [] : [8, 4]);
  ctx.strokeRect(vaga.x + 2, vaga.y + 2, vaga.w - 4, vaga.h - 4);
  ctx.setLineDash([]);
  
  // Fundo semi-transparente escuro para texto
  ctx.fillStyle = 'rgba(20, 25, 30, 0.75)';
  ctx.beginPath();
  ctx.roundRect(vaga.x + 5, vaga.y + vaga.h / 2 - 20, vaga.w - 10, 40, 6);
  ctx.fill();
  
  // Sombra da caixa
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.beginPath();
  ctx.roundRect(vaga.x + 5, vaga.y + vaga.h / 2 - 17, vaga.w - 10, 40, 6);
  ctx.fill();
  
  // Texto da palavra (amarelo para melhor visibilidade)
  ctx.fillStyle = '#FFD700';
  ctx.font = 'bold 16px Georgia';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
  ctx.lineWidth = 3;
  ctx.strokeText(vaga.palavra, vaga.x + vaga.w / 2, vaga.y + vaga.h / 2);
  ctx.fillText(vaga.palavra, vaga.x + vaga.w / 2, vaga.y + vaga.h / 2);
  
  // Barra de progresso
  if (vagaAtual === vaga && tempoNaVaga > 0 && vaga.estado === 'normal') {
    const progresso = Math.min(1, tempoNaVaga / 60);
    
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(vaga.x + 5, vaga.y + vaga.h - 12, vaga.w - 10, 8);
    
    const barGrad = ctx.createLinearGradient(vaga.x + 5, 0, vaga.x + vaga.w - 5, 0);
    barGrad.addColorStop(0, '#2ecc71');
    barGrad.addColorStop(1, '#27ae60');
    ctx.fillStyle = barGrad;
    ctx.fillRect(vaga.x + 5, vaga.y + vaga.h - 12, (vaga.w - 10) * progresso, 8);
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.lineWidth = 1;
    ctx.strokeRect(vaga.x + 5, vaga.y + vaga.h - 12, vaga.w - 10, 8);
  }
}

/**
 * Renderiza um carro 2D com rotação e efeitos
 */
function renderizarCarro(
  ctx: CanvasRenderingContext2D,
  carro: Carro,
  frame: number,
  ehJogador: boolean = false,
  emoji: string = ''
) {
  const x = carro.x;
  const y = carro.y;
  const w = carro.w;
  const h = carro.h;
  const cor = carro.cor;
  
  // CORREÇÃO: Remover escala distorcida
  // Usar dimensões originais para manter proporções corretas
  const visualW = w;
  const visualH = h;
  
  ctx.save();
  ctx.translate(x + w / 2, y + h / 2);
  
  // Rotação baseada na direção
  let rotation = 0;
  if (carro.direcao === 'direita') rotation = 0;
  else if (carro.direcao === 'baixo') rotation = Math.PI / 2;
  else if (carro.direcao === 'esquerda') rotation = Math.PI;
  else if (carro.direcao === 'cima') rotation = -Math.PI / 2;
  
  ctx.rotate(rotation);
  
  // Inclinação (curva)
  if (ehJogador && carro.inclinacao !== 0) {
    ctx.rotate(carro.inclinacao * 0.05);
  }
  
  // Oscilação (balanço)
  if (ehJogador && carro.oscilacao !== 0) {
    ctx.translate(0, carro.oscilacao);
  }
  
  // Desenha o carro com proporção visual ajustada
  // Centraliza o carro visualmente maior
  drawCar(ctx, -visualW / 2, -visualH / 2, visualW, visualH, cor, ehJogador);
  
  ctx.restore();
  
  // Emoji acima do carro
  if (ehJogador && emoji) {
    ctx.save();
    const floatOffset = Math.sin(frame * 0.1) * 3;
    ctx.translate(x + w / 2, y - 30 + floatOffset);
    
    // Balão
    ctx.fillStyle = 'white';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetY = 3;
    
    ctx.beginPath();
    ctx.arc(0, 0, 20, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;
    
    // Ponteiro
    ctx.beginPath();
    ctx.moveTo(-5, 18);
    ctx.lineTo(0, 26);
    ctx.lineTo(5, 18);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    // Emoji
    ctx.font = '24px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(emoji, 0, 0);
    
    ctx.restore();
  }
}

/**
 * Renderiza o guarda de trânsito animado
 */
function renderizarGuarda(ctx: CanvasRenderingContext2D, x: number, y: number, frame: number, mensagem: string = '') {
  ctx.save();
  ctx.translate(x, y);
  
  // Balanço suave
  const balanco = Math.sin(frame * 0.05) * 2;
  ctx.rotate(balanco * 0.02);
  
  // Sombra
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(0, 35, 15, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  
  // Pernas
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-8, 15, 6, 20);
  ctx.fillRect(2, 15, 6, 20);
  
  // Sapatos
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(-9, 32, 8, 4);
  ctx.fillRect(1, 32, 8, 4);
  
  // Corpo
  ctx.fillStyle = '#2C3E50';
  ctx.beginPath();
  ctx.moveTo(-12, -5);
  ctx.lineTo(12, -5);
  ctx.lineTo(10, 18);
  ctx.lineTo(-10, 18);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#1a1a1a';
  ctx.lineWidth = 1;
  ctx.stroke();
  
  // Cinto
  ctx.fillStyle = '#8B4513';
  ctx.fillRect(-10, 12, 20, 4);
  ctx.fillStyle = '#FFD700';
  ctx.fillRect(-2, 12, 4, 4);
  
  // Braços
  const angBraco = Math.sin(frame * 0.08) * 0.3;
  ctx.save();
  ctx.translate(-12, 0);
  ctx.rotate(-0.3 + angBraco);
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-3, 0, 6, 18);
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, 20, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  
  ctx.save();
  ctx.translate(12, 0);
  ctx.rotate(0.3 - angBraco * 1.5);
  ctx.fillStyle = '#2C3E50';
  ctx.fillRect(-3, 0, 6, 18);
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, 20, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  
  // Cabeça
  ctx.fillStyle = '#FDBCB4';
  ctx.beginPath();
  ctx.arc(0, -15, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 0.5;
  ctx.stroke();
  
  // Olhos
  ctx.fillStyle = '#333';
  ctx.beginPath();
  ctx.arc(-4, -17, 1.5, 0, Math.PI * 2);
  ctx.arc(4, -17, 1.5, 0, Math.PI * 2);
  ctx.fill();
  
  // Sorriso
  ctx.strokeStyle = '#333';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(0, -12, 4, 0.1, Math.PI - 0.1);
  ctx.stroke();
  
  // Quepe
  ctx.fillStyle = '#1a1a1a';
  ctx.beginPath();
  ctx.ellipse(0, -24, 12, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(-10, -28, 20, 6);
  ctx.fillStyle = '#FFD700';
  ctx.beginPath();
  ctx.arc(0, -25, 3, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.restore();
  
  // Balão de fala
  if (mensagem) {
    ctx.save();
    ctx.font = 'bold 11px Georgia';
    const larguraTexto = ctx.measureText(mensagem).width + 20;
    const bx = x - larguraTexto / 2;
    const by = y - 70;
    
    ctx.fillStyle = 'white';
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    const r = 10;
    ctx.beginPath();
    ctx.moveTo(bx + r, by);
    ctx.lineTo(bx + larguraTexto - r, by);
    ctx.quadraticCurveTo(bx + larguraTexto, by, bx + larguraTexto, by + r);
    ctx.lineTo(bx + larguraTexto, by + 30 - r);
    ctx.quadraticCurveTo(bx + larguraTexto, by + 30, bx + larguraTexto - r, by + 30);
    ctx.lineTo(bx + r, by + 30);
    ctx.quadraticCurveTo(bx, by + 30, bx, by + 30 - r);
    ctx.lineTo(bx, by + r);
    ctx.quadraticCurveTo(bx, by, bx + r, by);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.moveTo(x - 5, by + 30);
    ctx.lineTo(x, by + 40);
    ctx.lineTo(x + 5, by + 30);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#333';
    ctx.beginPath();
    ctx.moveTo(x - 5, by + 30);
    ctx.lineTo(x, by + 40);
    ctx.lineTo(x + 5, by + 30);
    ctx.stroke();
    
    ctx.fillStyle = '#333';
    ctx.font = 'bold 11px Georgia';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(mensagem, x, by + 15);
    ctx.restore();
  }
}

/**
 * Renderizador principal 2D
 */
export function renderizar2D(
  ctx: CanvasRenderingContext2D,
  texturaChao: any[],
  vagas: Vaga[],
  obstaculos: Obstaculo[],
  carro: Carro,
  faseAtual: number,
  vagaAtual: Vaga | null,
  tempoNaVaga: number,
  particulas: SistemaParticulas,
  frame: number,
  vagaDestacada: Vaga | null = null,
  opacidadeTransicao: number = 0,
  mostrarGuarda: boolean = false,
  mensagemGuarda: string = ''
) {
  const width = ctx.canvas.width;
  const height = ctx.canvas.height;
  
  // Limpa canvas
  ctx.clearRect(0, 0, width, height);
  
  // Renderiza ambiente
  renderizarAmbiente(ctx, width, height, frame, texturaChao);
  
  // Renderiza partículas
  particulas.renderizar(ctx);
  
  // Renderiza obstáculos
  for (const obs of obstaculos) {
    const carroObs: Carro = {
      ...obs,
      velocidade: 0,
      direcao: obs.direcao,
      direcaoAlvo: obs.direcao,
      inclinacao: 0,
      oscilacao: 0
    };
    renderizarCarro(ctx, carroObs, frame, false, '');
  }
  
  // Renderiza vagas
  for (const vaga of vagas) {
    renderizarVaga(ctx, vaga, frame, vagaAtual, vagaDestacada, tempoNaVaga);
  }
  
  // Renderiza carro do jogador
  const emoji = fases[faseAtual]?.imagem || '';
  renderizarCarro(ctx, carro, frame, true, emoji);
  
  // Renderiza guarda de trânsito
  if (mostrarGuarda) {
    renderizarGuarda(ctx, 820, 260, frame, mensagemGuarda);
  }
  
  // Transição fade
  if (opacidadeTransicao > 0) {
    ctx.fillStyle = `rgba(0, 0, 0, ${opacidadeTransicao})`;
    ctx.fillRect(0, 0, width, height);
  }
}
