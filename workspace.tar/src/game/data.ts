/**
 * Dados do Jogo Palavra a bordo
 * Contém: fases (36), conquistas, tipos e funções de geração
 */

export interface Fase {
  imagem: string;
  correta: string;
  opcoes: string[];
  categoria?: string;
  dificuldade?: number; // 1-3
}

export interface Conquista {
  id: string;
  titulo: string;
  descricao: string;
  icone: string;
  condicao: (stats: EstatisticasJogador) => boolean;
}

export interface EstatisticasJogador {
  fasesCompletadas: number;
  totalAcertos: number;
  totalErros: number;
  fasesSemErro: number;
  melhorSequencia: number;
  palavrasErradas: Record<string, number>;
  conquistasDesbloqueadas: string[];
  estrelasPorFase: number[];
  tempoTotal: number;
}

export const fases: Fase[] = [
  // ============ FASES 1-3: Pares mínimos simples (troca de 1 consoante) ============
  { imagem: '🏠', correta: 'CASA', opcoes: ['CARTA', 'CAMA', 'CASA', 'COMA', 'CAÇA'], categoria: 'moradia', dificuldade: 1 },
  { imagem: '🐱', correta: 'GATO', opcoes: ['GATO', 'PATO', 'RATO', 'MATO', 'DADO'], categoria: 'animais', dificuldade: 1 },
  { imagem: '🐸', correta: 'SAPO', opcoes: ['SAPO', 'PATO', 'RATO', 'GATO', 'CAPO'], categoria: 'animais', dificuldade: 1 },

  // ============ FASES 4-6: Consoantes iniciais ============
  { imagem: '🦆', correta: 'PATO', opcoes: ['PATO', 'GATO', 'RATO', 'LATO', 'MATO'], categoria: 'animais', dificuldade: 1 },
  { imagem: '🐭', correta: 'RATO', opcoes: ['RATO', 'PATO', 'GATO', 'MATO', 'LATO'], categoria: 'animais', dificuldade: 1 },
  { imagem: '🐄', correta: 'VACA', opcoes: ['VACA', 'FACA', 'JACA', 'TACA', 'MACA'], categoria: 'animais', dificuldade: 1 },

  // ============ FASES 7-9: Consoantes iniciais + vogais ============
  { imagem: '🔪', correta: 'FACA', opcoes: ['FACA', 'VACA', 'JACA', 'TACA', 'MACA'], categoria: 'objetos', dificuldade: 1 },
  { imagem: '🎲', correta: 'DADO', opcoes: ['DADO', 'GATO', 'PATO', 'RATO', 'MATO'], categoria: 'objetos', dificuldade: 1 },
  { imagem: '🍎', correta: 'MAÇÃ', opcoes: ['MAÇÃ', 'MANA', 'MALA', 'MAPA', 'MATA'], categoria: 'alimentos', dificuldade: 2 },

  // ============ FASES 10-12: Palavras maiores ============
  { imagem: '🍌', correta: 'BANANA', opcoes: ['BANANA', 'BANDANA', 'BACANA', 'BARATA', 'BALA'], categoria: 'alimentos', dificuldade: 2 },
  { imagem: '🚢', correta: 'NAVIO', opcoes: ['NAVIO', 'NOVIO', 'RAVIO', 'NAVI', 'NAVE'], categoria: 'transportes', dificuldade: 2 },
  { imagem: '✈️', correta: 'AVIÃO', opcoes: ['AVIÃO', 'ANÃO', 'AVIA', 'AVIAR', 'ANIL'], categoria: 'transportes', dificuldade: 2 },

  // ============ FASES 13-15: Sons complexos ============
  { imagem: '✏️', correta: 'LÁPIS', opcoes: ['LÁPIS', 'LÁBIO', 'LAMA', 'LATA', 'LATA'], categoria: 'objetos', dificuldade: 2 },
  { imagem: '🥁', correta: 'TAMBOR', opcoes: ['TAMBOR', 'TAMPA', 'TANQUE', 'TANTO', 'TIMBER'], categoria: 'objetos', dificuldade: 2 },
  { imagem: '4️⃣', correta: 'QUATRO', opcoes: ['QUATRO', 'QUARTO', 'QUASE', 'QUADRA', 'QUEDA'], categoria: 'números', dificuldade: 2 },

  // ============ FASES 16-18: Palavras longas ============
  { imagem: '🐊', correta: 'JACARÉ', opcoes: ['JACARÉ', 'JACÁ', 'JACARE', 'JAGUAR', 'JABUTI'], categoria: 'animais', dificuldade: 3 },
  { imagem: '🐢', correta: 'TARTARUGA', opcoes: ['TARTARUGA', 'TARTARO', 'TATU', 'TARJA', 'TARIFA'], categoria: 'animais', dificuldade: 3 },
  { imagem: '♟️', correta: 'XADREZ', opcoes: ['XADREZ', 'XAROPE', 'XALE', 'XAMPU', 'XANGÔ'], categoria: 'objetos', dificuldade: 3 },

  // ============ FASES 19-24: Novas palavras - Animais ============
  { imagem: '🐶', correta: 'CACHORRO', opcoes: ['CACHORRO', 'CACHO', 'CAMARO', 'CATETO', 'CABELO'], categoria: 'animais', dificuldade: 2 },
  { imagem: '🐴', correta: 'CAVALO', opcoes: ['CAVALO', 'CAMA', 'CABELO', 'CANA', 'CAVO'], categoria: 'animais', dificuldade: 2 },
  { imagem: '🐟', correta: 'PEIXE', opcoes: ['PEIXE', 'PEITO', 'PEGA', 'PENTE', 'PEDRA'], categoria: 'animais', dificuldade: 2 },
  { imagem: '🦁', correta: 'LEÃO', opcoes: ['LEÃO', 'LEITE', 'LENÇO', 'LEMA', 'LEVA'], categoria: 'animais', dificuldade: 2 },
  { imagem: '🐦', correta: 'PÁSSARO', opcoes: ['PÁSSARO', 'PATO', 'PAPA', 'PANO', 'PARE'], categoria: 'animais', dificuldade: 3 },
  { imagem: '🦋', correta: 'BORBOLETA', opcoes: ['BORBOLETA', 'BOTA', 'BOLO', 'BOLA', 'BOMBA'], categoria: 'animais', dificuldade: 3 },

  // ============ FASES 25-30: Alimentos e objetos ============
  { imagem: '🍞', correta: 'PÃO', opcoes: ['PÃO', 'PAT', 'PÁ', 'PÉ', 'PI'], categoria: 'alimentos', dificuldade: 1 },
  { imagem: '🧀', correta: 'QUEIJO', opcoes: ['QUEIJO', 'QUEIMA', 'QUENTE', 'QUER', 'QUEDA'], categoria: 'alimentos', dificuldade: 2 },
  { imagem: '🍕', correta: 'PIZZA', opcoes: ['PIZZA', 'PIZA', 'PITA', 'PINO', 'PILHA'], categoria: 'alimentos', dificuldade: 2 },
  { imagem: '📚', correta: 'LIVRO', opcoes: ['LIVRO', 'LIDO', 'LIGA', 'LIMA', 'LI'], categoria: 'objetos', dificuldade: 2 },
  { imagem: '🎨', correta: 'TINTA', opcoes: ['TINTA', 'TINA', 'TIRA', 'TICA', 'TIA'], categoria: 'objetos', dificuldade: 2 },
  { imagem: '⚽', correta: 'BOLA', opcoes: ['BOLA', 'BOTA', 'BOCA', 'BOTA', 'BICO'], categoria: 'objetos', dificuldade: 1 },

  // ============ FASES 31-36: Sílabas complexas (LH, NH, CH, RR, SS) ============
  { imagem: '🔑', correta: 'CHAVE', opcoes: ['CHAVE', 'CAVE', 'CHAPA', 'CHA', 'CHEIA'], categoria: 'objetos', dificuldade: 3 },
  { imagem: '🌧️', correta: 'CHUVA', opcoes: ['CHUVA', 'CUVA', 'CHAPA', 'CHIA', 'CHUTA'], categoria: 'natureza', dificuldade: 3 },
  { imagem: '🍫', correta: 'ACHOCOLATADO', opcoes: ['ACHOCOLATADO', 'ACHATADO', 'ACOLHIDO', 'ACHADO', 'ACOLHER'], categoria: 'alimentos', dificuldade: 3 },
  { imagem: '👨', correta: 'MENINO', opcoes: ['MENINO', 'MENIR', 'MENOS', 'MEL', 'MENTA'], categoria: 'pessoas', dificuldade: 2 },
  { imagem: '🌈', correta: 'ARCO-ÍRIS', opcoes: ['ARCO-ÍRIS', 'ARCO', 'ARCA', 'ARMA', 'ARTE'], categoria: 'natureza', dificuldade: 3 },
  { imagem: '🦜', correta: 'PASSARINHO', opcoes: ['PASSARINHO', 'PATO', 'PAPAGAIO', 'PAREDE', 'PASTEL'], categoria: 'animais', dificuldade: 3 },
];

/**
 * Lista de conquistas do jogo
 */
export const conquistas: Conquista[] = [
  {
    id: 'primeiro_acerto',
    titulo: 'Primeiro Passo',
    descricao: 'Acerte sua primeira fase!',
    icone: '🌟',
    condicao: (s) => s.totalAcertos >= 1
  },
  {
    id: 'cinco_fases',
    titulo: 'Estudante Dedicado',
    descricao: 'Complete 5 fases',
    icone: '📚',
    condicao: (s) => s.fasesCompletadas >= 5
  },
  {
    id: 'dez_fases',
    titulo: 'Meio Caminho',
    descricao: 'Complete 10 fases',
    icone: '🏅',
    condicao: (s) => s.fasesCompletadas >= 10
  },
  {
    id: 'todas_fases',
    titulo: 'Mestre do Estacionamento',
    descricao: 'Complete todas as 36 fases',
    icone: '🏆',
    condicao: (s) => s.fasesCompletadas >= 36
  },
  {
    id: 'sem_erros_5',
    titulo: 'Memória de Elefante',
    descricao: 'Complete 5 fases seguidas sem errar',
    icone: '🧠',
    condicao: (s) => s.melhorSequencia >= 5
  },
  {
    id: 'sem_erros_10',
    titulo: 'Gênio da Alfabetização',
    descricao: 'Complete 10 fases seguidas sem errar',
    icone: '🎓',
    condicao: (s) => s.melhorSequencia >= 10
  },
  {
    id: 'estrela_tripla',
    titulo: 'Perfeccionista',
    descricao: 'Ganhe 3 estrelas em 5 fases',
    icone: '⭐',
    condicao: (s) => s.estrelasPorFase.filter(e => e === 3).length >= 5
  },
  {
    id: 'veloz',
    titulo: 'Piloto Veloz',
    descricao: 'Complete 10 fases em menos de 5 minutos no total',
    icone: '⚡',
    condicao: (s) => s.fasesCompletadas >= 10 && s.tempoTotal < 300
  },
  {
    id: 'explorador',
    titulo: 'Explorador de Palavras',
    descricao: 'Acerte 20 palavras diferentes',
    icone: '🗺️',
    condicao: (s) => s.totalAcertos >= 20
  },
  {
    id: 'persistente',
    titulo: 'Persistente',
    descricao: 'Tente 50 vezes (acertos + erros)',
    icone: '💪',
    condicao: (s) => (s.totalAcertos + s.totalErros) >= 50
  },
];

export const modelosCarros = ['esportivo', 'sedã', 'hatch', 'compacto', 'caminhonete', 'van', 'moto', 'fusca', 'policial'] as const;
export const coresCarros = ['#3498DB', '#2ECC71', '#F39C12', '#9B59B6', '#1ABC9C', '#E67E22', '#34495E', '#7F8C8D', '#C0392B', '#16A085'];

export interface Vaga {
  x: number;
  y: number;
  w: number;
  h: number;
  palavra: string;
  correta: boolean;
  estado: 'normal' | 'acerto' | 'erro';
  fileira: 'cima' | 'meio' | 'baixo';
  numero: number;
}

export interface Obstaculo {
  x: number;
  y: number;
  w: number;
  h: number;
  cor: string;
  modelo: string;
  direcao: string;
}

export interface Carro {
  x: number;
  y: number;
  w: number;
  h: number;
  velocidade: number;
  cor: string;
  modelo: string;
  direcao: string;
  direcaoAlvo: string;
  inclinacao: number; // para animação de curva
  oscilacao: number; // para balanço ao parar
}

export interface TexturaPonto {
  x: number;
  y: number;
  w: number;
  h: number;
}

/**
 * Gera textura do chão (pré-calculada para performance)
 */
export function gerarTexturaChao(): TexturaPonto[] {
  const pontos: TexturaPonto[] = [];
  for (let i = 0; i < 300; i++) {
    pontos.push({
      x: Math.random() * 900,
      y: Math.random() * 500,
      w: 1 + Math.random() * 2,
      h: 1 + Math.random() * 2
    });
  }
  return pontos;
}

export type LayoutTipo = 'classico' | 'shopping';

/**
 * Gera uma fase com vagas e obstáculos aleatórios
 */
export function gerarFase(faseAtual: number, layout: LayoutTipo = 'classico'): { vagas: Vaga[]; obstaculos: Obstaculo[] } {
  if (layout === 'shopping') {
    return gerarFaseShopping(faseAtual);
  }
  return gerarFaseClassica(faseAtual);
}

/**
 * Layout Clássico: 2 fileiras de 10 vagas (topo e base)
 */
function gerarFaseClassica(faseAtual: number): { vagas: Vaga[]; obstaculos: Obstaculo[] } {
  const fase = fases[faseAtual];
  const vagas: Vaga[] = [];
  const obstaculos: Obstaculo[] = [];

  const numVagas = 10;
  const larguraVaga = 80;
  const espacamento = 10;
  const inicioX = 30;

  const opcoesEmbaralhadas = [...fase.opcoes].sort(() => Math.random() - 0.5);
  const palavrasCima = opcoesEmbaralhadas.slice(0, 3);
  const palavrasBaixo = opcoesEmbaralhadas.slice(3, 5);

  const posicoesDisponiveis = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  const posCima: number[] = [];
  const posBaixo: number[] = [];

  for (let i = 0; i < 3; i++) {
    const idx = Math.floor(Math.random() * posicoesDisponiveis.length);
    posCima.push(posicoesDisponiveis.splice(idx, 1)[0]);
  }
  for (let i = 0; i < 2; i++) {
    const idx = Math.floor(Math.random() * posicoesDisponiveis.length);
    posBaixo.push(posicoesDisponiveis.splice(idx, 1)[0]);
  }

  posCima.forEach((pos, i) => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    vagas.push({
      x, y: 30, w: larguraVaga, h: 80,
      palavra: palavrasCima[i],
      correta: palavrasCima[i] === fase.correta,
      estado: 'normal',
      fileira: 'cima',
      numero: 623 - pos
    });
  });

  posBaixo.forEach((pos, idx) => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    vagas.push({
      x, y: 390, w: larguraVaga, h: 80,
      palavra: palavrasBaixo[idx],
      correta: palavrasBaixo[idx] === fase.correta,
      estado: 'normal',
      fileira: 'baixo',
      numero: 664 - pos
    });
  });

  const todasPosCima = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].filter(p => !posCima.includes(p));
  const todasPosBaixo = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].filter(p => !posBaixo.includes(p));

  todasPosCima.forEach(pos => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    obstaculos.push({
      x, y: 35, w: 60, h: 70,
      cor: coresCarros[Math.floor(Math.random() * coresCarros.length)],
      modelo: modelosCarros[Math.floor(Math.random() * modelosCarros.length)],
      direcao: 'baixo'
    });
  });

  todasPosBaixo.forEach(pos => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    obstaculos.push({
      x, y: 395, w: 60, h: 70,
      cor: coresCarros[Math.floor(Math.random() * coresCarros.length)],
      modelo: modelosCarros[Math.floor(Math.random() * modelosCarros.length)],
      direcao: 'cima'
    });
  });

  return { vagas, obstaculos };
}

/**
 * Layout Shopping: 3 fileiras de vagas com corredores conectando
 * Fileira superior (5 vagas), fileira central (5 vagas), fileira inferior (5 vagas)
 */
function gerarFaseShopping(faseAtual: number): { vagas: Vaga[]; obstaculos: Obstaculo[] } {
  const fase = fases[faseAtual];
  const vagas: Vaga[] = [];
  const obstaculos: Obstaculo[] = [];

  const numVagas = 5;
  const larguraVaga = 80;
  const espacamento = 10;
  const inicioX = 180; // Centralizado

  const opcoesEmbaralhadas = [...fase.opcoes].sort(() => Math.random() - 0.5);
  const palavrasTopo = opcoesEmbaralhadas.slice(0, 2);
  const palavrasMeio = opcoesEmbaralhadas.slice(2, 4);
  const palavrasBase = opcoesEmbaralhadas.slice(4, 5);

  // Fileira superior (y = 30)
  const posTopo: number[] = [];
  const posicoesTopo = [0, 1, 2, 3, 4];
  for (let i = 0; i < 2; i++) {
    const idx = Math.floor(Math.random() * posicoesTopo.length);
    posTopo.push(posicoesTopo.splice(idx, 1)[0]);
  }

  posTopo.forEach((pos, i) => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    vagas.push({
      x, y: 30, w: larguraVaga, h: 70,
      palavra: palavrasTopo[i],
      correta: palavrasTopo[i] === fase.correta,
      estado: 'normal',
      fileira: 'cima',
      numero: 101 - pos
    });
  });

  // Fileira central (y = 215)
  const posMeio: number[] = [];
  const posicoesMeio = [0, 1, 2, 3, 4];
  for (let i = 0; i < 2; i++) {
    const idx = Math.floor(Math.random() * posicoesMeio.length);
    posMeio.push(posicoesMeio.splice(idx, 1)[0]);
  }

  posMeio.forEach((pos, i) => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    vagas.push({
      x, y: 215, w: larguraVaga, h: 70,
      palavra: palavrasMeio[i],
      correta: palavrasMeio[i] === fase.correta,
      estado: 'normal',
      fileira: 'meio',
      numero: 201 - pos
    });
  });

  // Fileira inferior (y = 400)
  const posBase: number[] = [];
  const posicoesBase = [0, 1, 2, 3, 4];
  for (let i = 0; i < 1; i++) {
    const idx = Math.floor(Math.random() * posicoesBase.length);
    posBase.push(posicoesBase.splice(idx, 1)[0]);
  }

  posBase.forEach((pos, i) => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    vagas.push({
      x, y: 400, w: larguraVaga, h: 70,
      palavra: palavrasBase[i],
      correta: palavrasBase[i] === fase.correta,
      estado: 'normal',
      fileira: 'baixo',
      numero: 301 - pos
    });
  });

  // Obstáculos nas posições não ocupadas por vagas
  const todasPosTopo = [0, 1, 2, 3, 4].filter(p => !posTopo.includes(p));
  const todasPosMeio = [0, 1, 2, 3, 4].filter(p => !posMeio.includes(p));
  const todasPosBase = [0, 1, 2, 3, 4].filter(p => !posBase.includes(p));

  todasPosTopo.forEach(pos => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    obstaculos.push({
      x, y: 35, w: 60, h: 60,
      cor: coresCarros[Math.floor(Math.random() * coresCarros.length)],
      modelo: modelosCarros[Math.floor(Math.random() * modelosCarros.length)],
      direcao: 'baixo'
    });
  });

  todasPosMeio.forEach(pos => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    obstaculos.push({
      x, y: 220, w: 60, h: 60,
      cor: coresCarros[Math.floor(Math.random() * coresCarros.length)],
      modelo: modelosCarros[Math.floor(Math.random() * modelosCarros.length)],
      direcao: 'cima'
    });
  });

  todasPosBase.forEach(pos => {
    const x = inicioX + pos * (larguraVaga + espacamento);
    obstaculos.push({
      x, y: 405, w: 60, h: 60,
      cor: coresCarros[Math.floor(Math.random() * coresCarros.length)],
      modelo: modelosCarros[Math.floor(Math.random() * modelosCarros.length)],
      direcao: 'cima'
    });
  });

  return { vagas, obstaculos };
}

/**
 * Cria estatísticas iniciais do jogador
 */
export function criarEstatisticasIniciais(): EstatisticasJogador {
  return {
    fasesCompletadas: 0,
    totalAcertos: 0,
    totalErros: 0,
    fasesSemErro: 0,
    melhorSequencia: 0,
    palavrasErradas: {},
    conquistasDesbloqueadas: [],
    estrelasPorFase: [],
    tempoTotal: 0
  };
}

/**
 * Salva estatísticas no localStorage
 */
export function salvarEstatisticas(stats: EstatisticasJogador) {
  try {
    localStorage.setItem('palavra_a_bordo_stats', JSON.stringify(stats));
  } catch (e) {}
}

/**
 * Carrega estatísticas do localStorage
 */
export function carregarEstatisticas(): EstatisticasJogador {
  try {
    const data = localStorage.getItem('palavra_a_bordo_stats');
    if (data) return JSON.parse(data);
  } catch (e) {}
  return criarEstatisticasIniciais();
}

/**
 * Verifica novas conquistas desbloqueadas
 */
export function verificarConquistas(stats: EstatisticasJogador): Conquista[] {
  const novas: Conquista[] = [];
  for (const conquista of conquistas) {
    if (!stats.conquistasDesbloqueadas.includes(conquista.id) && conquista.condicao(stats)) {
      novas.push(conquista);
    }
  }
  return novas;
}
