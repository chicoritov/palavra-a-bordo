/**
 * ============================================
 * PALAVRA A BORDO
 * Componente Principal - Design Elegante
 * ============================================
 * 
 * Jogo educativo de alfabetização com design
 * sofisticado e acolhedor para crianças.
 * 
 * Design System:
 * - Paleta: Azul-petróleo, creme, dourado
 * - Fonte: Georgia (serifada, elegante)
 * - Animações: Suaves, apenas transform/opacity
 * - Acessibilidade: Contraste 7:1, foco visível
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import {
  fases, gerarFase, gerarTexturaChao, criarEstatisticasIniciais,
  salvarEstatisticas, carregarEstatisticas, verificarConquistas,
  conquistas, LayoutTipo,
  Vaga, Obstaculo, Carro, TexturaPonto, EstatisticasJogador, Conquista
} from './game/data';
import { renderizar2D } from './game/renderer2d';
import { SistemaParticulas } from './game/particles';
import {
  falar, somAcerto, somErro, somBatida, somBuzina, somConquista,
  iniciarMotor, atualizarMotor, pararMotor,
  iniciarMusica, pararMusica, inicializarAudio,
  setVolumes, getVolumes
} from './game/audio';
import { getPerguntasFase, PerguntaQuiz } from './game/quizData';
import { useTraducoes, getMensagemAleatoria, Idioma } from './game/traducoes';

type Tela = 'telaInicial' | 'menu' | 'jogando' | 'quiz' | 'conquistas' | 'configuracoes' | 'comoJogar' | 'final';

function colide(a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) {
  const margem = 4;
  return (a.x + margem) < (b.x + b.w - margem) &&
    (a.x + a.w - margem) > (b.x + margem) &&
    (a.y + margem) < (b.y + b.h - margem) &&
    (a.y + a.h - margem) > (b.y + margem);
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [tela, setTela] = useState<Tela>('telaInicial');
  const [faseAtual, setFaseAtual] = useState(0);
  const [acertos, setAcertos] = useState(0);
  const [mensagem, setMensagem] = useState('Use as setas ⬆️⬇️⬅️➡️ para dirigir até a vaga certa!');
  const [canvasWidth, setCanvasWidth] = useState(900);
  const [stats, setStats] = useState<EstatisticasJogador>(carregarEstatisticas());
  const [novaConquista, setNovaConquista] = useState<Conquista | null>(null);
  const [estrelasFase, setEstrelasFase] = useState(0);
  const [errosFaseAtual, setErrosFaseAtual] = useState(0);
  const [audioInicializado, setAudioInicializado] = useState(false);
  const [volumesUI, setVolumesUI] = useState(getVolumes());
  const [musicaLigada, setMusicaLigada] = useState(false);
  const [modeloCarro, setModeloCarro] = useState<string>(() => {
    try {
      return localStorage.getItem('palavra_a_bordo_carro') || 'esportivo';
    } catch { return 'esportivo'; }
  });

  // Estados do Quiz
  const [quizPerguntaAtual, setQuizPerguntaAtual] = useState(0);
  const [quizRespostaSelecionada, setQuizRespostaSelecionada] = useState<number | null>(null);
  const [quizRespostaCorreta, setQuizRespostaCorreta] = useState(false);
  const [quizRespostaErrada, setQuizRespostaErrada] = useState(false);
  const [quizPerguntas, setQuizPerguntas] = useState<PerguntaQuiz[]>([]);
  const [quizAcertos, setQuizAcertos] = useState(0);
  const [somLigado, setSomLigado] = useState(true);
  const [idioma, setIdioma] = useState<Idioma>('pt');
  const t = useTraducoes(idioma);

  const gameState = useRef({
    faseAtual: 0,
    acertos: 0,
    jogoAtivo: true,
    errosNaFase: 0,
    frame: 0,
    tempoInicioFase: 0,
    layout: 'classico' as LayoutTipo,
    carro: {
      x: 100, y: 240, w: 60, h: 70,
      velocidade: 2.8, cor: '#E74C3C', modelo: 'esportivo',
      direcao: 'direita', direcaoAlvo: 'direita',
      inclinacao: 0, oscilacao: 0
    } as Carro,
    vagas: [] as Vaga[],
    obstaculos: [] as Obstaculo[],
    tempoNaVaga: 0,
    vagaAtual: null as Vaga | null,
    texturaChao: gerarTexturaChao() as TexturaPonto[],
    keys: { up: false, down: false, left: false, right: false },
    animFrame: 0,
    particulas: new SistemaParticulas(),
    opacidadeTransicao: 0,
    transicaoAtiva: false,
    vagaDestacada: null as Vaga | null,
    tempoDestaque: 0,
    mostrarGuarda: false,
    mensagemGuarda: '',
    tempoGuarda: 0,
    farolAceso: false,
    tempoFarol: 0,
    stats: carregarEstatisticas() as EstatisticasJogador,
    ultimoFrameMovimento: 0,
    ultimaBatida: 0 // Cooldown para som de batida (corrige bug #7)
  });

  const inicializarFase = useCallback((fase: number) => {
    const state = gameState.current;
    state.faseAtual = fase;
    const { vagas, obstaculos } = gerarFase(fase, state.layout);
    state.vagas = vagas;
    state.obstaculos = obstaculos;
    
    // Posição inicial baseada no layout
    if (state.layout === 'shopping') {
      state.carro.x = 50;
      state.carro.y = 150; // Corredor superior
    } else {
      state.carro.x = 50;
      state.carro.y = 240; // Corredor central
    }
    
    state.carro.direcao = 'direita';
    state.carro.direcaoAlvo = 'direita';
    state.carro.inclinacao = 0;
    state.carro.oscilacao = 0;
    state.tempoNaVaga = 0;
    state.vagaAtual = null;
    state.jogoAtivo = true;
    state.errosNaFase = 0;
    state.tempoInicioFase = Date.now();
    state.particulas.limpar();
    state.vagaDestacada = null;
    state.mostrarGuarda = fase === 0; // Mostra guarda na primeira fase
    state.mensagemGuarda = fase === 0 ? 'Dirija até a palavra certa!' : '';
    state.tempoGuarda = fase === 0 ? 180 : 0;
    setFaseAtual(fase);
    setErrosFaseAtual(0);
    setMensagem('Dirija até a vaga com a palavra certa!');
  }, []);

  const iniciarJogo = useCallback(() => {
    if (!audioInicializado) {
      inicializarAudio();
      iniciarMotor();
      setAudioInicializado(true);
    }
    // Aplica o modelo de carro escolhido
    gameState.current.carro.modelo = modeloCarro;
    setTela('jogando');
    inicializarFase(0);
  }, [audioInicializado, inicializarFase, modeloCarro]);

  const proximaFase = useCallback(() => {
    const state = gameState.current;
    const novaFase = state.faseAtual + 1;
    if (novaFase >= fases.length) {
      setTela('final');
      falar('Parabéns! Você completou todas as fases!');
    } else {
      // Muda a tela de volta para 'jogando' após o quiz
      setTela('jogando');
      
      // Transição fade
      state.transicaoAtiva = true;
      state.opacidadeTransicao = 0;
      setTimeout(() => {
        inicializarFase(novaFase);
      }, 300);
    }
  }, [inicializarFase]);

  const iniciarQuiz = useCallback((faseIndex: number) => {
    const perguntas = getPerguntasFase(faseIndex);
    setQuizPerguntas(perguntas);
    setQuizPerguntaAtual(0);
    setQuizRespostaSelecionada(null);
    setQuizRespostaCorreta(false);
    setQuizRespostaErrada(false);
    setQuizAcertos(0);
    setTela('quiz');
    
    // Lê automaticamente a primeira pergunta após 500ms
    setTimeout(() => {
      if (perguntas.length > 0) {
        falar(perguntas[0].pergunta);
      }
    }, 500);
  }, []);

  const responderQuiz = useCallback((opcaoIndex: number) => {
    if (quizRespostaCorreta || quizRespostaErrada) return; // Evita múltiplas respostas

    const perguntaAtual = quizPerguntas[quizPerguntaAtual];
    setQuizRespostaSelecionada(opcaoIndex);

    if (opcaoIndex === perguntaAtual.correta) {
      // Resposta correta
      setQuizRespostaCorreta(true);
      somAcerto();
      const novosAcertos = quizAcertos + 1;
      setQuizAcertos(novosAcertos);

      // Avança para próxima pergunta após 1 segundo
      setTimeout(() => {
        if (quizPerguntaAtual < quizPerguntas.length - 1) {
          // Ainda há perguntas
          const novaPerguntaIndex = quizPerguntaAtual + 1;
          setQuizPerguntaAtual(novaPerguntaIndex);
          setQuizRespostaSelecionada(null);
          setQuizRespostaCorreta(false);
          
          // Lê automaticamente a próxima pergunta
          setTimeout(() => {
            falar(quizPerguntas[novaPerguntaIndex].pergunta);
          }, 300);
        } else {
          // Quiz completo - vai para próxima fase
          proximaFase();
        }
      }, 1000);
    } else {
      // Resposta errada
      setQuizRespostaErrada(true);
      somErro();

      // Permite tentar novamente após 1 segundo
      setTimeout(() => {
        setQuizRespostaSelecionada(null);
        setQuizRespostaErrada(false);
      }, 1000);
    }
  }, [quizPerguntas, quizPerguntaAtual, quizRespostaCorreta, quizRespostaErrada, quizAcertos, proximaFase]);

  const reiniciar = useCallback(() => {
    const state = gameState.current;
    const novasStats = criarEstatisticasIniciais();
    state.stats = novasStats;
    setStats(novasStats);
    salvarEstatisticas(novasStats);
    setAcertos(0);
    setEstrelasFase(0);
    setErrosFaseAtual(0);
    setNovaConquista(null);
    setTela('menu');
  }, []);

  const falarPalavra = useCallback(() => {
    const state = gameState.current;
    if (fases[state.faseAtual]) {
      falar(fases[state.faseAtual].correta);
    }
  }, []);

  const usarDica = useCallback(() => {
    const state = gameState.current;
    const vagaCorreta = state.vagas.find(v => v.correta);
    if (vagaCorreta) {
      state.vagaDestacada = vagaCorreta;
      state.tempoDestaque = 120; // 2 segundos a 60fps
      state.mensagemGuarda = 'Aqui está a dica!';
      state.mostrarGuarda = true;
      state.tempoGuarda = 120;
    }
  }, []);

  const toggleMusica = useCallback(() => {
    if (musicaLigada) {
      pararMusica();
      setMusicaLigada(false);
    } else {
      iniciarMusica();
      setMusicaLigada(true);
    }
  }, [musicaLigada]);

  const alternarLayout = useCallback(() => {
    const state = gameState.current;
    state.layout = state.layout === 'classico' ? 'shopping' : 'classico';
    // Reinicia a fase atual com o novo layout
    inicializarFase(state.faseAtual);
  }, [inicializarFase]);

  const escolherCarro = useCallback((modelo: string) => {
    setModeloCarro(modelo);
    try {
      localStorage.setItem('palavra_a_bordo_carro', modelo);
    } catch {}
  }, []);

  // Ajustar canvas responsivo
  useEffect(() => {
    function ajustarCanvas() {
      // Considerar padding de 32px (16px de cada lado) + margem de segurança
      const padding = 32;
      const maxW = Math.min(window.innerWidth - padding, 900);
      setCanvasWidth(maxW);
    }
    ajustarCanvas();
    window.addEventListener('resize', ajustarCanvas);
    return () => window.removeEventListener('resize', ajustarCanvas);
  }, []);

  // Cleanup ao desmontar
  useEffect(() => {
    return () => {
      pararMotor();
      pararMusica();
    };
  }, []);

  // Input handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const state = gameState.current;
      if (tela !== 'jogando') return;
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') { state.keys.up = true; e.preventDefault(); }
      if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') { state.keys.down = true; e.preventDefault(); }
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') { state.keys.left = true; e.preventDefault(); }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') { state.keys.right = true; e.preventDefault(); }
      if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        // Buzina
        somBuzina();
        state.farolAceso = true;
        state.tempoFarol = 30;
        state.particulas.adicionarFaiscas(state.carro.x + state.carro.w, state.carro.y + state.carro.h / 2, 5);
      }
      if (e.key === 'h' || e.key === 'H') {
        usarDica();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      const state = gameState.current;
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') state.keys.up = false;
      if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') state.keys.down = false;
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') state.keys.left = false;
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') state.keys.right = false;
    };
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('keyup', handleKeyUp);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('keyup', handleKeyUp);
    };
  }, [tela, usarDica]);

  // Game loop
  useEffect(() => {
    if (tela !== 'jogando') return;
    let running = true;

    function update() {
      const state = gameState.current;
      state.frame++;

      // Transição fade
      if (state.transicaoAtiva) {
        if (state.opacidadeTransicao < 1) {
          state.opacidadeTransicao += 0.05;
        } else {
          state.transicaoAtiva = false;
        }
      } else if (state.opacidadeTransicao > 0) {
        state.opacidadeTransicao -= 0.05;
      }

      // Atualiza destaque da dica
      if (state.tempoDestaque > 0) {
        state.tempoDestaque--;
        if (state.tempoDestaque <= 0) {
          state.vagaDestacada = null;
        }
      }

      // Atualiza guarda
      if (state.tempoGuarda > 0) {
        state.tempoGuarda--;
        if (state.tempoGuarda <= 0) {
          state.mostrarGuarda = false;
          state.mensagemGuarda = '';
        }
      }

      // Atualiza farol
      if (state.tempoFarol > 0) {
        state.tempoFarol--;
        if (state.tempoFarol <= 0) {
          state.farolAceso = false;
        }
      }

      if (!state.jogoAtivo) {
        state.particulas.atualizar();
        return;
      }

      const { carro, keys } = state;
      let dx = 0, dy = 0;
      if (keys.up) dy -= carro.velocidade;
      if (keys.down) dy += carro.velocidade;
      if (keys.left) dx -= carro.velocidade;
      if (keys.right) dx += carro.velocidade;

      if (dx !== 0 && dy !== 0) { dx *= 0.707; dy *= 0.707; }

      // Direção e inclinação
      if (dx > 0) carro.direcaoAlvo = 'direita';
      else if (dx < 0) carro.direcaoAlvo = 'esquerda';
      else if (dy > 0) carro.direcaoAlvo = 'baixo';
      else if (dy < 0) carro.direcaoAlvo = 'cima';

      if (dx !== 0 || dy !== 0) {
        carro.direcao = carro.direcaoAlvo;
        // Inclinação nas curvas
        if (dx !== 0) {
          carro.inclinacao = dx > 0 ? 1 : -1;
        } else {
          carro.inclinacao = 0;
        }
        state.ultimoFrameMovimento = state.frame;

        // Fumaça ao acelerar
        if (state.frame % 8 === 0) {
          const traseiraX = carro.direcao === 'direita' ? carro.x : carro.direcao === 'esquerda' ? carro.x + carro.w : carro.x + carro.w / 2;
          const traseiraY = carro.direcao === 'cima' ? carro.y + carro.h : carro.direcao === 'baixo' ? carro.y : carro.y + carro.h / 2;
          state.particulas.adicionarFumaca(traseiraX, traseiraY, 2);
        }

        // Marcas de pneu
        if (state.frame % 4 === 0) {
          const angulo = carro.direcao === 'direita' ? 0 : carro.direcao === 'esquerda' ? Math.PI :
            carro.direcao === 'cima' ? -Math.PI / 2 : Math.PI / 2;
          state.particulas.adicionarMarcaPneu(carro.x + carro.w / 2, carro.y + carro.h / 2, angulo);
        }
      } else {
        // Oscilação ao parar (balanço)
        const tempoParado = state.frame - state.ultimoFrameMovimento;
        if (tempoParado < 15) {
          carro.oscilacao = Math.sin(tempoParado * 0.5) * 2 * (1 - tempoParado / 15);
        } else {
          carro.oscilacao = 0;
        }
        carro.inclinacao *= 0.9; // Relaxa inclinação
      }

      // Atualiza motor
      const velocidade = Math.sqrt(dx * dx + dy * dy);
      atualizarMotor(velocidade, carro.velocidade);

      const canvas = canvasRef.current;
      if (!canvas) return;
      const cw = canvas.width;
      const ch = canvas.height;

      // Move X
      const novoX = carro.x + dx;
      const testeX = { x: novoX, y: carro.y, w: carro.w, h: carro.h };
      let colidiu = false;

      if (novoX < 10 || novoX + carro.w > cw - 10) colidiu = true;
      for (const obs of state.obstaculos) { if (colide(testeX, obs)) { colidiu = true; break; } }
      
      // Verifica colisão com vagas - SIMPLIFICADO
      // Vagas são áreas onde o carro PODE entrar, não obstáculos
      // Só bloqueia se o carro estiver tentando entrar de lado (não alinhado)
      for (const v of state.vagas) {
        if (colide(testeX, v)) {
          // Verifica se o carro está alinhado com a vaga
          const centroCarroX = testeX.x + testeX.w / 2;
          const centroVagaX = v.x + v.w / 2;
          const distanciaX = Math.abs(centroCarroX - centroVagaX);
          
          // Se o centro do carro está dentro da largura da vaga, permite
          if (distanciaX > v.w / 2) {
            // Não está alinhado, bloqueia
            colidiu = true;
            break;
          }
          // Se está alinhado, permite entrar (não faz nada)
        }
      }

      if (!colidiu) {
        carro.x = novoX;
      } else if (dx !== 0) {
        // Cooldown para som de batida (corrige bug #7)
        const agora = Date.now();
        if (agora - state.ultimaBatida > 200) {
          somBatida();
          state.ultimaBatida = agora;
          state.particulas.adicionarFaiscas(
            dx > 0 ? carro.x + carro.w : carro.x,
            carro.y + carro.h / 2, 5
          );
        }
      }

      // Move Y
      const novoY = carro.y + dy;
      const testeY = { x: carro.x, y: novoY, w: carro.w, h: carro.h };
      colidiu = false;

      if (novoY < 10 || novoY + carro.h > ch - 10) colidiu = true;
      for (const obs of state.obstaculos) { if (colide(testeY, obs)) { colidiu = true; break; } }
      
      // Verifica colisão com vagas - SIMPLIFICADO
      // Vagas são áreas onde o carro PODE entrar
      // Só bloqueia se o carro não estiver alinhado com a vaga
      for (const v of state.vagas) {
        if (colide(testeY, v)) {
          // Verifica se o carro está alinhado com a vaga
          const centroCarroX = testeY.x + testeY.w / 2;
          const centroVagaX = v.x + v.w / 2;
          const distanciaX = Math.abs(centroCarroX - centroVagaX);
          
          // Se o centro do carro está dentro da largura da vaga, permite
          if (distanciaX > v.w / 2) {
            // Não está alinhado, bloqueia
            colidiu = true;
            break;
          }
          // Se está alinhado, permite entrar (não faz nada)
        }
      }

      if (!colidiu) {
        carro.y = novoY;
      } else if (dy !== 0) {
        // Cooldown para som de batida (corrige bug #7)
        const agora = Date.now();
        if (agora - state.ultimaBatida > 200) {
          somBatida();
          state.ultimaBatida = agora;
          state.particulas.adicionarFaiscas(
            carro.x + carro.w / 2,
            dy > 0 ? carro.y + carro.h : carro.y, 5
          );
        }
      }

      // Check vaga - verifica se o carro está estacionado
      let emVaga: Vaga | null = null;
      for (const v of state.vagas) {
        // Verifica se o centro do carro está dentro da vaga
        const centroCarroX = carro.x + carro.w / 2;
        const centroCarroY = carro.y + carro.h / 2;
        
        const dentroX = centroCarroX >= v.x && centroCarroX <= v.x + v.w;
        const dentroY = centroCarroY >= v.y && centroCarroY <= v.y + v.h;
        
        if (dentroX && dentroY) {
          emVaga = v;
          break;
        }
      }

      const parado = dx === 0 && dy === 0;
      if (emVaga && parado) {
        if (state.vagaAtual === emVaga) {
          state.tempoNaVaga++;
          if (state.tempoNaVaga >= 60) {
            if (emVaga.correta) {
              emVaga.estado = 'acerto';
              state.acertos++;
              setAcertos(state.acertos);
              setMensagem(`✅ Isso! ${fases[state.faseAtual].correta}!`);
              somAcerto();
              falar(`Muito bem! ${fases[state.faseAtual].correta}!`);

              // Confetes e estrelas
              state.particulas.adicionarConfetes(carro.x + carro.w / 2, carro.y, 40);
              state.particulas.adicionarEstrelas(carro.x + carro.w / 2, carro.y, 15);

              // Calcula estrelas da fase
              const estrelas = state.errosNaFase === 0 ? 3 : state.errosNaFase <= 2 ? 2 : 1;
              setEstrelasFase(estrelas);

              // Atualiza stats
              state.stats.totalAcertos++;
              state.stats.fasesCompletadas++;
              state.stats.fasesSemErro = state.errosNaFase === 0 ? state.stats.fasesSemErro + 1 : 0;
              state.stats.melhorSequencia = Math.max(state.stats.melhorSequencia, state.stats.fasesSemErro);
              state.stats.estrelasPorFase.push(estrelas);
              state.stats.tempoTotal += (Date.now() - state.tempoInicioFase) / 1000;

              // Verifica conquistas (corrige bug #9 - evita duplicatas)
              const novasConquistas = verificarConquistas(state.stats);
              if (novasConquistas.length > 0) {
                const c = novasConquistas[0];
                // Verifica se já não foi desbloqueada
                if (!state.stats.conquistasDesbloqueadas.includes(c.id)) {
                  state.stats.conquistasDesbloqueadas.push(c.id);
                  setNovaConquista(c);
                  somConquista();
                  setTimeout(() => setNovaConquista(null), 3000);
                }
              }

              setStats({ ...state.stats });
              salvarEstatisticas(state.stats);

              state.jogoAtivo = false;
              // Inicia o quiz após 2 segundos
              setTimeout(() => iniciarQuiz(state.faseAtual), 2000);
            } else {
              emVaga.estado = 'erro';
              setMensagem(`❌ Ops! Não é ${emVaga.palavra}`);
              somErro();
              falar(`Não é ${emVaga.palavra}. Tente outra vaga.`);

              // Atualiza stats de erro
              state.stats.totalErros++;
              state.errosNaFase++;
              setErrosFaseAtual(state.errosNaFase);
              if (!state.stats.palavrasErradas[emVaga.palavra]) {
                state.stats.palavrasErradas[emVaga.palavra] = 0;
              }
              state.stats.palavrasErradas[emVaga.palavra]++;
              salvarEstatisticas(state.stats);

              // Mostra guarda com dica
              state.mostrarGuarda = true;
              state.mensagemGuarda = 'Tente outra vaga!';
              state.tempoGuarda = 90;

              setTimeout(() => {
                // Respeita o layout atual (corrige bug #3)
                if (state.layout === 'shopping') {
                  carro.x = 50;
                  carro.y = 150;
                } else {
                  carro.x = 50;
                  carro.y = 240;
                }
                emVaga!.estado = 'normal';
                state.tempoNaVaga = 0;
                state.vagaAtual = null;
              }, 800);
            }
          }
        } else {
          state.vagaAtual = emVaga;
          state.tempoNaVaga = 0;
        }
      } else {
        state.tempoNaVaga = 0;
        state.vagaAtual = emVaga;
      }

      // Atualiza partículas
      state.particulas.atualizar();
    }

    function render() {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      const state = gameState.current;
      renderizar2D(
        ctx,
        state.texturaChao,
        state.vagas,
        state.obstaculos,
        state.carro,
        state.faseAtual,
        state.vagaAtual,
        state.tempoNaVaga,
        state.particulas,
        state.frame,
        state.vagaDestacada,
        state.opacidadeTransicao,
        state.mostrarGuarda,
        state.mensagemGuarda
      );
    }

    function loop() {
      if (!running) return;
      update();
      render();
      gameState.current.animFrame = requestAnimationFrame(loop);
    }

    loop();

    return () => {
      running = false;
      cancelAnimationFrame(gameState.current.animFrame);
    };
  }, [tela, proximaFase]);

  // Touch handlers
  const handleDirStart = useCallback((dir: string) => (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    gameState.current.keys[dir as keyof typeof gameState.current.keys] = true;
  }, []);

  const handleDirEnd = useCallback((dir: string) => (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    gameState.current.keys[dir as keyof typeof gameState.current.keys] = false;
  }, []);

  const handleVolumeChange = useCallback((tipo: 'musica' | 'efeitos' | 'voz', valor: number) => {
    const v = getVolumes();
    const updated = { ...v, [tipo]: valor };
    setVolumes(updated.musica, updated.efeitos, updated.voz);
    setVolumesUI(updated);
  }, []);

  const canvasHeight = Math.round(canvasWidth * (500 / 900));
  const fase = fases[faseAtual];

  // ============ TELA INICIAL ============
  if (tela === 'telaInicial') {
    const iniciarJogoDaTelaInicial = () => {
      if (!audioInicializado) {
        inicializarAudio();
        iniciarMotor();
        setAudioInicializado(true);
      }
      setTela('menu');
    };

    return (
      <main 
        className="fixed inset-0 flex flex-col items-center justify-center select-none overflow-hidden"
        style={{
          background: 'linear-gradient(180deg, #87CEEB 0%, #B0E0E6 50%, #E0F0FF 100%)',
          animation: 'fadeIn 0.5s ease-out'
        }}
        role="main"
        aria-label="Tela inicial do jogo Palavra a bordo"
      >
        {/* Céu com nuvens fofas */}
        <div className="absolute top-0 left-0 w-full h-1/2 pointer-events-none">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="absolute"
              style={{
                left: `${i * 35 + 5}%`,
                top: `${10 + i * 15}%`,
                animation: `floatCloud ${30 + i * 10}s linear infinite`,
                animationDelay: `${i * 5}s`
              }}
            >
              <div className="relative">
                <div className="w-32 h-16 bg-white rounded-full opacity-80" />
                <div className="absolute top-4 left-8 w-24 h-12 bg-white rounded-full opacity-90" />
                <div className="absolute top-2 left-16 w-20 h-10 bg-white rounded-full opacity-85" />
              </div>
            </div>
          ))}
        </div>

        {/* Sol brilhante (estático para reduzir animações) */}
        <div 
          className="absolute top-10 right-10 w-24 h-24 rounded-full"
          style={{
            background: 'radial-gradient(circle, #FFD700 0%, #FFA500 100%)',
            boxShadow: '0 0 60px rgba(255, 215, 0, 0.6)'
          }}
        />

        {/* Estrada visual (preview decorativo do jogo) */}
        <div 
          className="absolute bottom-0 left-0 w-full h-1/3 opacity-60"
          style={{
            background: 'linear-gradient(180deg, #505050 0%, #3a3a3a 100%)'
          }}
          aria-hidden="true"
        >
          {/* Linhas da estrada */}
          <div className="absolute top-1/2 left-0 w-full h-2 flex justify-around">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="w-16 h-2 bg-yellow-300 opacity-60" />
            ))}
          </div>
          
          {/* Vagas de estacionamento (preview decorativo) */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex gap-8">
            {[0, 1, 2].map((i) => (
              <div 
                key={i}
                className="w-20 h-24 border-4 border-white rounded-lg flex items-center justify-center"
                style={{
                  background: 'rgba(255, 255, 255, 0.1)',
                  animation: `fadeInUp 0.5s ease-out ${0.8 + i * 0.2}s both`
                }}
              >
                <span className="text-2xl font-bold text-white opacity-70">
                  {['GATO', 'CASA', 'SAPO'][i]}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Botão de som - posição responsiva */}
        <button
          type="button"
          onClick={() => {
            const novoEstado = !somLigado;
            setSomLigado(novoEstado);
            
            // Integrar com o sistema de áudio real
            if (novoEstado) {
              // Ativar som - restaurar volumes padrão
              setVolumes(0.3, 0.5, 0.8);
              if (!musicaLigada) {
                iniciarMusica();
                setMusicaLigada(true);
              }
            } else {
              // Desativar som - mutar tudo
              setVolumes(0, 0, 0);
              if (musicaLigada) {
                pararMusica();
                setMusicaLigada(false);
              }
            }
          }}
          className="absolute top-6 left-6 sm:left-auto sm:right-6 w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95 focus:ring-4 focus:ring-blue-300 focus:outline-none z-20"
          style={{
            background: 'rgba(255, 255, 255, 0.9)',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.2)',
            border: '3px solid rgba(255, 255, 255, 1)'
          }}
          aria-label={somLigado ? 'Desativar som' : 'Ativar som'}
          aria-pressed={somLigado}
        >
          <span className="text-3xl" aria-hidden="true">{somLigado ? '🔊' : '🔇'}</span>
        </button>

        {/* Conteúdo principal */}
        <div className="relative z-10 flex flex-col items-center gap-8 px-4">
          
          {/* Título Principal - Estilo placa de trânsito */}
          <div 
            className="relative"
            style={{
              animation: 'fadeInDown 0.8s ease-out both'
            }}
          >
            {/* Placa decorativa atrás do título */}
            <div 
              className="absolute inset-0 -m-4 rounded-3xl"
              style={{
                background: 'rgba(255, 255, 255, 0.3)',
                WebkitBackdropFilter: 'blur(10px)',
                backdropFilter: 'blur(10px)',
                border: '4px solid rgba(255, 255, 255, 0.3)'
              }}
            />
            
            <h1 
              className="relative text-4xl sm:text-5xl md:text-7xl font-black text-center uppercase"
              style={{ 
                fontFamily: 'Arial Black, Impact, sans-serif',
                color: '#ffffff',
                textShadow: '0 4px 8px rgba(0, 0, 0, 0.3), 3px 3px 0 #2C5F7C',
                letterSpacing: '0.05em',
                WebkitTextStroke: '2px #2C5F7C'
              }}
            >
              🚗 {t.titulo} 🅿️
            </h1>
          </div>

          {/* Subtítulo mais amigável */}
          <p 
            className="text-2xl md:text-3xl font-bold text-center"
            style={{ 
              fontFamily: 'Arial, sans-serif',
              color: '#1a3a52',
              textShadow: '0 2px 4px rgba(255, 255, 255, 0.9), 0 1px 2px rgba(0, 0, 0, 0.2)',
              animation: 'fadeInUp 0.8s ease-out 0.3s both'
            }}
          >
            {t.subtitulo} 🎯
          </p>

          {/* Carro do Gatinho - MAIOR e mais destacado */}
          <div 
            className="relative"
            style={{
              animation: 'slideInLeft 1s ease-out 0.5s both'
            }}
          >
            {/* Balão de fala do gatinho */}
            <div 
              className="absolute -top-20 left-1/2 -translate-x-1/2 bg-white rounded-3xl px-6 py-3 shadow-xl"
              style={{
                animation: 'bounce 2s ease-in-out infinite',
                border: '3px solid #2C5F7C'
              }}
            >
              <span className="text-2xl font-bold" style={{ color: '#2C5F7C' }}>
                {getMensagemAleatoria(idioma)}
              </span>
              <div 
                className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-0 h-0"
                style={{
                  borderLeft: '10px solid transparent',
                  borderRight: '10px solid transparent',
                  borderTop: '10px solid white'
                }}
              />
            </div>

            {/* Carro vermelho GRANDE */}
            <div 
              className="relative w-[280px] sm:w-[280px] md:w-[280px] max-w-[80vw] aspect-[280/160]"
              style={{
                animation: 'carIdle 2s ease-in-out infinite'
              }}
            >
              <canvas
                ref={(el) => {
                  if (el) {
                    const ctx = el.getContext('2d');
                    if (ctx) {
                      // Ajustar tamanho do canvas ao container
                      const container = el.parentElement;
                      if (container) {
                        el.width = container.clientWidth;
                        el.height = container.clientHeight;
                      }
                      
                      // Limpar canvas antes de desenhar
                      ctx.clearRect(0, 0, el.width, el.height);
                      
                      // Calcular escala baseada no tamanho real
                      const scaleX = el.width / 280;
                      const scaleY = el.height / 160;
                      const scale = Math.min(scaleX, scaleY) * 2.3;
                      
                      // Desenhar carro vermelho BEM MAIOR
                      ctx.save();
                      ctx.translate(el.width / 2, el.height / 2);
                      ctx.scale(scale, scale);
                      
                      // Sombra mais suave
                      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
                      ctx.beginPath();
                      ctx.ellipse(3, 5, 33, 31.5, 0, 0, Math.PI * 2);
                      ctx.fill();
                      
                      // Rodas mais detalhadas
                      ctx.fillStyle = '#1a1a1a';
                      ctx.beginPath();
                      ctx.roundRect(-27, -35, 12, 8, 2);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(15, -35, 12, 8, 2);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(-27, 27, 12, 8, 2);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(15, 27, 12, 8, 2);
                      ctx.fill();
                      
                      // Aros das rodas
                      ctx.fillStyle = '#555';
                      ctx.beginPath();
                      ctx.roundRect(-25, -33, 8, 4, 1);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(17, -33, 8, 4, 1);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(-25, 29, 8, 4, 1);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.roundRect(17, 29, 8, 4, 1);
                      ctx.fill();
                      
                      // Carroceria com gradiente mais rico
                      const grad = ctx.createLinearGradient(0, -35, 0, 35);
                      grad.addColorStop(0, '#ff6b6b');
                      grad.addColorStop(0.3, '#e74c3c');
                      grad.addColorStop(0.7, '#c0392b');
                      grad.addColorStop(1, '#a93226');
                      ctx.fillStyle = grad;
                      
                      // Silhueta assimétrica melhorada
                      ctx.beginPath();
                      ctx.moveTo(-30, 30);
                      ctx.lineTo(30, 30);
                      ctx.lineTo(35, 10);
                      ctx.lineTo(33, -5);
                      ctx.lineTo(35, -25);
                      ctx.quadraticCurveTo(30, -35, 20, -35);
                      ctx.lineTo(-20, -35);
                      ctx.quadraticCurveTo(-30, -35, -35, -25);
                      ctx.lineTo(-33, -5);
                      ctx.lineTo(-35, 10);
                      ctx.closePath();
                      ctx.fill();
                      
                      // Contorno mais grosso
                      ctx.strokeStyle = '#8b2820';
                      ctx.lineWidth = 3;
                      ctx.stroke();
                      
                      // Para-brisa mais realista
                      ctx.fillStyle = 'rgba(100, 150, 200, 0.8)';
                      ctx.beginPath();
                      ctx.roundRect(-20, -25, 40, 20, 3);
                      ctx.fill();
                      
                      // Reflexo no para-brisa
                      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
                      ctx.beginPath();
                      ctx.moveTo(-15, -22);
                      ctx.lineTo(-5, -22);
                      ctx.lineTo(-8, -15);
                      ctx.lineTo(-18, -15);
                      ctx.closePath();
                      ctx.fill();
                      
                      // Faróis acesos com glow
                      ctx.fillStyle = '#fff4a3';
                      ctx.shadowColor = '#fff4a3';
                      ctx.shadowBlur = 20;
                      ctx.beginPath();
                      ctx.arc(30, -15, 6, 0, Math.PI * 2);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.arc(30, 15, 6, 0, Math.PI * 2);
                      ctx.fill();
                      ctx.shadowBlur = 0;
                      
                      // Lanternas traseiras
                      ctx.fillStyle = '#ff0000';
                      ctx.shadowColor = '#ff0000';
                      ctx.shadowBlur = 10;
                      ctx.beginPath();
                      ctx.arc(-30, -15, 4, 0, Math.PI * 2);
                      ctx.fill();
                      ctx.beginPath();
                      ctx.arc(-30, 15, 4, 0, Math.PI * 2);
                      ctx.fill();
                      ctx.shadowBlur = 0;
                      
                      ctx.restore();
                    }
                  }
                }}
                className="w-full h-full block"
              />
            </div>
          </div>

          {/* Botão JOGAR - MAIOR e mais chamativo */}
          <button
            type="button"
            onClick={iniciarJogoDaTelaInicial}
            className="relative font-black text-4xl uppercase px-20 py-8 rounded-full transition-all duration-200 hover:scale-110 active:scale-95 focus:ring-4 focus:ring-green-300 focus:outline-none"
            style={{
              fontFamily: 'Arial Black, Impact, sans-serif',
              background: 'linear-gradient(135deg, #4caf50 0%, #388e3c 100%)',
              color: '#ffffff',
              border: '5px solid #ffffff',
              boxShadow: '0 10px 30px rgba(76, 175, 80, 0.5), 0 5px 15px rgba(0, 0, 0, 0.3)',
              animation: 'pulse 1.5s ease-in-out infinite, fadeInUp 0.5s ease-out 1s both',
              letterSpacing: '0.1em'
            }}
            aria-label="Iniciar jogo"
          >
            <span aria-hidden="true">▶</span> {t.botoes.jogar}
          </button>

          {/* Botões Secundários - MAIORES */}
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6 mt-6">
            <button
              type="button"
              onClick={() => setTela('comoJogar')}
              className="flex flex-col items-center gap-3 transition-all duration-200 hover:scale-110 active:scale-95 focus:ring-4 focus:ring-blue-300 focus:outline-none"
              style={{
                animation: 'fadeInUp 0.5s ease-out 1.2s both'
              }}
              aria-label="Ver como jogar"
            >
              <div 
                className="w-24 h-24 rounded-3xl flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, #2196f3 0%, #1976d2 100%)',
                  border: '4px solid #ffffff',
                  boxShadow: '0 6px 20px rgba(33, 150, 243, 0.4)'
                }}
              >
                <span className="text-5xl" aria-hidden="true">🐾</span>
              </div>
              <span 
                className="text-base font-bold uppercase"
                style={{ 
                  color: '#2C5F7C',
                  textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)'
                }}
              >
                {t.botoes.comoJogar}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTela('conquistas')}
              className="flex flex-col items-center gap-3 transition-all duration-200 hover:scale-110 active:scale-95 focus:ring-4 focus:ring-yellow-300 focus:outline-none"
              style={{
                animation: 'fadeInUp 0.5s ease-out 1.4s both'
              }}
              aria-label="Ver conquistas"
            >
              <div 
                className="w-24 h-24 rounded-3xl flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, #ffc107 0%, #ffa000 100%)',
                  border: '4px solid #ffffff',
                  boxShadow: '0 6px 20px rgba(255, 193, 7, 0.4)'
                }}
              >
                <span className="text-5xl" aria-hidden="true">🏆</span>
              </div>
              <span 
                className="text-base font-bold uppercase"
                style={{ 
                  color: '#2C5F7C',
                  textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)'
                }}
              >
                {t.botoes.conquistas}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setTela('configuracoes')}
              className="flex flex-col items-center gap-3 transition-all duration-200 hover:scale-110 active:scale-95 focus:ring-4 focus:ring-gray-300 focus:outline-none"
              style={{
                animation: 'fadeInUp 0.5s ease-out 1.6s both'
              }}
              aria-label="Abrir configurações"
            >
              <div 
                className="w-24 h-24 rounded-3xl flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, #78909c 0%, #546e7a 100%)',
                  border: '4px solid #ffffff',
                  boxShadow: '0 6px 20px rgba(120, 144, 156, 0.4)'
                }}
              >
                <span className="text-5xl" aria-hidden="true">⚙️</span>
              </div>
              <span 
                className="text-base font-bold uppercase"
                style={{ 
                  color: '#2C5F7C',
                  textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)'
                }}
              >
                {t.botoes.configuracoes}
              </span>
            </button>
          </div>

          {/* Rodapé Informativo */}
          <p 
            className="text-lg text-center mt-8 font-semibold"
            style={{
              color: '#2C5F7C',
              fontFamily: 'Arial, sans-serif',
              textShadow: '0 2px 4px rgba(255, 255, 255, 0.8)',
              animation: 'fadeIn 0.5s ease-out 2s both'
            }}
          >
            {t.rodape}
          </p>
        </div>
      </main>
    );
  }

  // ============ TELA: MENU ============
  if (tela === 'menu') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center justify-center p-4 select-none relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
        }}
      >
        {/* Vinheta suave nas bordas */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at center, transparent 0%, rgba(26, 35, 50, 0.4) 100%)'
          }}
        />

        {/* Conteúdo principal */}
        <div className="relative z-10 flex flex-col items-center gap-8 max-w-2xl w-full animate-fade-in">
          
          {/* Título elegante */}
          <div className="text-center space-y-3">
            <h1 
              className="text-5xl md:text-7xl font-bold text-balance"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#FFF8E7',
                textShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
                letterSpacing: '0.02em'
              }}
            >
              Palavra
              <br />
              <span style={{ color: '#D4A853' }}>a bordo</span>
            </h1>
            <p 
              className="text-xl md:text-2xl opacity-90"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#F5EDD6',
                fontStyle: 'italic'
              }}
            >
              Aprenda palavras brincando
            </p>
          </div>

          {/* Galeria de Carros - Cartão elegante */}
          <div 
            className="w-full max-w-md rounded-2xl p-6"
            style={{
              background: 'rgba(255, 248, 231, 0.95)',
              boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3), 0 2px 10px rgba(0, 0, 0, 0.2)',
              backdropFilter: 'blur(10px)'
            }}
          >
            <h3 
              className="text-center font-bold mb-4 text-lg"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#2C3E50',
                letterSpacing: '0.05em'
              }}
            >
              Escolha seu Carro
            </h3>
            <div className="grid grid-cols-3 gap-3">
              {(['esportivo', 'sedã', 'hatch', 'compacto', 'caminhonete', 'van', 'moto', 'fusca', 'policial'] as const).map((modelo) => (
                <button
                  key={modelo}
                  onClick={() => escolherCarro(modelo)}
                  className="p-3 rounded-xl transition-all duration-200 hover:scale-105"
                  style={{
                    background: modeloCarro === modelo 
                      ? 'linear-gradient(135deg, #D4A853 0%, #C09845 100%)' 
                      : 'rgba(44, 62, 80, 0.05)',
                    border: modeloCarro === modelo 
                      ? '2px solid #D4A853' 
                      : '2px solid rgba(44, 62, 80, 0.1)',
                    boxShadow: modeloCarro === modelo 
                      ? '0 4px 12px rgba(212, 168, 83, 0.3)' 
                      : 'none'
                  }}
                >
                  <div className="text-3xl mb-1">
                    {modelo === 'esportivo' ? '🏎️' : 
                     modelo === 'sedã' ? '🚗' : 
                     modelo === 'hatch' ? '🚙' : 
                     modelo === 'compacto' ? '🚕' : 
                     modelo === 'caminhonete' ? '🛻' : 
                     modelo === 'van' ? '🚐' : 
                     modelo === 'moto' ? '🏍️' :
                     modelo === 'policial' ? '🚓' : '🚘'}
                  </div>
                  <p 
                    className="text-xs font-semibold capitalize"
                    style={{ 
                      fontFamily: 'Georgia, serif',
                      color: modeloCarro === modelo ? '#FFF8E7' : '#2C3E50'
                    }}
                  >
                    {modelo}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Botões principais */}
          <div className="flex flex-col gap-4 w-full max-w-sm">
            <button
              onClick={iniciarJogo}
              className="text-2xl font-bold py-5 px-8 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
                color: '#FFF8E7',
                boxShadow: '0 8px 24px rgba(44, 95, 124, 0.4), 0 2px 8px rgba(0, 0, 0, 0.2)',
                letterSpacing: '0.05em'
              }}
            >
              ▶ JOGAR
            </button>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setTela('comoJogar')}
                className="text-base font-semibold py-3 px-4 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  fontFamily: 'Georgia, serif',
                  background: 'rgba(255, 248, 231, 0.95)',
                  color: '#2C3E50',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
                  border: '2px solid rgba(212, 168, 83, 0.3)'
                }}
              >
                📖 Como Jogar
              </button>
              
              <button
                onClick={() => setTela('conquistas')}
                className="text-base font-semibold py-3 px-4 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  fontFamily: 'Georgia, serif',
                  background: 'rgba(255, 248, 231, 0.95)',
                  color: '#2C3E50',
                  boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
                  border: '2px solid rgba(212, 168, 83, 0.3)'
                }}
              >
                🏆 Conquistas
              </button>
            </div>

            <button
              onClick={() => setTela('configuracoes')}
              className="text-base font-semibold py-3 px-4 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'rgba(255, 248, 231, 0.95)',
                color: '#2C3E50',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
                border: '2px solid rgba(212, 168, 83, 0.3)'
              }}
            >
              ⚙️ Configurações
            </button>
          </div>

          {/* Barra de progresso */}
          {stats.fasesCompletadas > 0 && (
            <div 
              className="w-full max-w-sm rounded-xl p-4 animate-fade-in"
              style={{
                background: 'rgba(255, 248, 231, 0.95)',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)'
              }}
            >
              <p 
                className="text-center font-semibold mb-2"
                style={{ 
                  fontFamily: 'Georgia, serif',
                  color: '#2C3E50'
                }}
              >
                Seu Progresso: {stats.fasesCompletadas}/{fases.length} fases
              </p>
              <div 
                className="w-full h-3 rounded-full overflow-hidden"
                style={{ background: 'rgba(44, 62, 80, 0.1)' }}
              >
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{ 
                    width: `${(stats.fasesCompletadas / fases.length) * 100}%`,
                    background: 'linear-gradient(90deg, #7BA07B 0%, #6B8F6B 100%)'
                  }} 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ============ TELA: COMO JOGAR ============
  if (tela === 'comoJogar') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center p-4 select-none overflow-auto"
        style={{
          background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
        }}
      >
        <div 
          className="rounded-2xl p-8 max-w-lg w-full animate-fade-in"
          style={{
            background: 'rgba(255, 248, 231, 0.98)',
            boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.3)',
            border: '2px solid rgba(212, 168, 83, 0.3)'
          }}
        >
          <h2 
            className="text-4xl font-bold text-center mb-6"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            📖 Como Jogar
          </h2>
          <div className="space-y-5">
            {[
              { icone: '🎯', titulo: 'Objetivo', texto: 'Estacione o carro na vaga com a palavra que corresponde ao emoji mostrado no topo.' },
              { icone: '🎮', titulo: 'Controles', texto: 'Use as setas do teclado ou os botões na tela para mover o carro.' },
              { icone: '🔊', titulo: 'Som', texto: 'Toque no botão 🔊 para ouvir a palavra correta.' },
              { icone: '⭐', titulo: 'Estrelas', texto: 'Ganhe 3 estrelas se não errar, 2 se errar 1-2 vezes, 1 se errar mais.' },
              { icone: '💡', titulo: 'Dica', texto: 'Pressione H ou use o botão de dica para destacar a vaga correta.' },
              { icone: '📯', titulo: 'Buzina', texto: 'Pressione Espaço para buzinar!' }
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-4">
                <span className="text-3xl">{item.icone}</span>
                <div>
                  <p 
                    className="font-bold text-lg mb-1"
                    style={{ 
                      fontFamily: 'Georgia, serif',
                      color: '#2C3E50'
                    }}
                  >
                    {item.titulo}
                  </p>
                  <p 
                    className="text-base"
                    style={{ 
                      fontFamily: 'Georgia, serif',
                      color: '#5A6C7D'
                    }}
                  >
                    {item.texto}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => { pararMotor(); setTela('menu'); }}
            className="mt-8 w-full text-xl font-bold py-4 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              fontFamily: 'Georgia, serif',
              background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
              color: '#FFF8E7',
              boxShadow: '0 6px 20px rgba(44, 95, 124, 0.4)'
            }}
          >
            ← Voltar
          </button>
        </div>
      </div>
    );
  }

  // ============ TELA: CONQUISTAS ============
  if (tela === 'conquistas') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center p-4 select-none overflow-auto"
        style={{
          background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
        }}
      >
        <div 
          className="rounded-2xl p-8 max-w-lg w-full animate-fade-in"
          style={{
            background: 'rgba(255, 248, 231, 0.98)',
            boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.3)',
            border: '2px solid rgba(212, 168, 83, 0.3)'
          }}
        >
          <h2 
            className="text-4xl font-bold text-center mb-6"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            🏆 Conquistas
          </h2>
          <div className="space-y-3">
            {conquistas.map((c: Conquista) => {
              const desbloq = stats.conquistasDesbloqueadas.includes(c.id);
              return (
                <div 
                  key={c.id} 
                  className="flex items-center gap-4 p-4 rounded-xl transition-all duration-200"
                  style={{
                    background: desbloq 
                      ? 'linear-gradient(135deg, rgba(212, 168, 83, 0.1) 0%, rgba(212, 168, 83, 0.05) 100%)'
                      : 'rgba(44, 62, 80, 0.05)',
                    border: desbloq 
                      ? '2px solid #D4A853' 
                      : '2px solid rgba(44, 62, 80, 0.1)',
                    opacity: desbloq ? 1 : 0.6
                  }}
                >
                  <span className="text-4xl">{desbloq ? c.icone : '🔒'}</span>
                  <div>
                    <p 
                      className="font-bold text-base"
                      style={{ 
                        fontFamily: 'Georgia, serif',
                        color: '#2C3E50'
                      }}
                    >
                      {c.titulo}
                    </p>
                    <p 
                      className="text-sm"
                      style={{ 
                        fontFamily: 'Georgia, serif',
                        color: '#5A6C7D'
                      }}
                    >
                      {c.descricao}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
          <button
            onClick={() => { pararMotor(); setTela('menu'); }}
            className="mt-8 w-full text-xl font-bold py-4 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              fontFamily: 'Georgia, serif',
              background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
              color: '#FFF8E7',
              boxShadow: '0 6px 20px rgba(44, 95, 124, 0.4)'
            }}
          >
            ← Voltar
          </button>
        </div>
      </div>
    );
  }

  // ============ TELA: CONFIGURAÇÕES ============
  if (tela === 'configuracoes') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center p-4 select-none overflow-auto"
        style={{
          background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
        }}
      >
        <div 
          className="rounded-2xl p-8 max-w-lg w-full animate-fade-in"
          style={{
            background: 'rgba(255, 248, 231, 0.98)',
            boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.3)',
            border: '2px solid rgba(212, 168, 83, 0.3)'
          }}
        >
          <h2 
            className="text-4xl font-bold text-center mb-8"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            ⚙️ Configurações
          </h2>
          <div className="space-y-6">
            {[
              { label: '🎵 Volume da Música', value: volumesUI.musica, type: 'musica' as const },
              { label: '🔊 Volume dos Efeitos', value: volumesUI.efeitos, type: 'efeitos' as const },
              { label: '🗣️ Volume da Voz', value: volumesUI.voz, type: 'voz' as const }
            ].map((item, i) => (
              <div key={i}>
                <label 
                  className="font-semibold text-base block mb-3"
                  style={{ 
                    fontFamily: 'Georgia, serif',
                    color: '#2C3E50'
                  }}
                >
                  {item.label}: {Math.round(item.value * 100)}%
                </label>
                <input 
                  type="range" 
                  min="0" 
                  max="1" 
                  step="0.1" 
                  value={item.value}
                  onChange={(e) => handleVolumeChange(item.type, parseFloat(e.target.value))}
                  className="w-full" 
                />
              </div>
            ))}
            
            <div 
              className="flex items-center justify-between p-4 rounded-xl"
              style={{
                background: 'rgba(44, 62, 80, 0.05)',
                border: '2px solid rgba(44, 62, 80, 0.1)'
              }}
            >
              <span 
                className="font-semibold text-base"
                style={{ 
                  fontFamily: 'Georgia, serif',
                  color: '#2C3E50'
                }}
              >
                🎶 Música de Fundo
              </span>
              <button
                onClick={toggleMusica}
                className="px-6 py-3 rounded-full font-semibold transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  fontFamily: 'Georgia, serif',
                  background: musicaLigada 
                    ? 'linear-gradient(135deg, #7BA07B 0%, #6B8F6B 100%)'
                    : 'rgba(44, 62, 80, 0.1)',
                  color: musicaLigada ? '#FFF8E7' : '#5A6C7D',
                  boxShadow: musicaLigada ? '0 4px 12px rgba(123, 160, 123, 0.3)' : 'none'
                }}
              >
                {musicaLigada ? 'Ligada' : 'Desligada'}
              </button>
            </div>
          </div>
          <button
            onClick={() => { pararMotor(); setTela('menu'); }}
            className="mt-8 w-full text-xl font-bold py-4 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              fontFamily: 'Georgia, serif',
              background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
              color: '#FFF8E7',
              boxShadow: '0 6px 20px rgba(44, 95, 124, 0.4)'
            }}
          >
            ← Voltar
          </button>
        </div>
      </div>
    );
  }

  // ============ TELA: QUIZ ============
  if (tela === 'quiz' && quizPerguntas.length > 0) {
    const perguntaAtual = quizPerguntas[quizPerguntaAtual];
    const emojiFase = fases[faseAtual]?.imagem || '🎯';
    
    return (
      <div 
        className="fixed inset-0 flex items-center justify-center p-4 z-50 animate-fade-in"
        style={{
          background: 'rgba(0, 0, 0, 0.7)',
          backdropFilter: 'blur(8px)'
        }}
      >
        <div 
          className="rounded-3xl p-8 max-w-2xl w-full animate-fade-in-scale"
          style={{
            background: 'linear-gradient(135deg, #FFF8E7 0%, #F5EDD6 100%)',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5), 0 8px 24px rgba(0, 0, 0, 0.4)',
            border: '3px solid #D4A853'
          }}
        >
          {/* Cabeçalho do Quiz */}
          <div className="text-center mb-6">
            <div className="text-6xl mb-3">{emojiFase}</div>
            <h2 
              className="text-3xl font-bold mb-2"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#2C3E50'
              }}
            >
              Quiz de Consciência Fonológica
            </h2>
            <p 
              className="text-lg"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#5A6C7D'
              }}
            >
              Pergunta {quizPerguntaAtual + 1} de {quizPerguntas.length}
            </p>
          </div>

          {/* Balão de Diálogo com a Pergunta */}
          <div 
            className="rounded-2xl p-6 mb-6 relative"
            style={{
              background: 'rgba(255, 255, 255, 0.9)',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.1)',
              border: '2px solid rgba(212, 168, 83, 0.3)'
            }}
          >
            {/* Ponteiro do balão */}
            <div 
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 rotate-45"
              style={{
                background: 'rgba(255, 255, 255, 0.9)',
                border: '2px solid rgba(212, 168, 83, 0.3)',
                borderTop: 'none',
                borderLeft: 'none'
              }}
            />
            
            {/* Container da pergunta com botão de áudio */}
            <div className="flex items-center gap-4">
              {/* Texto da pergunta */}
              <p 
                className="text-2xl font-semibold flex-1"
                style={{ 
                  fontFamily: 'Georgia, serif',
                  color: '#2C3E50'
                }}
              >
                {perguntaAtual.pergunta}
              </p>
              
              {/* Botão de áudio */}
              <button
                onClick={() => falar(perguntaAtual.pergunta)}
                className="flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
                style={{
                  background: 'linear-gradient(135deg, #D4A853 0%, #C09845 100%)',
                  boxShadow: '0 4px 12px rgba(212, 168, 83, 0.4)',
                  border: '2px solid rgba(255, 248, 231, 0.3)'
                }}
                title="Ouvir pergunta"
              >
                <span className="text-2xl">🔊</span>
              </button>
            </div>
          </div>

          {/* Botões de Resposta */}
          <div className="grid grid-cols-1 gap-4">
            {perguntaAtual.opcoes.map((opcao, index) => {
              let buttonStyle = {
                background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
                border: '3px solid rgba(255, 248, 231, 0.2)'
              };
              let animationClass = '';

              // Feedback visual baseado na resposta
              if (quizRespostaSelecionada === index) {
                if (quizRespostaCorreta) {
                  buttonStyle = {
                    background: 'linear-gradient(135deg, #7BA07B 0%, #6B8F6B 100%)',
                    border: '3px solid #7BA07B'
                  };
                } else if (quizRespostaErrada) {
                  buttonStyle = {
                    background: 'linear-gradient(135deg, #D4A853 0%, #C09845 100%)',
                    border: '3px solid #D4A853'
                  };
                  animationClass = 'animate-shake';
                }
              }

              return (
                <div key={index} className="flex items-center gap-3">
                  {/* Botão de resposta */}
                  <button
                    onClick={() => responderQuiz(index)}
                    disabled={quizRespostaCorreta || quizRespostaErrada}
                    className={`flex-1 text-2xl font-bold py-6 px-8 rounded-2xl transition-all duration-200 hover:scale-105 active:scale-95 disabled:cursor-not-allowed ${animationClass}`}
                    style={{
                      ...buttonStyle,
                      color: '#FFF8E7',
                      fontFamily: 'Georgia, serif',
                      boxShadow: '0 6px 20px rgba(44, 95, 124, 0.4)'
                    }}
                  >
                    {opcao}
                  </button>
                  
                  {/* Botão de áudio para a opção */}
                  <button
                    onClick={() => falar(opcao)}
                    disabled={quizRespostaCorreta || quizRespostaErrada}
                    className="flex-shrink-0 w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{
                      background: 'linear-gradient(135deg, #4A90E2 0%, #357ABD 100%)',
                      boxShadow: '0 4px 12px rgba(74, 144, 226, 0.4)',
                      border: '2px solid rgba(255, 248, 231, 0.3)'
                    }}
                    title={`Ouvir opção ${opcao}`}
                  >
                    <span className="text-xl">🔊</span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* Indicador de Progresso */}
          <div className="mt-6 flex justify-center gap-2">
            {quizPerguntas.map((_, index) => (
              <div
                key={index}
                className="w-3 h-3 rounded-full transition-all duration-300"
                style={{
                  background: index < quizPerguntaAtual ? '#7BA07B' : 
                             index === quizPerguntaAtual ? '#D4A853' : 'rgba(44, 62, 80, 0.2)',
                  transform: index === quizPerguntaAtual ? 'scale(1.3)' : 'scale(1)'
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ============ TELA: FINAL ============
  if (tela === 'final') {
    return (
      <div 
        className="min-h-screen flex flex-col items-center justify-center p-4 select-none"
        style={{
          background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
        }}
      >
        <div 
          className="rounded-3xl p-10 max-w-md w-full text-center animate-fade-in-scale"
          style={{
            background: 'linear-gradient(135deg, #FFF8E7 0%, #F5EDD6 100%)',
            boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5), 0 8px 24px rgba(0, 0, 0, 0.4)',
            border: '3px solid #D4A853'
          }}
        >
          <h2 
            className="text-5xl font-bold mb-6"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            🏆 Parabéns! 🏆
          </h2>
          <p 
            className="text-2xl mb-6"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#5A6C7D'
            }}
          >
            Você completou todas as {fases.length} fases!
          </p>
          <div 
            className="text-6xl mb-6"
            style={{ color: '#D4A853' }}
          >
            ⭐ {acertos} ⭐
          </div>
          <p 
            className="text-lg mb-8"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#5A6C7D'
            }}
          >
            Conquistas: {stats.conquistasDesbloqueadas.length}/10
          </p>
          <div className="flex flex-col gap-4">
            <button
              onClick={reiniciar}
              className="text-xl font-bold py-4 px-6 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'linear-gradient(135deg, #7BA07B 0%, #6B8F6B 100%)',
                color: '#FFF8E7',
                boxShadow: '0 6px 20px rgba(123, 160, 123, 0.4)'
              }}
            >
              🔄 Jogar de Novo
            </button>
            <button
              onClick={() => { pararMotor(); setTela('menu'); }}
              className="text-xl font-bold py-4 px-6 rounded-full transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
                color: '#FFF8E7',
                boxShadow: '0 6px 20px rgba(44, 95, 124, 0.4)'
              }}
            >
              🏠 Menu
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ============ TELA: JOGANDO ============
  return (
    <div 
      className="min-h-screen flex flex-col items-center px-4 py-6 select-none overflow-x-hidden relative"
      style={{
        background: 'linear-gradient(135deg, #1A2332 0%, #2C3E50 50%, #34495E 100%)'
      }}
    >
      {/* HUD Superior - Vidro fosco elegante */}
      <div 
        className="w-full rounded-2xl p-4 mb-4 animate-fade-in"
        style={{
          background: 'rgba(255, 248, 231, 0.95)',
          backdropFilter: 'blur(10px)',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3), 0 2px 8px rgba(0, 0, 0, 0.2)',
          border: '2px solid rgba(212, 168, 83, 0.3)',
          maxWidth: `${canvasWidth}px`
        }}
      >
        {/* Linha superior: Menu, Fase, Layout, Estrelas */}
        <div className="flex items-center justify-between flex-wrap gap-3 mb-3">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => { pararMotor(); setTela('menu'); }} 
              className="px-4 py-2 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'rgba(44, 62, 80, 0.1)',
                color: '#2C3E50',
                border: '2px solid rgba(44, 62, 80, 0.2)'
              }}
            >
              ← Menu
            </button>
            <span 
              className="font-semibold text-base"
              style={{ 
                fontFamily: 'Georgia, serif',
                color: '#2C3E50'
              }}
            >
              Fase {faseAtual + 1} de {fases.length}
            </span>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={alternarLayout} 
              className="px-4 py-2 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                fontFamily: 'Georgia, serif',
                background: 'rgba(44, 95, 124, 0.1)',
                color: '#2C5F7C',
                border: '2px solid rgba(44, 95, 124, 0.3)'
              }}
              title="Alternar Layout"
            >
              🅿️ {gameState.current.layout === 'classico' ? 'Clássico' : 'Shopping'}
            </button>
            <div className="flex items-center gap-2">
              <span 
                className="font-bold text-lg"
                style={{ color: '#D4A853' }}
              >
                ⭐ {acertos}
              </span>
              {estrelasFase > 0 && (
                <span className="text-xl">
                  {'⭐'.repeat(estrelasFase)}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Linha inferior: Palavra alvo, botões de som e dica */}
        <div 
          className="rounded-xl px-4 py-3 inline-flex items-center gap-3"
          style={{
            background: 'rgba(255, 248, 231, 0.6)',
            border: '2px solid rgba(212, 168, 83, 0.4)'
          }}
        >
          <span 
            className="font-semibold text-base"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            Estacione:
          </span>
          <span className="text-3xl">{fase?.imagem}</span>
          
          <button 
            onClick={falarPalavra} 
            className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
              boxShadow: '0 2px 8px rgba(44, 95, 124, 0.3)'
            }}
            title="Ouvir palavra"
          >
            🔊
          </button>
          
          <button 
            onClick={usarDica} 
            className="w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
            style={{
              background: 'linear-gradient(135deg, #D4A853 0%, #C09845 100%)',
              boxShadow: '0 2px 8px rgba(212, 168, 83, 0.3)'
            }}
            title="Dica (H)"
          >
            💡
          </button>
        </div>

        {/* Barra de progresso */}
        <div className="mt-3">
          <div 
            className="w-full h-2 rounded-full overflow-hidden"
            style={{ background: 'rgba(44, 62, 80, 0.1)' }}
          >
            <div 
              className="h-full rounded-full transition-all duration-500"
              style={{ 
                width: `${((faseAtual) / fases.length) * 100}%`,
                background: 'linear-gradient(90deg, #7BA07B 0%, #6B8F6B 100%)'
              }} 
            />
          </div>
        </div>
      </div>

      {/* Canvas do jogo */}
      <canvas
        ref={canvasRef}
        width={900}
        height={500}
        className="rounded-2xl animate-fade-in-scale"
        style={{ 
          width: `${canvasWidth}px`, 
          height: `${canvasHeight}px`, 
          maxWidth: '100%',
          aspectRatio: '900 / 500',
          touchAction: 'none',
          boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.3)',
          border: '3px solid rgba(212, 168, 83, 0.3)',
          display: 'block',
          margin: '0 auto'
        }}
      />

      {/* Mensagem de feedback */}
      <div 
        className="text-center font-semibold mt-4 min-h-[40px] px-6 py-3 rounded-xl w-full animate-fade-in"
        style={{
          fontFamily: 'Georgia, serif',
          background: 'rgba(255, 248, 231, 0.95)',
          color: '#2C3E50',
          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.2)',
          border: '2px solid rgba(212, 168, 83, 0.3)',
          maxWidth: `${canvasWidth}px`
        }}
      >
        {mensagem}
      </div>

      {/* Controles direcionais */}
      <div className="grid grid-cols-3 gap-2 mt-4" style={{ gridTemplateColumns: 'repeat(3, 70px)', gridTemplateRows: 'repeat(3, 70px)' }}>
        <div className="invisible" />
        <button
          className="rounded-2xl text-2xl cursor-pointer flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
            boxShadow: '0 4px 12px rgba(44, 95, 124, 0.3)',
            border: '2px solid rgba(255, 248, 231, 0.2)'
          }}
          onTouchStart={handleDirStart('up')} onTouchEnd={handleDirEnd('up')} onTouchCancel={handleDirEnd('up')}
          onMouseDown={handleDirStart('up')} onMouseUp={handleDirEnd('up')} onMouseLeave={handleDirEnd('up')}
        >⬆️</button>
        <div className="invisible" />

        <button
          className="rounded-2xl text-2xl cursor-pointer flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
            boxShadow: '0 4px 12px rgba(44, 95, 124, 0.3)',
            border: '2px solid rgba(255, 248, 231, 0.2)'
          }}
          onTouchStart={handleDirStart('left')} onTouchEnd={handleDirEnd('left')} onTouchCancel={handleDirEnd('left')}
          onMouseDown={handleDirStart('left')} onMouseUp={handleDirEnd('left')} onMouseLeave={handleDirEnd('left')}
        >⬅️</button>
        <button
          onClick={falarPalavra}
          className="rounded-2xl text-xl cursor-pointer flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #D4A853 0%, #C09845 100%)',
            boxShadow: '0 4px 12px rgba(212, 168, 83, 0.3)',
            border: '2px solid rgba(255, 248, 231, 0.2)'
          }}
        >🔊</button>
        <button
          className="rounded-2xl text-2xl cursor-pointer flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
            boxShadow: '0 4px 12px rgba(44, 95, 124, 0.3)',
            border: '2px solid rgba(255, 248, 231, 0.2)'
          }}
          onTouchStart={handleDirStart('right')} onTouchEnd={handleDirEnd('right')} onTouchCancel={handleDirEnd('right')}
          onMouseDown={handleDirStart('right')} onMouseUp={handleDirEnd('right')} onMouseLeave={handleDirEnd('right')}
        >➡️</button>

        <div className="invisible" />
        <button
          className="rounded-2xl text-2xl cursor-pointer flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: 'linear-gradient(135deg, #2C5F7C 0%, #1E4A63 100%)',
            boxShadow: '0 4px 12px rgba(44, 95, 124, 0.3)',
            border: '2px solid rgba(255, 248, 231, 0.2)'
          }}
          onTouchStart={handleDirStart('down')} onTouchEnd={handleDirEnd('down')} onTouchCancel={handleDirEnd('down')}
          onMouseDown={handleDirStart('down')} onMouseUp={handleDirEnd('down')} onMouseLeave={handleDirEnd('down')}
        >⬇️</button>
        <div className="invisible" />
      </div>

      {/* Notificação de conquista */}
      {novaConquista && (
        <div 
          className="fixed top-8 left-1/2 -translate-x-1/2 rounded-2xl p-6 z-50 text-center animate-fade-in-scale"
          style={{
            background: 'linear-gradient(135deg, #FFF8E7 0%, #F5EDD6 100%)',
            boxShadow: '0 12px 48px rgba(0, 0, 0, 0.4), 0 4px 16px rgba(0, 0, 0, 0.3)',
            border: '3px solid #D4A853'
          }}
        >
          <p className="text-4xl mb-2">{novaConquista.icone}</p>
          <p 
            className="font-bold text-xl mb-1"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#2C3E50'
            }}
          >
            Conquista Desbloqueada!
          </p>
          <p 
            className="font-bold text-lg"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#D4A853'
            }}
          >
            {novaConquista.titulo}
          </p>
          <p 
            className="text-sm mt-2"
            style={{ 
              fontFamily: 'Georgia, serif',
              color: '#5A6C7D'
            }}
          >
            {novaConquista.descricao}
          </p>
        </div>
      )}
    </div>
  );
}
