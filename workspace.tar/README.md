# 🚗 Palavra a bordo 🅿️

Jogo educativo de alfabetização em português brasileiro onde crianças aprendem palavras dirigindo um carro até a vaga correta em um estacionamento.

![Versão](https://img.shields.io/badge/versão-2.0-green)
![Licença](https://img.shields.io/badge/licença-MIT-blue)
![React](https://img.shields.io/badge/React-18-61DAFB)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6)

## 🎯 Sobre o Projeto

**Palavra a bordo** é um jogo educativo desenvolvido para ajudar crianças de 5-8 anos no processo de alfabetização. Através de uma mecânica divertida de estacionamento, os jogadores aprendem a reconhecer palavras e seus significados através de pares mínimos pedagógicos.

### 🎮 Como Jogar

1. Observe o emoji no topo da tela
2. Use as setas do teclado ou botões na tela para mover o carro
3. Estacione na vaga com a palavra correspondente ao emoji
4. Complete todas as 36 fases para vencer!

## ✨ Características

### 🎨 Visual e Animações
- 9 modelos de carros diferentes (esportivo, sedã, hatch, caminhonete, van, moto, fusca, policial)
- 2 layouts de estacionamento (Clássico e Shopping)
- Sistema de partículas (fumaça, confetes, estrelas, faíscas)
- Marcas de pneu no asfalto
- Sombras dinâmicas
- Faróis piscando ao buzinar
- Transições suaves entre fases
- Guarda de trânsito animado com dicas

### 🎵 Áudio
- Motor contínuo que muda de tom com a velocidade
- Música de fundo alegre (gerada via Web Audio API)
- Síntese de voz para ler as palavras em português
- Efeitos sonoros para acertos, erros e colisões
- Controles de volume separados

### 🏆 Progresso e Conquistas
- 36 fases organizadas por dificuldade
- Sistema de estrelas (1-3 por fase)
- 10 conquistas desbloqueáveis
- Progresso salvo automaticamente
- Estatísticas detalhadas

### 📚 Conteúdo Pedagógico
- Pares mínimos (CASA/CAMA, GATO/PATO, etc.)
- Categorias temáticas (animais, alimentos, objetos, transportes)
- Sílabas complexas (CH, LH, NH, RR, SS)
- Tratamento correto de acentos

## 🚀 Como Executar

### Pré-requisitos

- Node.js 18+ instalado
- npm ou yarn

### Instalação

```bash
# Clone o repositório
git clone https://github.com/SEU_USUARIO/palavra-a-bordo.git

# Entre na pasta do projeto
cd palavra-a-bordo

# Instale as dependências
npm install

# Execute em modo de desenvolvimento
npm run dev

# Build para produção
npm run build
```

O jogo estará disponível em `http://localhost:5173`

## 🎮 Controles

| Ação | Teclado | Touch |
|------|---------|-------|
| Mover | Setas ou WASD | Botões direcionais |
| Buzinar | Espaço | - |
| Dica | H | Botão 💡 |
| Ouvir palavra | - | Botão 🔊 |

## 🏗️ Estrutura do Projeto

```
palavra-a-bordo/
├── src/
│   ├── game/
│   │   ├── data.ts          # Dados do jogo (fases, conquistas)
│   │   ├── drawing.ts       # Renderização (carros, estacionamento)
│   │   ├── audio.ts         # Sistema de áudio
│   │   └── particles.ts     # Sistema de partículas
│   ├── App.tsx              # Componente principal
│   ├── main.tsx             # Entry point
│   └── index.css            # Estilos globais
├── public/                  # Arquivos estáticos
├── index.html               # HTML base
├── package.json             # Dependências
├── vite.config.ts           # Configuração Vite
├── tsconfig.json            # Configuração TypeScript
└── GUIA_MODELOS_CARROS.md   # Guia para criar novos carros
```

## 🎨 Personalização

### Adicionar Novos Modelos de Carros

Consulte o arquivo `GUIA_MODELOS_CARROS.md` para instruções detalhadas sobre como criar seus próprios modelos de carros.

### Adicionar Novas Fases

Edite o arquivo `src/game/data.ts` e adicione novas fases no array `fases`:

```typescript
{
  imagem: '🎈',           // Emoji
  correta: 'BALA',        // Palavra correta
  opcoes: ['BALA', 'BOLA', 'BOTA', 'BICA', 'BICO'],  // 5 opções
  categoria: 'objetos',   // Categoria
  dificuldade: 1          // 1-3
}
```

## 🛠️ Tecnologias Utilizadas

- **React 18** - Biblioteca UI
- **TypeScript** - Tipagem estática
- **Vite** - Build tool
- **Tailwind CSS** - Estilização
- **Canvas API** - Renderização gráfica
- **Web Audio API** - Áudio procedural
- **Speech Synthesis API** - Síntese de voz

## 📱 Compatibilidade

- ✅ Chrome/Edge (recomendado)
- ✅ Firefox
- ✅ Safari
- ✅ Mobile (iOS/Android)
- ✅ Tablets

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se à vontade para:

- Reportar bugs
- Sugerir novas funcionalidades
- Melhorar a documentação
- Adicionar novos modelos de carros
- Criar novas fases

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 🙏 Agradecimentos

- Desenvolvido com ❤️ para a educação infantil
- Inspirado em jogos como Crossy Road e Parking Jam
- Design isométrico inspirado em jogos voxel

## 📞 Contato

Se tiver dúvidas ou sugestões:
- Abra uma issue no GitHub
- Envie um pull request

---

**Divirta-se aprendendo!** 🎓🚗💨
