# 📤 Guia Completo: Como Subir o Projeto no GitHub

Este guia te ensina passo a passo como publicar seu projeto AlfaEstacionamento no GitHub.

---

## 🎯 Pré-requisitos

Antes de começar, você precisa ter:

1. ✅ Conta no GitHub (gratuita) - [crie aqui](https://github.com/signup)
2. ✅ Git instalado no computador
3. ✅ Editor de código (VS Code recomendado)

### Instalando o Git

**Windows:**
- Baixe em: https://git-scm.com/download/win
- Instale com as opções padrão

**Mac:**
```bash
# Opção 1: Via Homebrew
brew install git

# Opção 2: Baixe em https://git-scm.com/download/mac
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install git
```

### Verificando a Instalação

Abra o terminal e digite:
```bash
git --version
```

Deve aparecer algo como: `git version 2.39.0`

---

## 🚀 Método 1: Via Terminal (Recomendado)

### Passo 1: Configurar Git (primeira vez apenas)

```bash
# Configure seu nome e email
git config --global user.name "Seu Nome"
git config --global user.email "seu.email@exemplo.com"

# Verifique as configurações
git config --list
```

### Passo 2: Inicializar Git no Projeto

Abra o terminal na pasta do projeto:

```bash
# Navegue até a pasta do projeto
cd caminho/para/alfaestacionamento

# Inicialize o Git
git init
```

### Passo 3: Adicionar Arquivos

```bash
# Adicione todos os arquivos
git add .

# Verifique o status
git status
```

### Passo 4: Criar Primeiro Commit

```bash
# Crie o commit inicial
git commit -m "🎮 AlfaEstacionamento - Jogo educativo de alfabetização"
```

### Passo 5: Criar Repositório no GitHub

1. Acesse: https://github.com/new
2. Preencha os campos:
   - **Repository name:** `alfaestacionamento` (ou o nome que preferir)
   - **Description:** `Jogo educativo de alfabetização em português`
   - **Public** (recomendado) ou **Private**
   - ❌ **NÃO** marque "Add a README" (já temos um)
   - ❌ **NÃO** marque "Add .gitignore" (já temos um)
   - ❌ **NÃO** marque "Choose a license" (adicione depois se quiser)
3. Clique em **Create repository**

### Passo 6: Conectar e Enviar

O GitHub vai mostrar comandos. Copie e execute:

```bash
# Conecte o repositório local ao remoto
git remote add origin https://github.com/SEU_USUARIO/alfaestacionamento.git

# Renomeie a branch principal
git branch -M main

# Envie os arquivos
git push -u origin main
```

**Substitua `SEU_USUARIO` pelo seu nome de usuário do GitHub!**

### Passo 7: Autenticação

Na primeira vez, o Git vai pedir suas credenciais:

1. **Username:** seu usuário do GitHub
2. **Password:** você precisa usar um **Personal Access Token** (não a senha normal)

#### Como criar um Personal Access Token:

1. Vá em: https://github.com/settings/tokens
2. Clique em **Generate new token (classic)**
3. Dê um nome (ex: "Meu PC")
4. Selecione as permissões: ✅ `repo`
5. Clique em **Generate token**
6. **COPIE O TOKEN** (ele só aparece uma vez!)
7. Use esse token como senha no Git

---

## 🖱️ Método 2: Via GitHub Desktop (Mais Fácil)

Se preferir uma interface gráfica:

### Passo 1: Instalar GitHub Desktop

- Baixe em: https://desktop.github.com/
- Instale e faça login com sua conta GitHub

### Passo 2: Adicionar Projeto

1. Abra o GitHub Desktop
2. Clique em **File > Add Local Repository**
3. Clique em **Choose...** e selecione a pasta do projeto
4. Se aparecer "This directory does not appear to be a Git repository":
   - Clique em **create a repository**
   - Preencha:
     - **Name:** alfaestacionamento
     - **Local Path:** (já preenchido)
     - **Initialize with README:** ❌ desmarque
   - Clique em **Create Repository**

### Passo 3: Fazer Primeiro Commit

1. Na aba **Changes**, você verá todos os arquivos
2. Digite uma mensagem no campo inferior: `🎮 Primeira versão do jogo`
3. Clique em **Commit to main**

### Passo 4: Publicar no GitHub

1. Clique em **Publish repository**
2. Preencha:
   - **Name:** alfaestacionamento
   - **Description:** Jogo educativo de alfabetização
   - **Keep this code private:** ❌ desmarque (para ser público)
3. Clique em **Publish Repository**

Pronto! Seu projeto está no GitHub! 🎉

---

## 🔄 Atualizações Futuras

Sempre que você fizer mudanças no código:

```bash
# 1. Adicione as mudanças
git add .

# 2. Crie um commit com descrição
git commit -m "✨ Adicionei novo modelo de carro"

# 3. Envie para o GitHub
git push
```

### Exemplos de Mensagens de Commit

- `✨ Adicionei novo modelo de carro`
- `🐛 Corrigi bug na colisão`
- `📝 Atualizei a documentação`
- `🎨 Melhorei as animações`
- `🎵 Adicionei novos sons`

---

## 🌐 Publicar como Site (GitHub Pages)

Quer que o jogo fique acessível online? Use o GitHub Pages!

### Opção 1: Vercel (Mais Fácil)

1. Acesse: https://vercel.com/
2. Faça login com GitHub
3. Clique em **New Project**
4. Selecione seu repositório
5. Clique em **Deploy**
6. Pronto! Você terá um link tipo: `alfaestacionamento.vercel.app`

### Opção 2: Netlify

1. Acesse: https://www.netlify.com/
2. Faça login com GitHub
3. Arraste a pasta `dist` para o Netlify
4. Pronto! Link tipo: `alfaestacionamento.netlify.app`

### Opção 3: GitHub Pages

```bash
# Instale o pacote para deploy
npm install -D gh-pages

# Adicione no package.json (scripts):
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"

# Execute
npm run deploy
```

Depois ative o GitHub Pages nas configurações do repositório.

---

## 🐛 Problemas Comuns

### "Permission denied (publickey)"

```bash
# Gere uma nova chave SSH
ssh-keygen -t ed25519 -C "seu.email@exemplo.com"

# Adicione ao SSH agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# Copie a chave
cat ~/.ssh/id_ed25519.pub

# Adicione no GitHub: https://github.com/settings/keys
```

### "Updates were rejected because the remote contains work"

```bash
# Puxe as mudanças primeiro
git pull origin main

# Depois envie
git push
```

### "fatal: remote origin already exists"

```bash
# Remova o remote antigo
git remote remove origin

# Adicione novamente
git remote add origin https://github.com/SEU_USUARIO/alfaestacionamento.git
```

---

## 📋 Checklist Final

Antes de subir, verifique:

- [ ] Arquivo `.gitignore` criado
- [ ] Arquivo `README.md` criado
- [ ] Projeto funcionando localmente (`npm run dev`)
- [ ] Build funcionando (`npm run build`)
- [ ] Pasta `node_modules` NÃO está sendo enviada
- [ ] Pasta `dist` NÃO está sendo enviada
- [ ] Mensagem de commit descritiva
- [ ] Repositório criado no GitHub
- [ ] Remote configurado corretamente

---

## 🎓 Comandos Git Essenciais

```bash
# Ver status
git status

# Ver histórico
git log

# Ver diferenças
git diff

# Desfazer mudanças (cuidado!)
git checkout -- arquivo.txt

# Criar nova branch
git checkout -b nova-feature

# Voltar para main
git checkout main

# Mesclar branch
git merge nova-feature
```

---

## 📞 Precisa de Ajuda?

- Documentação oficial do Git: https://git-scm.com/doc
- GitHub Guides: https://guides.github.com/
- Stack Overflow: https://stackoverflow.com/questions/tagged/git

---

**Boa sorte com seu projeto!** 🚀🎮

Se tiver dúvidas, abra uma issue no próprio repositório ou consulte a documentação.
