# 🚗 Guia: Como Criar Seus Próprios Modelos de Carros

## 📍 Onde Editar

Os modelos de carros estão em **3 arquivos**:

1. **`src/game/drawing.ts`** - Desenho do carro (gráficos)
2. **`src/game/data.ts`** - Lista de modelos disponíveis
3. **`src/App.tsx`** - Galeria de seleção no menu

---

## 🎨 Passo a Passo: Criar um Novo Modelo

### PASSO 1: Criar a Função de Desenho

Abra `src/game/drawing.ts` e crie sua função seguindo este modelo:

```typescript
/**
 * Nome do Seu Modelo - descrição breve
 */
function desenharSeuModelo(
  ctx: CanvasRenderingContext2D,  // contexto do canvas
  cx: number,                      // centro X
  cy: number,                      // centro Y
  w: number,                       // largura
  h: number,                       // altura
  cor: string,                     // cor principal
  farolAceso: boolean = false      // se faróis estão ligados
) {
  // Escala baseada no tamanho
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // DESENHE SEU CARRO AQUI
  // Origem (0,0) é o centro do carro
  // Carro aponta para a DIREITA por padrão

  // Exemplo: corpo do carro
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-50, 15);    // ponto inicial
  ctx.lineTo(-50, -10);   // linha até aqui
  ctx.lineTo(50, -10);    // outra linha
  ctx.lineTo(50, 15);     // fecha
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Exemplo: vidros
  ctx.fillStyle = '#0a0a0a';
  ctx.fillRect(-20, -25, 40, 15);

  // Exemplo: rodas
  desenharRoda(ctx, -30, 18, 9);  // roda traseira
  desenharRoda(ctx, 30, 18, 9);   // roda dianteira

  // Exemplo: faróis
  if (farolAceso) {
    ctx.fillStyle = '#FFFF00';
    ctx.shadowColor = '#FFFF00';
    ctx.shadowBlur = 10;
  } else {
    ctx.fillStyle = '#FFEB3B';
  }
  ctx.fillRect(47, -5, 3, 10);
  ctx.shadowBlur = 0;

  ctx.restore();
}
```

### PASSO 2: Registrar no Switch Case

Na função `desenharCarroIsometrico`, adicione seu modelo:

```typescript
switch (modelo) {
  case 'esportivo': desenharEsportivo(ctx, cx, cy, w, h, cor, farolAceso); break;
  case 'sedã': desenharSeda(ctx, cx, cy, w, h, cor, farolAceso); break;
  // ... outros modelos ...
  case 'seumodelo': desenharSeuModelo(ctx, cx, cy, w, h, cor, farolAceso); break; // ← ADICIONE AQUI
  default: desenharSeda(ctx, cx, cy, w, h, cor, farolAceso);
}
```

### PASSO 3: Adicionar à Lista de Modelos

Abra `src/game/data.ts` e adicione na lista:

```typescript
export const modelosCarros = [
  'esportivo', 'sedã', 'hatch', 'compacto', 
  'caminhonete', 'van', 'moto', 'fusca', 
  'seumodelo'  // ← ADICIONE AQUI
] as const;
```

### PASSO 4: Adicionar na Galeria do Menu

Abra `src/App.tsx` e adicione na galeria:

```typescript
{(['esportivo', 'sedã', ..., 'seumodelo'] as const).map((modelo) => (
  <button key={modelo} onClick={() => escolherCarro(modelo)} ...>
    <div className="text-2xl mb-1">
      {modelo === 'esportivo' ? '🏎️' : 
       // ... outros ...
       modelo === 'seumodelo' ? '🚘' : '🚗'}  // ← ADICIONE EMOJI
    </div>
    <p className="text-white text-xs capitalize">{modelo}</p>
  </button>
))}
```

---

## 🎯 Dicas de Desenho

### Coordenadas
- **Origem (0,0)** = centro do carro
- **Eixo X**: negativo = trás, positivo = frente
- **Eixo Y**: negativo = topo, positivo = base
- **Carro aponta para DIREITA** por padrão

### Funções Úteis do Canvas

```typescript
// Retângulo
ctx.fillRect(x, y, largura, altura);

// Círculo
ctx.beginPath();
ctx.arc(x, y, raio, 0, Math.PI * 2);
ctx.fill();

// Forma personalizada
ctx.beginPath();
ctx.moveTo(x1, y1);  // início
ctx.lineTo(x2, y2);  // linha reta
ctx.lineTo(x3, y3);  // outra linha
ctx.closePath();      // fecha a forma
ctx.fill();           // preenche
ctx.stroke();         // contorno

// Curva suave
ctx.quadraticCurveTo(controleX, controleY, finalX, finalY);
```

### Cores
```typescript
// Cor sólida
ctx.fillStyle = '#FF0000';  // vermelho
ctx.fillStyle = 'rgb(255, 0, 0)';
ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';  // com transparência

// Gradiente
const grad = ctx.createLinearGradient(0, 0, 100, 0);
grad.addColorStop(0, '#FF0000');
grad.addColorStop(1, '#0000FF');
ctx.fillStyle = grad;
```

### Efeitos Especiais
```typescript
// Brilho (glow)
ctx.shadowColor = '#FFFF00';
ctx.shadowBlur = 10;
// desenhe algo aqui
ctx.shadowBlur = 0;  // desliga o brilho

// Transparência
ctx.globalAlpha = 0.5;  // 50% transparente
// desenhe algo aqui
ctx.globalAlpha = 1;    // volta ao normal
```

---

## 📐 Exemplos Práticos

### Exemplo 1: Carro Simples (Retangular)

```typescript
function desenharSimples(ctx, cx, cy, w, h, cor, farolAceso) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Corpo
  ctx.fillStyle = cor;
  ctx.fillRect(-50, -20, 100, 40);
  ctx.strokeStyle = '#222';
  ctx.strokeRect(-50, -20, 100, 40);

  // Teto
  ctx.fillStyle = escurecerCor(cor, 0.8);
  ctx.fillRect(-30, -30, 60, 15);

  // Rodas
  desenharRoda(ctx, -35, 20, 8);
  desenharRoda(ctx, 35, 20, 8);
  desenharRoda(ctx, -35, -20, 8);
  desenharRoda(ctx, 35, -20, 8);

  ctx.restore();
}
```

### Exemplo 2: Carro com Detalhes

```typescript
function desenharDetalhado(ctx, cx, cy, w, h, cor, farolAceso) {
  const escX = w / 100, escY = h / 55;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(escX, escY);

  // Sombra
  ctx.fillStyle = 'rgba(0,0,0,0.3)';
  ctx.beginPath();
  ctx.ellipse(0, 25, 50, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  // Corpo principal
  ctx.fillStyle = cor;
  ctx.beginPath();
  ctx.moveTo(-45, 15);
  ctx.quadraticCurveTo(-50, 0, -45, -15);
  ctx.lineTo(45, -15);
  ctx.quadraticCurveTo(50, 0, 45, 15);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  // Brilho
  ctx.fillStyle = clarearCor(cor, 0.3);
  ctx.fillRect(-40, -14, 80, 3);

  // Vidros
  ctx.fillStyle = '#1a1a1a';
  ctx.fillRect(-25, -25, 50, 12);

  // Faróis
  ctx.fillStyle = farolAceso ? '#FFFF00' : '#FFEB3B';
  ctx.beginPath();
  ctx.arc(42, -8, 4, 0, Math.PI * 2);
  ctx.arc(42, 8, 4, 0, Math.PI * 2);
  ctx.fill();

  // Rodas
  desenharRoda(ctx, -30, 18, 9);
  desenharRoda(ctx, 30, 18, 9);

  ctx.restore();
}
```

---

## 🧪 Testando

1. Salve o arquivo
2. O Vite recarrega automaticamente (hot reload)
3. Vá no menu do jogo
4. Seu novo modelo deve aparecer na galeria
5. Selecione e jogue!

---

## 🎨 Modelos Já Incluídos

1. **Esportivo** 🏎️ - Carro baixo e rápido
2. **Sedã** 🚗 - Carro médio padrão
3. **Hatch** 🚙 - Compacto com porta traseira
4. **Compacto** 🚕 - Pequeno e ágil
5. **Caminhonete** 🛻 - Picape com caçamba
6. **Van** 🚐 - Veículo grande e alto
7. **Moto** 🏍️ - Motocicleta (2 rodas)
8. **Fusca** 🚘 - Clássico arredondado
9. **Policial** 🚓 - Carro de polícia com giroflex

---

## 💡 Dicas Finais

- **Comece simples**: faça um retângulo primeiro, depois adicione detalhes
- **Use o exemplo do Policial** como referência
- **Teste frequentemente** para ver como fica
- **A escala é automática** (w/100, h/55), então desenhe em coordenadas -50 a 50
- **O carro gira automaticamente** conforme a direção, então não precisa desenhar em todas as direções
- **Faróis piscam** quando o jogador buzina (tecla Espaço)

---

## 🆘 Precisa de Ajuda?

Se tiver dúvidas, olhe os modelos existentes em `src/game/drawing.ts`:
- `desenharPolicial` - Exemplo recente e bem comentado
- `desenharFusca` - Exemplo de forma arredondada
- `desenharMoto` - Exemplo de veículo diferente

Bom desenho! 🎨🚗
